package com.github.susan.debounceclick.plugin

class DebounceClickExtension {
    def includePackages = []
    def excludePackages = []
//  ['com.jakewharton.rxbinding.view.ViewClickOnSubscribe' ,'com.facebook.react.uimanager.NativeViewHierarchyManager','butterknife.internal.DebouncingOnClickListener']
    boolean debug = false
}
