#!/usr/bin/env bash

gradlew clean assembleRelease bintrayUpload -PbintrayUser=wusanm -PbintrayKey=bf075598cbafbe7a01f453fa6c87c0669f010abd -PdryRun=false

gradlew build --refresh-dependencies

gradlew -q app:dependencies >1.txt