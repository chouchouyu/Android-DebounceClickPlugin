package com.cm.android.infors.demo.liba_datapick;

/**
 * Author :xishuang
 * Date :${Date}
 * Des :
 */
public interface Counter3 {

    void count();
}
