package com.cm.android.infors.demo;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class SuccessCouponDailog extends Dialog {


    Button button;

    public SuccessCouponDailog(Context context) {
        super(context);
    }


    public SuccessCouponDailog(Context context, int theme) {
        super(context, theme);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setCancelable(false);  // 是否可以撤销
        setContentView(R.layout.dialog_custom);

        button = findViewById(R.id.btn_register_success);
    }

    public void setOnButtonClickListener(View.OnClickListener clickListener) {
        button.setOnClickListener(clickListener);
    }

}