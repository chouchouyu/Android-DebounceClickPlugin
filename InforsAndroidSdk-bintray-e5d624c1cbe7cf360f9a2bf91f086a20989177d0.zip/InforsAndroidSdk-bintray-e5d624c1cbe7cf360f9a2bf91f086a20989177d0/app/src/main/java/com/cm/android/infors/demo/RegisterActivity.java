package com.cm.android.infors.demo;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

import com.cm.android.infors.Infors;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class RegisterActivity extends AppCompatActivity {

    @BindView(R.id.progress)
    ProgressBar progress;
    @BindView(R.id.tv_username)
    AutoCompleteTextView tvUsername;
    @BindView(R.id.et_verification_code)
    EditText etVerificationCode;
    @BindView(R.id.et_set_password)
    EditText etSetPassword;
    @BindView(R.id.et_password_confirm)
    EditText etPasswordConfirm;
    @BindView(R.id.btn_register)
    Button btnRegister;

    SuccessCouponDailog dailog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        ButterKnife.bind(this);
    }

    @OnClick(R.id.btn_register)
    public void onViewClicked() {

        progress.setVisibility(View.VISIBLE);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                //显示dialog
                progress.setVisibility(View.GONE);

                dailog = new SuccessCouponDailog(RegisterActivity.this);
                dailog.show();
                dailog.setOnButtonClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
//                        Infors.getInstance().login("UserIdDemo1");
                        Intent intent = new Intent(RegisterActivity.this, CouponActivity.class);
                        intent.putExtra("isLogin", true);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    }
                });
            }
        }, 1000);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dailog != null) {
            dailog.dismiss();
        }
    }
}
