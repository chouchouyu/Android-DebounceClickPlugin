package com.cm.android.infors.demo.liba_datapick;

import android.view.View;


/**
 * Created by xishuang on 2018/1/6.
 */

public class Counter2 implements Counter3 {

    public void test() throws InterruptedException {
    }

    @AutoTrackDataViewOnClick
    public void test2(View view) throws InterruptedException {
    }

    @Override
    public void count() {

    }
}
