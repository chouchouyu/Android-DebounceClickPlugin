package com.cm.android.infors.core;

import android.app.Activity;
import android.app.Application;
import android.content.SharedPreferences;
import com.cm.android.infors.apm.trace.hacker.Hacker;
import com.cm.android.infors.core.events.ActivityTracker;
import com.cm.android.infors.core.plugin.Plugin;
import com.cm.android.infors.core.plugin.PluginListener;
import com.cm.android.infors.core.report.Issue;
import com.cm.android.infors.core.events.ProcessMonitor;
import com.cm.android.infors.core.report.Upload;
import com.cm.android.infors.request.modal.UserInfo;
import com.cm.android.infors.utils.DeviceUtils;
import com.cm.android.infors.utils.InforsUtil;
import com.cm.android.infors.utils.PrefUtils;
import com.cm.android.infors.utils.SharedPreferencesFactory;
import com.cm.android.infors.vieweditor.IViewEditor;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.util.*;

import static com.cm.android.infors.core.Consts.*;
import static com.cm.android.infors.utils.PrefUtils.*;

/**
 * 最初始的Plugin，采集基础数据
 * closeAutoTrace开关会影响部分数据的采集
 *
 * @author wusm
 */
public class InitialPlugin extends Plugin implements IViewEditor.OnSuccess, ProcessMonitor.Listener, ActivityTracker.Listener {
    private static final String TAG = "Infors.InitialPlugin";
    private final Upload upload;
    private InforsConfig mConfig;

    private ActivityTracker activityTracker = ActivityTracker.get();
    private ProcessMonitor processMonitor;

    public InitialPlugin(InforsConfig config, Upload upload, ProcessMonitor processMonitor) {
        mConfig = config;
        this.upload = upload;
        this.processMonitor = processMonitor;
    }

    @Override
    public void init(Application app, PluginListener listener, SDKSwitchHandler dynamicConfig) {
        super.init(app, listener, dynamicConfig);
        upload.getConfigInfo(app, mConfig, this);

    }

    @Override
    public void start() {
        super.start();
        if (!isSupported()) {
            return;
        }
        reportLaunchEvent();
        reportDevice();

        activityTracker.registerListener(this);
        processMonitor.registerListener(this);

    }


    @Override
    public void stop() {
        super.stop();
        if (!isSupported()) {
            return;
        }
        processMonitor.unregisterListener(this);
        activityTracker.registerListener(this);
    }

    @Override
    public void destroy() {
        super.destroy();

    }

    public static String getTAG() {
        return InitialPlugin.TAG;
    }

    public void reportUserInfo(UserInfo userInfo) {
        UserInfo user;
        if (null == userInfo) {
            removeSpUserId();
            return;
        } else {
            user = userInfo;
        }
        saveToSP(user.getUserid());
        Gson gson = new Gson();
        JsonObject userObj = gson.fromJson(gson.toJson(user), JsonObject.class);
        userObj.addProperty(ReportField.telephonyInfo.name(), DeviceUtils.getInstance(getApplication()).operatorToCarrier());
        userObj.addProperty(ReportField.osVersion.name(), InforsUtil.getOSVersion(getApplication()));
        userObj.addProperty(ReportField.deviceId.name(), mConfig.getDeviceId(getApplication()));
        userObj.addProperty(ReportField.vid.name(), TYPE_USER);
        userObj.addProperty(ReportField.describe.name(), TYPE_USER);

        Issue issue = new Issue(TYPE_USER, userObj, this);
        this.onDetectIssue(issue);
    }

    private void saveToSP(String userid) {
        saveStringSP(getApplication(), mConfig, Consts.SP_USERINFO, userid);
    }

    private void removeSpUserId() {
        SharedPreferencesFactory sharedPreferencesFactory = new SharedPreferencesFactory(getApplication(),
                mConfig);
        SharedPreferences prefs = sharedPreferencesFactory.create();
        PrefUtils.remove(prefs, Consts.SP_USERINFO);
    }

//    public void reportTraceEvent(String vid, String describe, Map<String, String>
//            property) {
//        Map<String, Object> map = new HashMap<String, Object>();
//        for (String key : property.keySet()) {
//            map.put(key, property.get(key));
//        }
//        Issue issue = new Issue(TYPE_TRACK, vid, describe, map, this);
//        this.onDetectIssue(issue);
//    }


    public void reportTraceEvent(String vid, String describe, Map<String, String> property, String appkey) {
        Map<String, Object> map = new HashMap<String, Object>();
        for (String key : property.keySet()) {
            map.put(key, property.get(key));
        }

        Issue issue = new Issue(TYPE_TRACK, vid, describe, map, this, appkey);
        this.onDetectIssue(issue);
    }

//    private void setAppLaunchTime() {
//        mConfig.setAppLaunchTime(System.currentTimeMillis());
//    }


    private void reportLaunchEvent() {
        long timeStamp = Hacker.sApplicationCreateBeginTime;
        if (0 != timeStamp) {
            if (isNEWLaunch(timeStamp) && InforsUtil.isInMainProcess(this.getApplication())) {
                Map<String, Object> map = new HashMap<String, Object>();
                map.put(ReportField.localIP.name(), DeviceUtils.getInstance(getApplication()).getIPAddress());
                map.put(ReportField.timestamp.name(), timeStamp);
                map.put(ReportField.osVersion.name(), InforsUtil.getOSVersion(getApplication()));
                mConfig.setAppLaunchTime(this.getApplication(), timeStamp);
                InforsUtil.setConnection(getApplication(), false);
                Issue issue = new Issue(TYPE_LAUNCH, map, this);
                issue.setTimestamp(timeStamp);
                this.onDetectIssue(issue);
            }

        }

    }

    private void reportDevice() {
        if (InforsUtil.isInMainProcess(this.getApplication())) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put(ReportField.deviceType.name(), mConfig.getDeviceType(getApplication()));
            Issue issue = new Issue(TYPE_DEVICE, map, this);
            this.onDetectIssue(issue);
        }
    }

    @Override
    public void onSuccess(String response) {
        Logger.i(" cfg json ->  ", response);
        saveStringSP(getApplication(), mConfig, Consts.SP_PC_CFG, response);
    }


    @Override
    public void onActivityCreate(Activity activity) {

    }

    @Override
    public void onActivityStart(Activity activity) {

    }

    @Override
    public void onActivityResume(Activity activity) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ReportField.title.name(), activity.getTitle().toString());
        map.put(ReportField.pageId.name(), activity.getClass()
                .getCanonicalName());
        Issue issue = new Issue(TYPE_PAGEVIEW, activity.getClass().getCanonicalName(), activity.getClass().getCanonicalName(), map, this);
        onDetectIssue(issue);
    }

    @Override
    public void onActivityPause(Activity activity) {

    }

    @Override
    public void onActivityStop(Activity activity) {

    }

    @Override
    public void onActivityDestroyed(Activity activity) {

    }

    @Override
    public void onActivityForegroundToBackground(Activity activity) {
        if (!getDynamicConfig().isAutoTraceEnable()) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put(ReportField.lastActivity.name(), activity.getClass().getCanonicalName());
            Issue issue = new Issue(TYPE_PAGE_PAUSE, activity.getClass().getCanonicalName(), "onForegroundToBackground:" + activity.getClass().getSimpleName(), map, this);
            onDetectIssue(issue);
        }
        upload.uploadEvents(activity.getApplication());
    }

    @Override
    public void onActivityBackgroundToForeground(Activity activity) {
        saveLongSP(getApplication(), mConfig, SP_TO_BACKGROUND, System.currentTimeMillis());
        if (!getDynamicConfig().isAutoTraceEnable()) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put(ReportField.firstActivity.name(), activity.getClass().getCanonicalName());
            Issue issue = new Issue(TYPE_PAGE_RESUME, activity.getClass().getCanonicalName(), "onBackgroundToForeground:" + activity.getClass().getSimpleName(), map, this);
            onDetectIssue(issue);
        }
    }


    private boolean isNEWLaunch(long timeStamp) {
        Long saveTime = new Long(mConfig.getAppLaunchTime(this.getApplication()));
        Long currentTime = new Long(timeStamp);
        if (saveTime == currentTime) {
            return false;
        } else {
            return true;
        }
    }
}
