package com.cm.android.infors.runtime;

import android.annotation.TargetApi;
import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.os.Build;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.*;
import com.cm.android.infors.Infors;
import com.cm.android.infors.core.InforsConfig;
import com.cm.android.infors.R;
import com.cm.android.infors.core.Consts;
import com.cm.android.infors.utils.*;
import com.google.gson.JsonObject;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static com.cm.android.infors.utils.PrefUtils.getStringFromSP;

/**
 * 字节码插桩 Utils
 *
 * @author wusm
 */
public class AutoTrackUtils {

    /**
     * 获取 Activity 的 title
     *
     * @param activity Activity
     * @return Activity 的 title
     */
    public static String getActivityTitle(Activity activity) {
        try {
            if (activity != null) {
                try {
                    String activityTitle = null;
                    if (!TextUtils.isEmpty(activity.getTitle())) {
                        activityTitle = activity.getTitle().toString();
                    }

                    if (Build.VERSION.SDK_INT >= 11) {
                        String toolbarTitle = getToolbarTitle(activity);
                        if (!TextUtils.isEmpty(toolbarTitle)) {
                            activityTitle = toolbarTitle;
                        }
                    }

                    if (TextUtils.isEmpty(activityTitle)) {
                        PackageManager packageManager = activity.getPackageManager();
                        if (packageManager != null) {
                            ActivityInfo activityInfo = packageManager.getActivityInfo(activity.getComponentName(), 0);
                            if (activityInfo != null) {
                                if (!TextUtils.isEmpty(activityInfo.loadLabel(packageManager))) {
                                    activityTitle = activityInfo.loadLabel(packageManager).toString();
                                }
                            }
                        }
                    }

                    return activityTitle;
                } catch (Exception e) {
                    return null;
                }
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    @TargetApi(11)
    public static String getToolbarTitle(Activity activity) {
        try {
            ActionBar actionBar = activity.getActionBar();
            if (actionBar != null) {
                if (!TextUtils.isEmpty(actionBar.getTitle())) {
                    return actionBar.getTitle().toString();
                }
            } else {
                try {
                    Class<?> appCompatActivityClass = Class.forName("android.support.v7.app.AppCompatActivity");
                    if (appCompatActivityClass != null && appCompatActivityClass.isInstance(activity)) {
                        Method method = activity.getClass().getMethod("getSupportActionBar");
                        if (method != null) {
                            Object supportActionBar = method.invoke(activity);
                            if (supportActionBar != null) {
                                method = supportActionBar.getClass().getMethod("getTitle");
                                if (method != null) {
                                    CharSequence charSequence = (CharSequence) method.invoke(supportActionBar);
                                    if (charSequence != null) {
                                        return charSequence.toString();
                                    }
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    //ignored
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String traverseView(StringBuilder stringBuilder, ViewGroup root) {
        try {
            if (root == null) {
                return stringBuilder.toString();
            }

            final int childCount = root.getChildCount();
            for (int i = 0; i < childCount; ++i) {
                final View child = root.getChildAt(i);

                if (child.getVisibility() != View.VISIBLE) {
                    continue;
                }

                if (child instanceof ViewGroup) {
                    traverseView(stringBuilder, (ViewGroup) child);
                } else {
//                    if (isViewIgnored(child)) {
//                        continue;
//                    }

                    Class<?> switchCompatClass = null;
                    try {
                        switchCompatClass = Class.forName("android.support.v7.widget.SwitchCompat");
                    } catch (Exception e) {
                        //ignored
                    }

                    if (switchCompatClass == null) {
                        try {
                            switchCompatClass = Class.forName("androidx.appcompat.widget.SwitchCompat");
                        } catch (Exception e) {
                            //ignored
                        }
                    }

                    CharSequence viewText = null;
                    if (child instanceof CheckBox) {
                        CheckBox checkBox = (CheckBox) child;
                        viewText = checkBox.getText();
                    } else if (switchCompatClass != null && switchCompatClass.isInstance(child)) {
                        CompoundButton switchCompat = (CompoundButton) child;
                        Method method;
                        if (switchCompat.isChecked()) {
                            method = child.getClass().getMethod("getTextOn");
                        } else {
                            method = child.getClass().getMethod("getTextOff");
                        }
                        viewText = (String) method.invoke(child);
                    } else if (child instanceof RadioButton) {
                        RadioButton radioButton = (RadioButton) child;
                        viewText = radioButton.getText();
                    } else if (child instanceof ToggleButton) {
                        ToggleButton toggleButton = (ToggleButton) child;
                        boolean isChecked = toggleButton.isChecked();
                        if (isChecked) {
                            viewText = toggleButton.getTextOn();
                        } else {
                            viewText = toggleButton.getTextOff();
                        }
                    } else if (child instanceof Button) {
                        Button button = (Button) child;
                        viewText = button.getText();
                    } else if (child instanceof CheckedTextView) {
                        CheckedTextView textView = (CheckedTextView) child;
                        viewText = textView.getText();
                    } else if (child instanceof TextView) {
                        TextView textView = (TextView) child;
                        viewText = textView.getText();
                    } else if (child instanceof ImageView) {
                        ImageView imageView = (ImageView) child;
                        if (!TextUtils.isEmpty(imageView.getContentDescription())) {
                            viewText = imageView.getContentDescription().toString();
                        }
                    }

                    if (!TextUtils.isEmpty(viewText)) {
                        stringBuilder.append(viewText.toString());
                        stringBuilder.append("-");
                    }
                }
            }
            return stringBuilder.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return stringBuilder.toString();
        }
    }


    public static void getFragmentNameFromView(View view, Map<String, Object> properties) {
        try {
            if (view != null) {
                String fragmentName = (String) view.getTag(R.id.auto_track_tag_view_fragment_name);
                String fragmentName2 = (String) view.getTag(R.id.auto_track_tag_view_fragment_name2);
                if (!TextUtils.isEmpty(fragmentName2)) {
                    fragmentName = fragmentName2;
                }
                if (!TextUtils.isEmpty(fragmentName)) {
//                    String screenName = properties.optString(AopConstants.SCREEN_NAME);
                    if (!TextUtils.isEmpty(fragmentName)) {
//                        properties.addProperty(ReportField.fragmentName, new StringElement(fragmentName));
                    } else {
//                        properties.addProperty(ReportField.fragmentName, new StringElement(fragmentName));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


//    public static void getFragmentNameFromView(View view, JsonObject properties) {
//        try {
//            if (view != null) {
//                String fragmentName = (String) view.getTag(R.id.auto_track_tag_view_fragment_name);
//                String fragmentName2 = (String) view.getTag(R.id.auto_track_tag_view_fragment_name2);
//                if (!TextUtils.isEmpty(fragmentName2)) {
//                    fragmentName = fragmentName2;
//                }
//                if (!TextUtils.isEmpty(fragmentName)) {
//                    String screenName = properties.optString(AopConstants.SCREEN_NAME);
//                    if (!TextUtils.isEmpty(fragmentName)) {
//                        properties.addProperty(AopConstants.SCREEN_NAME, String.format(Locale.CHINA, "%s|%s", screenName, fragmentName));
//                    } else {
//                        properties.addProperty(AopConstants.SCREEN_NAME, fragmentName);
//                    }
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

    public static Activity getActivityFromContext(Context context, View view) {
        Activity activity = null;
        try {
            if (context != null) {
                if (context instanceof Activity) {
                    activity = (Activity) context;
                } else if (context instanceof ContextWrapper) {
                    while (!(context instanceof Activity) && context instanceof ContextWrapper) {
                        context = ((ContextWrapper) context).getBaseContext();
                    }
                    if (context instanceof Activity) {
                        activity = (Activity) context;
                    }
                } else {
                    if (view != null) {
                        Object object = view.getTag(R.id.auto_track_tag_view_activity);
                        if (object != null) {
                            if (object instanceof Activity) {
                                activity = (Activity) object;
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return activity;
    }

    public static void addViewPathProperties(Activity activity, View view, JsonObject properties) {
        try {
//            if (!SensorsDataAPI.sharedInstance().isHeatMapEnabled()) {
//                return;
//            }

//            if (activity != null) {
//                if (!SensorsDataAPI.sharedInstance().isHeatMapActivity(activity.getClass())) {
//                    return;
//                }
//            }
            if (view == null) {
                return;
            }

            if (properties == null) {
                properties = new JsonObject();
            }

            ViewParent viewParent;
            List<String> viewPath = new ArrayList<>();
            do {
                viewParent = view.getParent();
                int index = getChildIndex(viewParent, view);
//                String idString2 = AopUtil.getViewId(view);
//                if (TextUtils.isEmpty(idString2)) {
//                    viewPath.add(view.getClass().getCanonicalName() + "[" + index + "]");
//                } else {
//                    viewPath.add(view.getClass().getCanonicalName() + "[" + idString2 + "]");
//                }
                viewPath.add(view.getClass().getCanonicalName() + "[" + index + "]");
                if (viewParent instanceof ViewGroup) {
                    view = (ViewGroup) viewParent;
                }

            } while (viewParent instanceof ViewGroup);

            Collections.reverse(viewPath);
            StringBuilder stringBuffer = new StringBuilder();
            for (int i = 1; i < viewPath.size(); i++) {
                stringBuffer.append(viewPath.get(i));
                if (i != (viewPath.size() - 1)) {
                    stringBuffer.append("/");
                }
            }
            properties.addProperty("$element_selector", stringBuffer.toString());
        } catch (Exception e) {
            e.printStackTrace();
//            com.sensorsdata.analytics.android.sdk.SALog.printStackTrace(e);
        }
    }


//    public static void getFragmentNameFromView(View view, JsonObject properties) {
//        try {
//            if (view != null) {
//                String fragmentName = (String) view.getTag(R.id.auto_track_tag_view_fragment_name);
//                String fragmentName2 = (String) view.getTag(R.id.auto_track_tag_view_fragment_name2);
//                if (!TextUtils.isEmpty(fragmentName2)) {
//                    fragmentName = fragmentName2;
//                }
//                if (!TextUtils.isEmpty(fragmentName)) {
//                    String screenName = properties.optString(AopConstants.SCREEN_NAME);
//                    if (!TextUtils.isEmpty(fragmentName)) {
//                        properties.addProperty(AopConstants.SCREEN_NAME, String.format(Locale.CHINA, "%s|%s", screenName, fragmentName));
//                    } else {
//                        properties.addProperty(AopConstants.SCREEN_NAME, fragmentName);
//                    }
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }


    private static int getChildIndex(ViewParent parent, View child) {
        try {
            if (parent == null || !(parent instanceof ViewGroup)) {
                return -1;
            }

            ViewGroup viewParent = (ViewGroup) parent;
            final String childIdName = getViewId(child);

            String childClassName = child.getClass().getCanonicalName();
            int index = 0;
            for (int i = 0; i < viewParent.getChildCount(); i++) {
                View brother = viewParent.getChildAt(i);

                if (!hasClassName(brother, childClassName)) {
                    continue;
                }

                String brotherIdName = getViewId(brother);

                if (null != childIdName && !childIdName.equals(brotherIdName)) {
                    index++;
                    continue;
                }

                if (brother == child) {
                    return index;
                }

                index++;
            }

            return -1;
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }

    public static String getViewId(View view) {
        String idString = null;
        try {
            idString = (String) view.getTag(R.id.auto_track_tag_view_id);
            if (TextUtils.isEmpty(idString)) {
                if (view.getId() != View.NO_ID) {
                    idString = view.getContext().getResources().getResourceEntryName(view.getId());
                }
            }
        } catch (Exception e) {
            //ignore
        }
        return idString;
    }


    public static boolean hasClassName(Object o, String className) {
        Class<?> klass = o.getClass();
        while (klass.getCanonicalName() != null) {
            if (klass.getCanonicalName().equals(className)) {
                return true;
            }

            if (klass == Object.class) {
                break;
            }

            klass = klass.getSuperclass();
        }
        return false;
    }


    /**
     * 得到json文件中的内容
     *
     * @return
     */
//    public static String getCfgJsonStr() {
//        StringBuilder stringBuilder = new StringBuilder();
//        //获得assets资源管理器
//        AssetManager assetManager = Infors.getInstance().getAppContext().getAssets();
//        //使用IO流读取json文件内容
//        try {
//            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(
//                    assetManager.open(jsonFileName), "utf-8"));
//            String line;
//            while ((line = bufferedReader.readLine()) != null) {
//                stringBuilder.append(line);
//            }
//            bufferedReader.close();
//        } catch (IOException e) {
//            Logger.e("cfg -> get " + jsonFileName + " fail : " + e.getMessage());
//            e.printStackTrace();
//        }
//        return stringBuilder.toString();
//    }

    /**
     * 判断是否是支持的采集view类型
     *
     * @param view
     * @return
     */
    public static boolean configableOfView(View view) {
        Class clazz = view.getClass();
        if (Button.class.isAssignableFrom(clazz)
                || Spinner.class.isAssignableFrom(clazz)
                || SeekBar.class.isAssignableFrom(clazz)
                || RatingBar.class.isAssignableFrom(clazz)
                || ImageView.class.isAssignableFrom(clazz)
                || TextView.class.isAssignableFrom(clazz)
                || CheckedTextView.class.isAssignableFrom(clazz)
                || Button.class.isAssignableFrom(clazz)
                || ToggleButton.class.isAssignableFrom(clazz)
                || RadioButton.class.isAssignableFrom(clazz)
                || CheckBox.class.isAssignableFrom(clazz)
                || RadioGroup.class.isAssignableFrom(clazz)
        ) {
            return true;
        } else {
            return false;
        }
    }

    public static int getId(Activity activity, View view) {
        int viewId = 0;
        if (activity == null) {

            return viewId;
        }

        Class<? extends Activity> clz = activity.getClass();

        Field[] fs = clz.getDeclaredFields();
        Resources res = activity.getResources();
        String packageName = activity.getPackageName();
        for (Field field : fs) {

            if (!View.class.isAssignableFrom(field.getType())) {
                continue;
            }

            StringBuffer sb = viewIdFormat(field);

            int resId = res.getIdentifier(sb.toString(), "id", packageName);

            if (resId == 0) {
                continue;
            }
            field.setAccessible(true);
            View v = activity.findViewById(resId);
            if (v == view) {
                viewId = resId;
            }
        }
        return viewId;
    }

    @NonNull
    private static StringBuffer viewIdFormat(Field field) {
        StringBuffer sb = new StringBuffer();
        char[] fieldArray = field.getName().toCharArray();
        for (char c : fieldArray) {
            if ((char) c >= 'A' && (char) c <= 'Z') {
                sb.append("_").append((c + "").toLowerCase());
            } else {
                sb.append(c);
            }
        }
        return sb;
    }


    public static String getCfgJsonStr() {
        return getStringFromSP(Infors.getInstance().getAppContext(), InforsConfig.getInstance(), Consts.SP_PC_CFG);
//        SharedPreferencesFactory sharedPreferencesFactory = new SharedPreferencesFactory(Infors.getInstance().getAppContext(),
//                InforsConfig.getInstance());
//        SharedPreferences prefs = sharedPreferencesFactory.create();
//        return prefs.getString(Consts.SP_PC_CFG, "");
    }
}
