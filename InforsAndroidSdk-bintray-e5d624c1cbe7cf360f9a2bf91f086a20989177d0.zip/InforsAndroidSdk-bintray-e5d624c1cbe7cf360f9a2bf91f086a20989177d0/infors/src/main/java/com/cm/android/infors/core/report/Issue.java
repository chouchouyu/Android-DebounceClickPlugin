/*
 * Tencent is pleased to support the open source community by making wechat-matrix available.
 * Copyright (C) 2018 THL A29 Limited, a Tencent company. All rights reserved.
 * Licensed under the BSD 3-Clause License (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://opensource.org/licenses/BSD-3-Clause
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.cm.android.infors.core.report;

import android.support.annotation.NonNull;
import com.cm.android.infors.core.InitialPlugin;
import com.cm.android.infors.core.plugin.Plugin;
import com.cm.android.infors.core.ReportField;
import com.google.gson.JsonObject;

import java.util.Map;

/**
 * Data struct contains the issues
 * <p>
 *
 * @author wusm
 */

public class Issue {
    private String appkey;
    private JsonObject jsonObject;
    private Plugin plugin;
    private String type;
    private String describe;
    private String vid;
    private Map<String, Object> contentMap;
    private long timestamp;


    public Issue(@NonNull String type, @NonNull Map<String, Object> contentMap, @NonNull Plugin plugin) {
        this.type = type;
        this.describe = type;
        this.vid = type;
        this.plugin = plugin;
        if (plugin instanceof InitialPlugin) {
            contentMap.put(ReportField.vid.name(), getVid());
            contentMap.put(ReportField.describe.name(), getDescribe());
        }
        this.contentMap = contentMap;
        this.timestamp = System.currentTimeMillis();
    }


    public Issue(@NonNull String type, @NonNull String vid, @NonNull String describe, @NonNull Map<String, Object> contentMap, @NonNull Plugin plugin) {
        this(type, vid, describe, contentMap, plugin, null);
    }

    public Issue(@NonNull String type, @NonNull String vid, @NonNull String describe, @NonNull Map<String, Object> contentMap, @NonNull Plugin plugin, String appkey) {
        this.type = type;
        this.describe = describe;
        this.vid = vid;
        this.plugin = plugin;
        contentMap.put(ReportField.vid.name(), getVid());
        contentMap.put(ReportField.describe.name(), getDescribe());
        this.contentMap = contentMap;
        this.timestamp = System.currentTimeMillis();
        this.appkey = appkey;
    }

    public Issue(String type, JsonObject jsonObject, Plugin plugin) {
        this.type = type;
        this.plugin = plugin;
        this.jsonObject = jsonObject;
        this.timestamp = System.currentTimeMillis();
    }

    public String getAppkey() {
        return appkey;
    }

    public void setAppkey(String appkey) {
        this.appkey = appkey;
    }

    public Plugin getPlugin() {
        return plugin;
    }

    public void setPlugin(Plugin plugin) {
        this.plugin = plugin;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


    public String getDescribe() {
        return describe;
    }

    public void setDescribe(String describe) {
        this.describe = describe;
    }


    public String getVid() {
        return vid;
    }

    public void setVid(String vid) {
        this.vid = vid;
    }


    public Map<String, Object> getContentMap() {
        return contentMap;
    }

    public void setContentMap(Map<String, Object> contentMap) {
        this.contentMap = contentMap;
    }

    public JsonObject getJsonObject() {
        return jsonObject;
    }

    public void setJsonObject(JsonObject jsonObject) {
        this.jsonObject = jsonObject;
    }

    @Override
    public String toString() {
        return "Issue{" +
                "appkey='" + appkey + '\'' +
                ", jsonObject=" + jsonObject +
                ", plugin=" + plugin +
                ", type='" + type + '\'' +
                ", describe='" + describe + '\'' +
                ", vid='" + vid + '\'' +
                ", contentMap=" + contentMap +
                ", timestamp=" + timestamp +
                '}';
    }
}
