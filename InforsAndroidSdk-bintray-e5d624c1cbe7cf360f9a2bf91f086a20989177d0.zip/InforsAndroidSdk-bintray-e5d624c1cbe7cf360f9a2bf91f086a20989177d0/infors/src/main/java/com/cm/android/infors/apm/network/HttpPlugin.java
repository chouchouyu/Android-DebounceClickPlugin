package com.cm.android.infors.apm.network;

import android.app.Application;
import com.cm.android.infors.core.SDKSwitchHandler;
import com.cm.android.infors.core.plugin.Plugin;
import com.cm.android.infors.core.plugin.PluginListener;

/**
 * 网络请求事件采集插件
 *
 * @author wusm
 */
public class HttpPlugin extends Plugin {
    private static final String TAG = "Infors.HttpPlugin";

    @Override
    public void init(Application app, PluginListener listener, SDKSwitchHandler dynamicConfig) {
        super.init(app, listener, dynamicConfig);
        if (!getDynamicConfig().isHttpEnable()
                || !dynamicConfig.isAutoTraceEnable()) {
            unSupportPlugin();
            return;
        }
    }

    @Override
    public void start() {
        super.start();
        if (!isSupported()) {
            return;
        }
    }

    @Override
    public void stop() {
        super.stop();
        if (!isSupported()) {
            return;
        }
    }

    @Override
    public void destroy() {
        super.destroy();
    }

    public static String getTAG() {
        return HttpPlugin.TAG;
    }


}
