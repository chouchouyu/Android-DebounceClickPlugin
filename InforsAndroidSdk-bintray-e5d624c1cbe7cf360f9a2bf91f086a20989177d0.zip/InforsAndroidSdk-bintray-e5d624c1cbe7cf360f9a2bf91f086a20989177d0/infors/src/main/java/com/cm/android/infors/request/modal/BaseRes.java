package com.cm.android.infors.request.modal;

/**
 * 网络请求基础response
 * @author wusm
 */

public class BaseRes {

    /**
     * body : 测试内容7kto
     * code : 测试内容tq2q
     * message : 测试内容9472
     */

    private String body;
    private String code;
    private String message;

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
