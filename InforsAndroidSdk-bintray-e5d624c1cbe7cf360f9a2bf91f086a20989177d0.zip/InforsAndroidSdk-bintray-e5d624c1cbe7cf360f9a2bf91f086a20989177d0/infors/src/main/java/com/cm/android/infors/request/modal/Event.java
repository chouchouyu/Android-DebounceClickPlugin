package com.cm.android.infors.request.modal;

import java.io.Serializable;
import java.util.Map;


/**
 * @author caijp001
 */
public class Event implements Serializable {

    private static final long serialVersionUID = 6653355158452958558L;
    private String eventType;

    private String eventId;

    private String preEventId;

    private Long timestamp;

    private String sdkVersion;

    private String appKey;

    private String deviceId;

    private String sessionId;

    private String platform;

    private String userId;

    private String appVersion;

    private Map<String, Object> data;


    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getPreEventId() {
        return preEventId;
    }

    public void setPreEventId(String preEventId) {
        this.preEventId = preEventId;
    }

    public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }

    public String getSdkVersion() {
        return sdkVersion;
    }

    public void setSdkVersion(String sdkVersion) {
        this.sdkVersion = sdkVersion;
    }

    public String getAppKey() {
        return appKey;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public void setAppVersion(String appVersion) {
        this.appVersion = appVersion;
    }

    public Map<String, Object> getData() {
        return data;
    }

    public void setData(Map<String, Object> data) {
        this.data = data;
    }
}
