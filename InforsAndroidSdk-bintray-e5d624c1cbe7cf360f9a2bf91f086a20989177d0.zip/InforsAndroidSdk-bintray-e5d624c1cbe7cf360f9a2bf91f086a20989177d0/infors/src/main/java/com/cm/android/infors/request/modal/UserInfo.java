package com.cm.android.infors.request.modal;

import android.support.annotation.StringDef;
import com.cm.android.infors.core.InforsConfig;
import com.cm.android.infors.core.ReportField;

import java.lang.annotation.*;
import java.util.HashMap;
import java.util.Map;


/**
 * 用户信息
 *
 * @author wusm
 */

public class UserInfo {


    private String userid;
    private String username;
    private String gender;
    private int age;

    @Documented // 表示开启Doc文档
    @StringDef({
            "男",
            "女"
    }) //限定为MAN,WOMEN
    @Target({
            ElementType.PARAMETER,
            ElementType.FIELD,
            ElementType.METHOD,
    }) //表示注解作用范围，参数注解，成员注解，方法注解
    @Retention(RetentionPolicy.SOURCE) //表示注解所存活的时间,在运行时,而不会存在 .class 文件中
    public @interface Sex {
    }


    private String province;
    private String city;

    private String channel;


    public UserInfo(String userid, String username) {
        this.userid = userid;
        this.username = username;
    }


    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
        Map<String, String> map = InforsConfig.getInstance().getGlobalParams();
        if (null == map) {
            map = new HashMap<>();
        }
        map.put(ReportField.channel.name(), channel);
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getUserName() {
        return username;
    }

    public void setUserName(String username) {
        this.username = username;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(@Sex String gender) {
        this.gender = gender;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }


    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    @Override
    public String toString() {
        return "UserInfo{" +
                "userid='" + userid + '\'' +
                ", username='" + username + '\'' +
                ", gender='" + gender + '\'' +
                ", age=" + age +
                ", province='" + province + '\'' +
                ", city='" + city + '\'' +
                ", channel='" + channel + '\'' +
                '}';
    }
}