package com.cm.android.infors.db;

import android.arch.persistence.room.*;

import java.util.Date;

import static com.cm.android.infors.core.Consts.TABLE_APM;

@Entity(tableName = TABLE_APM,
        indices = {@Index(value = {"DATE"},
                unique = false)})
public class APMEventEntity {

    @PrimaryKey(autoGenerate = true)
    private int id;

    //    private int productId;
    @ColumnInfo(name = "CONTENT")
    private String content;

    @ColumnInfo(name = "EVENT_TYPE")
    private String eventType;

    @ColumnInfo(name = "DATE")
    private Date time;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public APMEventEntity() {
    }

    @Ignore
    public APMEventEntity(String content, String eventType, Date time) {
        this.content = content;
        this.eventType = eventType;
        this.time = time;
    }

    @Override
    public String toString() {
        return "EventEntity{" +
                "id=" + id +
                ", content='" + content + '\'' +
                ", eventType='" + eventType + '\'' +
                ", time=" + time +
                '}';
    }
}
