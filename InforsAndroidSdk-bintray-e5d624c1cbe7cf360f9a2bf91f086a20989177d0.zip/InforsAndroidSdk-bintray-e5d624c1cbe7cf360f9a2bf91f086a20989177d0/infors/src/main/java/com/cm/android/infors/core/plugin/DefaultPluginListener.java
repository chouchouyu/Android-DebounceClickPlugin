/*
 * Tencent is pleased to support the open source community by making wechat-matrix available.
 * Copyright (C) 2018 THL A29 Limited, a Tencent company. All rights reserved.
 * Licensed under the BSD 3-Clause License (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://opensource.org/licenses/BSD-3-Clause
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.cm.android.infors.core.plugin;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import com.cm.android.infors.apm.crash.CrashPlugin;
import com.cm.android.infors.apm.network.HttpPlugin;
import com.cm.android.infors.apm.trace.TracePlugin;
import com.cm.android.infors.core.*;
import com.cm.android.infors.core.report.Issue;
import com.cm.android.infors.db.APMEventEntity;
import com.cm.android.infors.db.EventEntity;
import com.cm.android.infors.db.InforsDatabase;
import com.cm.android.infors.utils.EncryptData;
import com.cm.android.infors.utils.InforsUtil;
import com.cm.android.infors.utils.SharedPreferencesFactory;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.util.Date;
import java.util.Map;
import java.util.concurrent.ThreadPoolExecutor;

import static com.cm.android.infors.core.Consts.*;
import static com.cm.android.infors.utils.EncryptData.Base64Encode;
import static com.cm.android.infors.utils.PrefUtils.*;

/**
 * @author wusm
 */

public class DefaultPluginListener implements PluginListener {
    private static final String TAG = "Infors.DefaultPluginListener";

    private final Context context;
    private final ThreadPoolExecutor executor;

    private InforsConfig config;

    public DefaultPluginListener(Context context, InforsConfig config, ThreadPoolExecutor tpe) {
        this.context = context;
        this.config = config;
        this.executor = tpe;
    }

    @Override
    public void onInit(Plugin plugin) {
        Logger.i(TAG, "%s plugin is inited", plugin.getTag());
    }

    @Override
    public void onStart(Plugin plugin) {
        Logger.i(TAG, "%s plugin is started", plugin.getTag());
    }

    @Override
    public void onStop(Plugin plugin) {
        Logger.i(TAG, "%s plugin is stopped", plugin.getTag());
    }

    @Override
    public void onDestroy(Plugin plugin) {
        Logger.i(TAG, "%s plugin is destroyed", plugin.getTag());
    }

    @Override
    public void onReportIssue(Issue issue) {
        String eventType = null;
        JsonObject jsonObject = null;

        if (issue.getPlugin() instanceof InitialPlugin) {
            eventType = issue.getType();
            if (null != issue.getJsonObject() && TextUtils.equals(issue.getType(), TYPE_JS)) {
                jsonObject = issue.getJsonObject();


            } else {
                jsonObject = new JsonObject();
                if (null != issue.getJsonObject() && TextUtils.equals(issue.getType(), TYPE_USER)) {
                    JsonObject userJson = issue.getJsonObject();

                    if (config.getGlobalParams() != null
                            && config.getGlobalParams().size() > 0) {
                        Map<String, String> globalParams = config.getGlobalParams();
                        for (String key : globalParams.keySet()) {
                            userJson.addProperty(key, globalParams.get(key));
                        }
                    }

                    jsonObject.add("data", userJson);


                } else {
                    Map<String, Object> map = issue.getContentMap();

                    if (config.getGlobalParams() != null
                            && config.getGlobalParams().size() > 0) {
                        Map<String, String> globalParams = config.getGlobalParams();
                        for (String key : globalParams.keySet()) {
//                            jsonObject.addProperty(key, globalParams.get(key));
                            map.put(key, globalParams.get(key));
                        }
                    }

                    jsonObject.add("data", InforsUtil.mapToJson(map));
                }
                String eventId = getMD5EventId(issue);
                jsonObject.addProperty(ReportField.eventId.name(), eventId);
                jsonObject.addProperty(ReportField.eventType.name(), issue.getType());
                jsonObject.addProperty(ReportField.timestamp.name(), issue.getTimestamp());
                jsonObject.addProperty(ReportField.appKey.name(), getAppKey(issue));
                jsonObject.addProperty(ReportField.sessionId.name(), getSessionId(issue));
                jsonObject.addProperty(ReportField.deviceId.name(), config.getDeviceId(context));
                jsonObject.addProperty(ReportField.sdkVersion.name(), SDK_VERSION);
                jsonObject.addProperty(ReportField.appVersion.name(), config.getAppVersionName(context));
                if (!TextUtils.isEmpty(InforsUtil.getUserId(context))) {
                    jsonObject.addProperty(ReportField.userId.name(), InforsUtil.getUserId(context));
                }
                jsonObject.addProperty(ReportField.platform.name(), PLATFORM);
                eventIdHandler(eventId);
                jsonObject.addProperty(ReportField.preEventId.name(), previousEventId);

            }

        }

        if (isAPMPlugin(issue.getPlugin())) {
            JsonObject eventObj = new JsonObject();
            Map<String, Object> map = issue.getContentMap();
            eventObj.add(issue.getType(), InforsUtil.mapToJson(map));
            eventType = issue.getType();
            jsonObject = eventObj;
        }

        if (!TextUtils.isEmpty(eventType) && null != jsonObject) {
            saveToDB(eventType, jsonObject, issue.getPlugin());
        }

    }

    private boolean isAPMPlugin(Plugin plugin) {
        if (plugin instanceof CrashPlugin || plugin instanceof HttpPlugin || plugin instanceof TracePlugin) {
            return true;
        } else {
            return false;
        }
    }

    private void saveToDB(final String type, JsonObject eventObj, final Plugin plugin) {
        Logger.i(TAG, "日志 ->" + eventObj.toString());
        final String json = new Gson().toJson(eventObj);

        executor.execute(new Runnable() {
            @Override
            public void run() {
                if (isAPMPlugin(plugin)) {
                    APMEventEntity eventEntity = new APMEventEntity();
                    eventEntity.setTime(new Date(System.currentTimeMillis()));
                    eventEntity.setContent(Base64Encode(json));
                    eventEntity.setEventType(type);
                    InforsDatabase.getInstance(context).apmEventDao().insert(eventEntity);
                } else {
                    EventEntity eventEntity = new EventEntity();
                    eventEntity.setTime(new Date(System.currentTimeMillis()));
                    eventEntity.setContent(Base64Encode(json));
                    eventEntity.setEventType(type);
                    InforsDatabase.getInstance(context).eventDao().insert(eventEntity);
                }
            }
        });
    }


    /**
     * eventId 规则 （deviceId + 13位时间戳 + 3位随机数）32bit_md5
     */
    private String getMD5EventId(Issue issue) {
        int randomNum = 100 + (int) (Math.random() * 900);
        StringBuffer sb = new StringBuffer();
        sb.append(config.getDeviceId(context)).append(issue.getTimestamp()).append(randomNum);
        return EncryptData.getMD5(sb.toString());
    }

    private String getAppKey(Issue issue) {
        if (issue.getAppkey() == null) {
            return config.getAppKey();
        } else {
            return issue.getAppkey();
        }
    }

    String previousEventId;
    String eventId;

    private void eventIdHandler(String eventId) {
        this.previousEventId = this.eventId;
        this.eventId = eventId;
    }

    private Boolean shouldGenerateNewSessionId() {
        SharedPreferencesFactory sharedPreferencesFactory = new SharedPreferencesFactory(context,
                config);
        SharedPreferences sharedPreferences = sharedPreferencesFactory.create();
        if (sharedPreferences.contains(SP_TO_BACKGROUND)) {
            Long oldTimeStampe = getLongFromSP(context, config, SP_TO_BACKGROUND);
            if (System.currentTimeMillis() - oldTimeStampe > 3000 * 60) {
                return true;
            } else {
                return false;
            }
        } else {
            return true;
        }

    }

    /**
     * 启动时的13位时间戳字符串+productId + deviceId + userId(如果存在)）32bit_MD5
     *
     * @return
     */
    private String getSessionId(Issue issue) {
        if (shouldGenerateNewSessionId()) {
            StringBuffer rawSessionIdSB;
            rawSessionIdSB = new StringBuffer();
            rawSessionIdSB = rawSessionIdSB.append(config.getAppLaunchTime(context)).append
                    (getAppKey(issue)).append(config.getDeviceId(context)).append(InforsUtil.getUserId(context)).append(getLongFromSP(context, config, SP_TO_BACKGROUND));
            String sessionId = EncryptData.getMD5(rawSessionIdSB.toString());
            saveStringSP(context, config, Consts.SP_SESSIONID, sessionId);
            return sessionId;
        } else {
            return getStringFromSP(context, config, SP_SESSIONID);
        }

    }
}
