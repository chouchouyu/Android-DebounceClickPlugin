package com.cm.android.infors.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.support.annotation.NonNull;
import com.cm.android.infors.core.InforsConfig;

/**
 * @author wusm
 */
public final class PrefUtils {

    public static void saveStringSP(@NonNull Context context, InforsConfig config, String key, String content) {
        SharedPreferencesFactory sharedPreferencesFactory = new SharedPreferencesFactory(context,
                config);
        SharedPreferences prefs = sharedPreferencesFactory.create();
        saveString(prefs, key, content);
    }


    public static void saveBooleanSP(@NonNull Context context, InforsConfig config, String key, Boolean flag) {
        SharedPreferencesFactory sharedPreferencesFactory = new SharedPreferencesFactory(context,
                config);
        SharedPreferences prefs = sharedPreferencesFactory.create();
        saveBoolean(prefs, key, flag);
    }

    public static String getStringFromSP(@NonNull Context context, InforsConfig config, String key) {
        SharedPreferencesFactory sharedPreferencesFactory = new SharedPreferencesFactory(context,
                config);
        SharedPreferences prefs = sharedPreferencesFactory.create();
        return prefs.getString(key, "");
    }


    public static boolean getBooleanFromSP(@NonNull Context context, InforsConfig config, String key) {
        SharedPreferencesFactory sharedPreferencesFactory = new SharedPreferencesFactory(context,
                config);
        SharedPreferences prefs = sharedPreferencesFactory.create();
        return prefs.getBoolean(key, true);
    }


    public static Long getLongFromSP(@NonNull Context context, InforsConfig config, String key) {
        SharedPreferencesFactory sharedPreferencesFactory = new SharedPreferencesFactory(context,
                config);
        SharedPreferences prefs = sharedPreferencesFactory.create();
        return prefs.getLong(key, 0);
    }


    public static void saveLongSP(@NonNull Context context, InforsConfig config, String key, Long flag) {
        SharedPreferencesFactory sharedPreferencesFactory = new SharedPreferencesFactory(context,
                config);
        SharedPreferences prefs = sharedPreferencesFactory.create();
        saveLong(prefs, key, flag);
    }


    private static String saveString(SharedPreferences prefs, String key, String
            value) {
        String saved_value = prefs.getString(key, "");
//        if (TextUtils.isEmpty(saved_value)) {
        final SharedPreferences.Editor prefEditor = prefs.edit();
        saved_value = value;
        prefEditor.putString(key, saved_value);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD) {
            prefEditor.apply();
        } else {
            prefEditor.commit();
        }
//        }
        return saved_value;
    }


    public static void remove(SharedPreferences prefs, String key) {
        final SharedPreferences.Editor prefEditor = prefs.edit();
        prefEditor.remove(key);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD) {
            prefEditor.apply();
        } else {
            prefEditor.commit();
        }
    }

    public static Boolean saveBoolean(SharedPreferences prefs, String key, Boolean
            value) {
        Boolean saved_value = prefs.getBoolean(key, true);
//        if (TextUtils.isEmpty(saved_value)) {
        final SharedPreferences.Editor prefEditor = prefs.edit();
        saved_value = value;

        prefEditor.putBoolean(key, saved_value);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD) {
            prefEditor.apply();
        } else {
            prefEditor.commit();
        }
//        }
        return saved_value;
    }


    public static Long saveLong(SharedPreferences prefs, String key, Long
            value) {
        Long saved_value = prefs.getLong(key, 0);
//        if (TextUtils.isEmpty(saved_value)) {
        final SharedPreferences.Editor prefEditor = prefs.edit();
        saved_value = value;

        prefEditor.putLong(key, saved_value);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD) {
            prefEditor.apply();
        } else {
            prefEditor.commit();
        }
//        }
        return saved_value;
    }

}
