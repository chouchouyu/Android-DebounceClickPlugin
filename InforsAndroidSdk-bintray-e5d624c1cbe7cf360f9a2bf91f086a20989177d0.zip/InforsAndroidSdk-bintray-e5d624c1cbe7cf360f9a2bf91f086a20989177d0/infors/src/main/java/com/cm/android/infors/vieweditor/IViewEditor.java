package com.cm.android.infors.vieweditor;

public interface IViewEditor {
    interface WsHandle {
        void onDisconnect(Throwable throwable);

        void onOpen();

        void onSendMessageSuccess();
    }

    interface OnSuccess {
        void onSuccess(String response);
    }

    void send(String msg);

    void close();

    interface MessageType {
        String DEVICE = "deviceInfo";
        String PAGE = "pageInfo";
    }
}

