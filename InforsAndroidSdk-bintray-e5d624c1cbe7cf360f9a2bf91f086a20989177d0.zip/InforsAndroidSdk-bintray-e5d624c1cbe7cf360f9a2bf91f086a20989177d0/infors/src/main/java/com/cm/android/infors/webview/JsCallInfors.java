package com.cm.android.infors.webview;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.util.Log;
import android.webkit.JavascriptInterface;
import com.cm.android.infors.Infors;
import com.cm.android.infors.core.*;
import com.cm.android.infors.core.report.Issue;
import com.cm.android.infors.request.modal.Event;
import com.cm.android.infors.utils.InforsUtil;
import com.google.gson.Gson;
import com.google.gson.JsonObject;


import java.util.Map;

import static com.cm.android.infors.core.Consts.*;
import static com.cm.android.infors.utils.PrefUtils.saveStringSP;

/**
 * js调用原生
 *
 * @author susan
 */
public class JsCallInfors {

    public JsCallInfors(@NonNull Context context) {
    }

    @JavascriptInterface
    public void saveToInfors(@NonNull String msg) {

        InitialPlugin plugin = Infors.getInstance().getPluginByClass(InitialPlugin.class);

        if (plugin != null) {
            Context context = plugin.getApplication();
            Gson gson = new Gson();
            Event event = gson.fromJson(msg, Event.class);
            JsonObject jsonObject = gson.fromJson(msg, JsonObject.class);
            if (null != event.getEventType()) {
                jsonObject.addProperty(ReportField.eventType.name(), event.getEventType());

            }

            if (null != event.getEventId()) {
                jsonObject.addProperty(ReportField.eventId.name(), event.getEventId());
            }

            if (null != event.getTimestamp()) {
                jsonObject.addProperty(ReportField.timestamp.name(), event.getTimestamp());
            }
            if (null != event.getAppKey()) {
                jsonObject.addProperty(ReportField.appKey.name(), event.getAppKey());
            }
            if (null != event.getSessionId()) {
                jsonObject.addProperty(ReportField.sessionId.name(), event.getSessionId());
            }
            if (null != event.getPreEventId()) {
                jsonObject.addProperty(ReportField.preEventId.name(), event.getPreEventId());
            }

            jsonObject.addProperty(ReportField.platform.name(), Consts.PLATFORM);
            jsonObject.addProperty(ReportField.deviceId.name(), InforsConfig.getInstance().getDeviceId(context));
            jsonObject.addProperty(ReportField.sdkVersion.name(), SDK_VERSION);
            jsonObject.addProperty(ReportField.appVersion.name(), InforsConfig.getInstance().getAppVersionName(context));

            if (event.getData() != null) {
                Map<String, Object> datamap = event.getData();
                if (event.getEventType().contains(TYPE_USER)) {
                    if (datamap.containsKey("userId")) {
                        saveStringSP(context, InforsConfig.getInstance(), Consts.SP_USERINFO, (String) datamap.get("userId"));
                    }
                }
                if (InforsConfig.getInstance().getGlobalParams() != null
                        && InforsConfig.getInstance().getGlobalParams().size() > 0) {
                    Map<String, String> globalParams = InforsConfig.getInstance().getGlobalParams();
                    for (String key : globalParams.keySet()) {
                        datamap.put(key, globalParams.get(key));
                    }
                }
                jsonObject.add("data", InforsUtil.mapToJson(datamap));
            }

            if (!TextUtils.isEmpty(InforsUtil.getUserId(context))) {
                jsonObject.addProperty(ReportField.userId.name(), InforsUtil.getUserId(context));
            }

            Issue issue = new Issue(TYPE_JS, jsonObject, plugin);
            plugin.onDetectIssue(issue);
        }

    }

}
