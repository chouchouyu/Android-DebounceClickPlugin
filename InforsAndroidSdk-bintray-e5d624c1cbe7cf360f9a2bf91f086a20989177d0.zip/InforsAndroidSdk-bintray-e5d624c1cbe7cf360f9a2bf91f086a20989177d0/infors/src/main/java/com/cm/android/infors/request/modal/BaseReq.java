package com.cm.android.infors.request.modal;

import java.util.List;

/**
 * 网络请求基础Request
 * @author wusm
 */

public class BaseReq {


    private List<EventsBean> events;

    public List<EventsBean> getEvents() {
        return events;
    }

    public void setEvents(List<EventsBean> events) {
        this.events = events;
    }

    public static class EventsBean {
        /**
         * event : {"eventId":"tutu","eventType":"pageView","sdkVersion":"1.0","appVersion":"1.0","userId":"testuser4","preEventId":"default","timestamp":1527048732000,"deviceId":"wangq001 - mac", "platform" : "web","sessionId":"awdsfwwcdd","product":"infors_web","data":{"vid":"awdwcefdsd","describe":"click","launchTime":132456465, "closeTime":223212344}}
         */

        private String event;

        public String getEvent() {
            return event;
        }

        public void setEvent(String event) {
            this.event = event;
        }
    }
}
