package com.cm.android.infors.request.modal;

import java.io.Serializable;
import java.util.List;

/**
 * 可视化，后台下发的配置结构
 * @author wusm
 */
public class ViewConfigRes {


    /**
     * code : Y
     * body : {"cfg":[{"xpath":"ScrollView/LinearLayout/AppCompatTextView",
     * "pageName":"MainActivity","option":{"vid":"ecacc695e3264e6faeee22646f422b98","top":37,
     * "left":83,"width":57,"controlId":"0","describe":"hello","type":"android.support.v7.widget
     * .AppCompatTextView","controlIndex":2,"height":14}}]}
     * message : null
     */

    private String code;
    private BodyBean body;
    private Object message;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public BodyBean getBody() {
        return body;
    }

    public void setBody(BodyBean body) {
        this.body = body;
    }

    public Object getMessage() {
        return message;
    }

    public void setMessage(Object message) {
        this.message = message;
    }

    public static class BodyBean {
        private List<CfgBean> cfg;

        public List<CfgBean> getCfg() {
            return cfg;
        }

        public void setCfg(List<CfgBean> cfg) {
            this.cfg = cfg;
        }

        public static class CfgBean implements Serializable {
            /**
             * xpath : ScrollView/LinearLayout/AppCompatTextView
             * pageName : MainActivity
             * option : {"vid":"ecacc695e3264e6faeee22646f422b98","top":37,"left":83,"width":57,
             * "controlId":"0","describe":"hello","type":"android.support.v7.widget
             * .AppCompatTextView","controlIndex":2,"height":14}
             */

            private String xpath;
            private String pageName;
            private OptionBean option;

            public String getXpath() {
                return xpath;
            }

            public void setXpath(String xpath) {
                this.xpath = xpath;
            }

            public String getPageName() {
                return pageName;
            }

            public void setPageName(String pageName) {
                this.pageName = pageName;
            }

            public OptionBean getOption() {
                return option;
            }

            public void setOption(OptionBean option) {
                this.option = option;
            }

            public static class OptionBean {
                /**
                 * vid : ecacc695e3264e6faeee22646f422b98
                 * top : 37
                 * left : 83
                 * width : 57
                 * controlId : 0
                 * describe : hello
                 * type : android.support.v7.widget.AppCompatTextView
                 * controlIndex : 2
                 * height : 14
                 */

                private String vid;
                private int top;
                private int left;
                private int width;
                private String controlId;
                private String describe;
                private String type;
                private int controlIndex;
                private int height;

                public String getVid() {
                    return vid;
                }

                public void setVid(String vid) {
                    this.vid = vid;
                }

                public int getTop() {
                    return top;
                }

                public void setTop(int top) {
                    this.top = top;
                }

                public int getLeft() {
                    return left;
                }

                public void setLeft(int left) {
                    this.left = left;
                }

                public int getWidth() {
                    return width;
                }

                public void setWidth(int width) {
                    this.width = width;
                }

                public String getControlId() {
                    return controlId;
                }

                public void setControlId(String controlId) {
                    this.controlId = controlId;
                }

                public String getDescribe() {
                    return describe;
                }

                public void setDescribe(String describe) {
                    this.describe = describe;
                }

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public int getControlIndex() {
                    return controlIndex;
                }

                public void setControlIndex(int controlIndex) {
                    this.controlIndex = controlIndex;
                }

                public int getHeight() {
                    return height;
                }

                public void setHeight(int height) {
                    this.height = height;
                }
            }
        }
    }
}
