package com.cm.android.infors.apm.crash;

import android.app.Application;
import com.cm.android.infors.core.SDKSwitchHandler;
import com.cm.android.infors.core.plugin.Plugin;
import com.cm.android.infors.core.plugin.PluginListener;

/**
 * crash 模块
 *
 * @author wusm
 */
public class CrashPlugin extends Plugin {

    private static final String TAG = "Infors.CrashPlugin";

    @Override
    public void init(Application app, PluginListener listener, SDKSwitchHandler dynamicConfig) {
        super.init(app, listener, dynamicConfig);
        if (!getDynamicConfig().isCrashEnable()
                || !dynamicConfig.isAutoTraceEnable()) {
            unSupportPlugin();
            return;
        }
    }


    @Override
    public void start() {
        super.start();
        if (!isSupported()) {
            return;
        }
        ExceptionHandler.init(this);
    }

    @Override
    public void stop() {
        super.stop();
        if (!isSupported()) {
            return;
        }
    }

    @Override
    public void destroy() {
        super.destroy();
    }

    public static String getTAG() {
        return CrashPlugin.TAG;
    }


}
