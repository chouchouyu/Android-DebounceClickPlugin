/*
 * Copyright (c) 2014-present, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree. An additional grant
 * of patent rights can be found in the PATENTS file in the same directory.
 */

package com.cm.android.infors.core.events;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Application;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.support.annotation.GuardedBy;
import android.support.annotation.Nullable;


import com.cm.android.infors.core.Logger;
import com.cm.android.infors.utils.ResUtils;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;


/**
 * Tracks which {@link Activity} instances have been created and not yet destroyed in creation
 * order for use by Stetho features.  Note that automatic tracking is not available for
 * all versions of Android but it is possible to manually track activities using the {@link #onActivityResumed(Activity)}
 * and {@link #onActivityDestroyed(Activity)} methods exposed below.  Be aware that this is an easy opportunity to
 * cause serious memory leaks in your application however.  Use with caution.
 * <p/>
 * Most callers can and should ignore this class, though it is necessary if you are implementing
 * Activity tracking pre-ICS.
 *
 * @author wusm
 */
public final class ActivityTracker {
    private static final ActivityTracker _sInstance = new ActivityTracker();

    /**
     * Use {@link WeakReference} here to silence a false positive from LeakCanary:
     * https://github.com/facebook/stetho/issues/319#issuecomment-285699813
     */
    @GuardedBy("Looper.getMainLooper()")
    private final ArrayList<WeakReference<Activity>> mActivities = new ArrayList<>();

    private final List<WeakReference<Activity>> mActivitiesUnmodifiable =
            Collections.unmodifiableList(mActivities);

    private final List<Listener> mListeners = new CopyOnWriteArrayList<>();

    @Nullable
    private AbstractAutomaticTracker mAutomaticTracker;

    //TODO 对外暴露
    public static ActivityTracker get() {
        return _sInstance;
    }

    //TODO 对外暴露
    public void registerListener(Listener listener) {
        mListeners.add(listener);
    }

    //TODO 对外暴露
    public void unregisterListener(Listener listener) {
        mListeners.remove(listener);
    }

    /**
     * Start automatic tracking if we are running on ICS+.
     *
     * @return Automatic tracking has been started.  No need to manually invoke {@link #onActivityResumed(Activity)} or
     * {@link #onActivityDestroyed} methods.
     */
    public boolean beginTrackingIfPossible(Application application) {
        if (mAutomaticTracker == null) {
            AbstractAutomaticTracker automaticTracker =
                    AbstractAutomaticTracker.newInstanceIfPossible(application, this);
            if (automaticTracker != null) {
                automaticTracker.register();
                mAutomaticTracker = automaticTracker;
                return true;
            }
        }
        return false;
    }

    public boolean endTracking() {
        if (mAutomaticTracker != null) {
            mAutomaticTracker.unregister();
            mAutomaticTracker = null;
            return true;
        }
        return false;
    }

    public void onActivityResumed(Activity activity) {
        checkNotnull(activity);
        mActivities.add(new WeakReference<>(activity));
        for (Listener listener : mListeners) {
            listener.onActivityResume(activity);
        }

    }

    private void onActivityCreated(Activity activity) {
        checkNotnull(activity);
        for (Listener listener : mListeners) {
            listener.onActivityCreate(activity);
        }
    }

    private void onActivityStopped(Activity activity) {
        checkNotnull(activity);
        for (Listener listener : mListeners) {
            listener.onActivityStop(activity);
        }
    }

    private void onActivityPaused(Activity activity) {
        checkNotnull(activity);
        for (Listener listener : mListeners) {
            listener.onActivityPause(activity);
        }
    }


    private void onActivityStarted(Activity activity) {
        checkNotnull(activity);
        for (Listener listener : mListeners) {
            listener.onActivityStart(activity);
        }
    }

    public void onActivityDestroyed(Activity activity) {
        checkNotnull(activity);
        if (removeFromWeakList(mActivities, activity)) {
            for (Listener listener : mListeners) {
                listener.onActivityDestroyed(activity);
            }
        }

    }

    private void checkNotnull(Activity activity) {
        ResUtils.throwIfNull(activity);
        ResUtils.throwIfNot(Looper.myLooper() == Looper.getMainLooper());
    }


    private static <T> boolean removeFromWeakList(ArrayList<WeakReference<T>> haystack, T needle) {
        for (int i = 0, N = haystack.size(); i < N; i++) {
            T hay = haystack.get(i).get();
            if (hay == needle) {
                haystack.remove(i);
                return true;
            }
        }
        return false;
    }

    //TODO 对外
    public List<WeakReference<Activity>> getActivitiesView() {
        return mActivitiesUnmodifiable;
    }

    //TODO 对外
    @Nullable
    public Activity tryGetTopActivity() {
        if (mActivitiesUnmodifiable.isEmpty()) {
            return null;
        }
        for (int i = mActivitiesUnmodifiable.size() - 1; i >= 0; i--) {
            Activity activity = mActivitiesUnmodifiable.get(i).get();
            if (activity != null) {
                return activity;
            }
        }
        return null;
    }

    //TODO 对外
    public interface Listener {
        void onActivityCreate(Activity activity);

        void onActivityStart(Activity activity);

        void onActivityResume(Activity activity);

        void onActivityPause(Activity activity);

        void onActivityStop(Activity activity);

        void onActivityDestroyed(Activity activity);
    }


    private static abstract class AbstractAutomaticTracker {
        @Nullable
        public static AbstractAutomaticTracker newInstanceIfPossible(
                Application application,
                ActivityTracker tracker) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH) {
                return new AbstractAutomaticTrackerICSAndBeyond(application, tracker);
            } else {
                return null;
            }
        }

        public abstract void register();

        public abstract void unregister();

        @TargetApi(Build.VERSION_CODES.ICE_CREAM_SANDWICH)
        private static class AbstractAutomaticTrackerICSAndBeyond extends AbstractAutomaticTracker {
            private final Application mApplication;
            private final ActivityTracker mTracker;

            public AbstractAutomaticTrackerICSAndBeyond(Application application, ActivityTracker tracker) {
                mApplication = application;
                mTracker = tracker;
            }

            @Override
            public void register() {
                mApplication.registerActivityLifecycleCallbacks(mLifecycleCallbacks);
            }

            @Override
            public void unregister() {
                mApplication.unregisterActivityLifecycleCallbacks(mLifecycleCallbacks);
            }

            private final Application.ActivityLifecycleCallbacks mLifecycleCallbacks =
                    new Application.ActivityLifecycleCallbacks() {
                        ScreenBroadcastReceiver screenBroadcastReceiver = new ScreenBroadcastReceiver();

                        @Override
                        public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
                            mTracker.onActivityCreated(activity);


                        }

                        @Override
                        public void onActivityStarted(Activity activity) {
                            mTracker.onActivityStarted(activity);
                        }

                        @Override
                        public void onActivityResumed(Activity activity) {
                            screenBroadcastReceiver.register(activity);
                            mTracker.onActivityResumed(activity);
                        }

                        @Override
                        public void onActivityPaused(Activity activity) {
                            screenBroadcastReceiver.unRegister(activity);
                            mTracker.onActivityPaused(activity);
                        }

                        @Override
                        public void onActivityStopped(Activity activity) {
                            mTracker.onActivityStopped(activity);
                        }

                        @Override
                        public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
                        }

                        @Override
                        public void onActivityDestroyed(Activity activity) {
                            mTracker.onActivityDestroyed(activity);
                        }

                    };
        }
    }


}
