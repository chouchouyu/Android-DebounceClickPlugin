package com.cm.android.infors.core;


import android.content.Context;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.text.TextUtils;

import com.cm.android.infors.utils.*;

import java.util.HashMap;
import java.util.Map;

import static com.cm.android.infors.core.Consts.SP_APP_LAUNCH;
import static com.cm.android.infors.utils.PrefUtils.*;

/**
 * Infors config
 *
 * @author wusm
 */

public class InforsConfig {

    private static class SingleTonHoler {
        private static InforsConfig INSTANCE = new InforsConfig();
    }

    public static InforsConfig getInstance() {
        return SingleTonHoler.INSTANCE;
    }


    public synchronized InforsConfig setAppKey(String appKey) {
        this.appKey = appKey;
        return this;
    }

    private String baseUrl;

    private InforsConfig() {
        if (null == this.globalParams) {
            this.globalParams = new HashMap<>();
        }
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    private final int sharedPreferencesMode = Context.MODE_PRIVATE;

    private final String sharedPreferencesName = Consts.SDK_NAME;


//    private long appLaunchTime;


    private String appKey;


    @NonNull
    public String sharedPreferencesName() {
        return sharedPreferencesName;
    }

    public int sharedPreferencesMode() {
        return sharedPreferencesMode;
    }

    public String getAppKey() {
        return appKey;
    }


    public long getAppLaunchTime(Context context) {
        return getLongFromSP(context, this, SP_APP_LAUNCH);
    }

    public void setAppLaunchTime(Context context, long appLaunchTime) {
        saveLongSP(context, this, SP_APP_LAUNCH, appLaunchTime);
    }

    private Map<String, String> globalParams;

    public Map<String, String> getGlobalParams() {
        return globalParams;
    }

    public void setGlobalParams(Map<String, String> globalParams) {
        this.globalParams.putAll(globalParams);
    }

    public String getDeviceId(Context context) {
        SharedPreferencesFactory sharedPreferencesFactory = new SharedPreferencesFactory(context,
                this);
        SharedPreferences prefs = sharedPreferencesFactory.create();
        String deviceId = prefs.getString(Consts.SP_DEVICE_ID, "");
        if (TextUtils.isEmpty(deviceId)) {
            deviceId = EncryptData.getMD5(DeviceUtils.getInstance(context)
                    .getDeviceData());

            saveStringSP(context,
                    this, Consts.SP_DEVICE_ID,
                    deviceId);

        }
        return deviceId;
    }

    public String getAppVersionName(Context context) {
        return DeviceUtils.getInstance(context).getAppVersionName();
    }

    public String getAppName(Context context) {
        return DeviceUtils.getInstance(context).getAppName();
    }

    private String getManufacturer(Context context) {
        return DeviceUtils.getInstance(context).getManufacturer();
    }

    private String getModel(Context context) {
        return DeviceUtils.getInstance(context).getModel();
    }

    public String getDeviceType(Context context) {
        return getManufacturer(context) + " " + getModel(context);
    }

    /**
     * requestId
     *
     * @param context
     * @return
     */
    public String getRequestid(Context context) {
        return getDeviceId(context) + System.currentTimeMillis();
    }

}
