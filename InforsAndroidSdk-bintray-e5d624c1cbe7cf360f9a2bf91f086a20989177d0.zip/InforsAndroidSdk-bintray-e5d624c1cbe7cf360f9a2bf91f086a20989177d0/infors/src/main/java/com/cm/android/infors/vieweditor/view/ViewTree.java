package com.cm.android.infors.vieweditor.view;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;

import com.cm.android.infors.core.InforsConfig;
import com.cm.android.infors.core.Logger;
import com.cm.android.infors.request.modal.ViewDescribe;
import com.cm.android.infors.runtime.AutoTrackUtils;

import com.google.gson.Gson;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import static com.cm.android.infors.core.Consts.TAG;

/**
 * 可视化 viewTree功能
 * Created by susan on 2018/8/13.
 */

public class ViewTree implements Observer {
    private final InforsConfig config;
    private View decorView;
    private ViewTreeUpdateListener listener;
    private Activity activity;

    public ViewTree(InforsConfig config, ViewTreeUpdateListener listener) {
        this.config = config;
        this.listener = listener;
    }

    public void startDrawViewTree(Activity activity) {
        this.activity = activity;
        onGetActivityChildren(activity);
    }

    private void onGetActivityChildren(Activity element) {
        decorView = element.getWindow().peekDecorView();
        if (decorView != null) {
            ViewGroup rootView = decorView.findViewById(android.R.id.content);
            childViewList = new ArrayList();
            View wrapView = rootView.getChildAt(0);
            childViewList.add(new WeakReference<View>(wrapView));
            for (int m = 0; m < ((ViewGroup) wrapView).getChildCount(); m++) {
                onGetChildren(rootView.getChildAt(m), childViewList);
            }

            if (viewDescribes == null) {
                viewDescribes = new ArrayList<>();
            } else {
                viewDescribes.clear();
            }

            for (int i = 0; i < childViewList.size(); i++) {
                WeakReference<View> node = childViewList.get(i);
                ViewProperty viewProperty = new ViewProperty(node.get(), i, element);

                viewProperty.addObserver(this);
            }
//
//            for (WeakReference<View> node : childViewList) {
//                if (viewTreeBean == null) {
//                    viewTreeBean = new ViewTreeBean();
//                    //第一次直接指定节点
//                    viewTreeBean.setNode(node);
//                } else {
//                    //之后依附parentView
//                    ViewTreeBean tempViewTree = new ViewTreeBean();
//                    tempViewTree.setNode(node);
//                    saveToParent(tempViewTree, viewTreeBean);
//                }
//            }

        }
    }


    List<ViewDescribe> viewDescribes;
    List<WeakReference<View>> childViewList;

    @Override
    public void update(Observable observable, Object o) {

        if (o instanceof ViewDescribe) {
            ViewDescribe currentViewDescribe = (ViewDescribe) o;
//            Logger.i(TAG, " view Tree -> " + currentViewDescribe.toString());
            viewDescribes.add(currentViewDescribe);
            ViewDescribe parentViewDescribe = viewDescribes.get(0);
            if (childViewList.size() == viewDescribes.size() && viewDescribes.size() > 1) {
                List<ViewDescribe> childViewDesCribes = parentViewDescribe.getChildViews();
                for (int i = 1; i < viewDescribes.size(); i++) {
                    childViewDesCribes.add(viewDescribes.get(i));
                }
            }


            //                ViewDescribe rootViewDesCribe = ViewTreeCompare(viewTreeBean);
//                ViewDescribe viewDesCribe = forEachViewTree(viewTreeBean, rootViewDesCribe);
            if (childViewList.size() == viewDescribes.size()) {

                Gson gson = new Gson();

                String json = gson.toJson(parentViewDescribe);
                json = JsonContact(json);
                if (listener != null) {
                    listener.onViewTreeChange(activity.getClass().getCanonicalName(),
                            json);
                }

            }
        }
    }


    public interface ViewTreeUpdateListener {
        void onViewTreeChange(String activityName, String viewTreeJson);
    }


    /**
     * "screenHeight": 0,
     * "screenWidth": 0,
     * ,"deviceId": "android.widget.ScrollView",
     * "appkey": "android.widget.ScrollView",
     * ,"platform": "android",
     *
     * @param json
     * @return
     */
    private String JsonContact(String json) {
        StringBuffer sb = new StringBuffer();
        sb.append(",")
                .append("\"screenHeight\":")
                .append(decorView.getHeight())
                .append(",\"screenWidth\":")
                .append(decorView.getWidth())
                .append(",\"appVersion\":")
                .append(config.getAppVersionName(activity.getApplicationContext()))
                .append(",\"deviceId\": \"")
                .append(config.getDeviceId(activity.getApplicationContext()))
                .append("\"")
                .append(",\"appKey\": \"")
                .append(config.getAppKey())
                .append("\"")
                .append(",\"platform\": \"android\"");

        StringBuffer viewTreeSB = new StringBuffer(json);
        viewTreeSB.insert(json.length() - 1, sb);


        Logger.i(TAG, "view Tree ->" + viewTreeSB);

        return viewTreeSB.toString();
    }


//    private ViewDescribe forEachViewTree(ViewTreeBean viewTreeBean, ViewDescribe viewDesCribe) {
//        List<ViewTreeBean> childViewList = viewTreeBean.getChildViewList();
//        if (childViewList != null && childViewList.size() > 0) {
//            for (ViewTreeBean childView : childViewList) {
//                ViewDescribe childViewDesCribe = ViewTreeCompare(childView);
//                forEachViewTree(childView, childViewDesCribe);
//                viewDesCribe.getChildViews().add(childViewDesCribe);
//            }
//        }
//
//        return viewDesCribe;
//    }


//    private ViewDescribe ViewTreeCompare(ViewTreeBean bean) {
//        ViewDescribe viewDes = null;
//
//        for (ViewDescribe viewDescribe : viewDescribes) {
//            if (viewDescribe.getId() == 0) {
//                if (bean.getXpath().equals(viewDescribe.getXpath())) {
//                    viewDes = viewDescribe;
//                }
//            } else if (activity.findViewById(viewDescribe.getId()) == bean.getNode().get()) {
//                viewDes = viewDescribe;
//            }
//        }
//        return viewDes;
//    }


//    private void saveToParent(ViewTreeBean tempViewTree, ViewTreeBean viewTreeBean) {
//        if (isCurrentViewGroupChild(tempViewTree.getNode().get(), viewTreeBean.getNode().get())) {
//            viewTreeBean.getChildViewList().add(tempViewTree);
//            return;
//        } else {
//            for (ViewTreeBean childViewTree : viewTreeBean.getChildViewList()) {
//                saveToParent(tempViewTree, childViewTree);
//            }
//        }
//    }


//    private boolean isCurrentViewGroupChild(View view, View parentView) {
//        if (view.getParent() != null
//                && view.getParent() instanceof View
//                && parentView != null) {
//            View currentparent = (View) view.getParent();
//            if (parentView == currentparent) {
//                return true;
//            }
//
//        }
//        return false;
//    }


    private void onGetChildren(View view, List<WeakReference<View>> childViewList) {
        if (view == null) {
            return;
        }

        if (isChildVisible(view) && AutoTrackUtils.configableOfView(view)) {
            childViewList.add(new WeakReference<View>(view));
        }


        if (view instanceof ViewGroup) {
            ViewGroup element = (ViewGroup) view;
            for (int i = 0, N = element.getChildCount(); i < N; ++i) {
                final View childView = element.getChildAt(i);
                if (childView != null) {
                    onGetChildren(childView, childViewList);
                }
            }
        }
    }

    private boolean isChildVisible(View childVg) {
        if (childVg.getVisibility() == View.VISIBLE) {
            return true;
        } else {
            return false;
        }
    }


}


