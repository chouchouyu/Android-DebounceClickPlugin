package com.cm.android.infors.apm.network;


import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

import com.cm.android.infors.Infors;
import com.cm.android.infors.core.report.Issue;
import com.cm.android.infors.core.events.ActivityTracker;
import com.cm.android.infors.core.ReportField;
import com.cm.android.infors.utils.DeviceUtils;
import okhttp3.*;

import static com.cm.android.infors.core.Consts.TYPE_HTTP;

/**
 * {  "preEventId" : "2392849d1926560ec1c6889cecd82ade",  "eventType" : "networkType",  "timestamp" : 1548748301896,  "deviceId" : "a39ac946b5fe4e038b986aa0405e4891",  "userId" : "default",  "platform" : "ios",  "eventId" : "aca96f3409d56186a462c1d680defc54",  "data" : {    "http" : {      "net_operator" : "",      "handle_time" : 0.89434301853179932,      "request_id" : "554b2426917166bb1bc09976663cffcc",      "request_time" : "2019-01-29 15:51:41",      "response_fail_code" : 0,      "request_bytes" : 17,      "url" : "https:\/\/www-di1.dev.cmrh.com\/mit\/tcs\/sendCode",      "response_bytes" : 64,      "is_slow_request" : false,      "remote_ip" : "100.67.174.10",      "response_time" : "2019-01-29 15:51:41",      "is_response_fail" : false    },    "vid" : "网络数据",    "describe" : "网络数据"  },  "sessionId" : "f3f96d7f6d710aa0e26e2024cfd725b7",  "appKey" : "db8b116c02854e42b8d32201c0f7d67d",  "appVersion" : "1.0",  "sdkVersion" : "1.1.2"}
 * <p>
 * https://github.com/Qihoo360/ArgusAPM/blob/master/argus-apm/argus-apm-okhttp/src/main/java/com/argusapm/android/okhttp3/NetWorkInterceptor.java
 * <p>
 * https://sourcegraph.com/github.com/square/okhttp@2f4b90050e739f2310a1e1a26634124dd3b618e2/-/blob/okhttp/src/main/java/okhttp3/internal/connection/RealConnection.java#L77:20
 * <p>
 * An OkHttp EventListener, which logs call events. Can be applied as an
 * {@linkplain OkHttpClient#eventListenerFactory() event listener factory}.
 *
 * <p>The format of the logs created by this class should not be considered stable and may change
 * slightly between releases. If you need a stable logging format, use your own event listener.
 *
 * @author wusm
 */
public class PrintingEventListener extends EventListener {


    public static final Factory FACTORY = new Factory() {

        final AtomicLong nextCallId = new AtomicLong(1L);

        @Override
        public EventListener create(Call call) {
            if (isShouldCollect()) {
                mOkHttpData = new OkHttpData();
//            System.out.printf("%04d %s%n", callId, call.request().url());
            }
            long callId = nextCallId.getAndIncrement();
            return new PrintingEventListener(callId, System.nanoTime());
        }
    };
    private static final String TAG = "Infors.PrintingEventListener";

    final long callId;
    final long callStartNanos;
    private static OkHttpData mOkHttpData;


    PrintingEventListener(long callId, long callStartNanos) {
        this.callId = callId;
        this.callStartNanos = callStartNanos;
    }

    private void printEvent(String name) {
//        long elapsedNanos = System.nanoTime() - callStartNanos;
//        Logger.d("Okhttp-EventListener", "%04d %.3f %s%n", callId, elapsedNanos / 1000000000d, name);
    }

    @Override
    public void callStart(Call call) {
        Request request = call.request();
        printEvent("callStart- url : " + request.url().toString());
        if (null != mOkHttpData) {
            mOkHttpData.setRequestTime(System.currentTimeMillis());
//        mOkHttpData.setRequest_time(OkHttpData.dataFormat(System.currentTimeMillis()));
            mOkHttpData.setUrl(request.url().toString());
        }
    }

    @Override
    public void dnsStart(Call call, String domainName) {
        printEvent("dnsStart" + domainName); //[34 ms] dnsStart: touch-di1.sit.cmrh.com
    }

    @Override
    public void dnsEnd(Call call, String domainName, List<InetAddress> inetAddressList) {
        // dnsEnd: [touch-di1.sit.cmrh.com/100.69.232.4]
        if (null != mOkHttpData) {
            mOkHttpData.setRemote_ip(inetAddressList + "");
        }
        printEvent("dnsEnd: " + inetAddressList);
    }

    @Override
    public void connectStart(
            Call call, InetSocketAddress inetSocketAddress, Proxy proxy) {
        printEvent("connectStart" + inetSocketAddress + " " + proxy);
    }

    @Override
    public void secureConnectStart(Call call) {
        printEvent("secureConnectStart");
    }

    @Override
    public void secureConnectEnd(Call call, Handshake handshake) {
        printEvent("secureConnectEnd" + handshake);
    }

    @Override
    public void connectEnd(
            Call call, InetSocketAddress inetSocketAddress, Proxy proxy, Protocol protocol) {
        printEvent("connectEnd" + protocol);
    }

    @Override
    public void connectFailed(Call call, InetSocketAddress inetSocketAddress, Proxy proxy,
                              Protocol protocol, IOException ioe) {
        printEvent("connectFailed" + protocol + " " + ioe);
        if (null != mOkHttpData) {
            mOkHttpData.setFail_msg(protocol + " " + ioe);
        }
    }

    @Override
    public void connectionAcquired(Call call, Connection connection) {
        printEvent("connectionAcquired" + connection);
    }

    @Override
    public void connectionReleased(Call call, Connection connection) {
        printEvent("connectionReleased");
    }

    @Override
    public void requestHeadersStart(Call call) {
        printEvent("requestHeadersStart");
    }

    @Override
    public void requestHeadersEnd(Call call, Request request) {
        printEvent("requestHeadersEnd");
    }

    @Override
    public void requestBodyStart(Call call) {
        printEvent("requestBodyStart");
    }

    @Override
    public void requestBodyEnd(Call call, long byteCount) {
        if (null != mOkHttpData) {
            mOkHttpData.setRequest_bytes(byteCount);
        }
        printEvent("requestBodyEnd" + byteCount);
    }

    @Override
    public void responseHeadersStart(Call call) {
        printEvent("responseHeadersStart");
    }

    @Override
    public void responseHeadersEnd(Call call, Response response) {
        printEvent("responseHeadersEnd: " + response);
        printEvent("okhttp chain.proceed 状态码：" + response.code());
        if (null != mOkHttpData) {
            mOkHttpData.setResponse_code(response.code());
        }
    }

    @Override
    public void responseBodyStart(Call call) {
        printEvent("responseBodyStart");
    }

    @Override
    public void responseBodyEnd(Call call, long byteCount) {
        if (null != mOkHttpData) {
            mOkHttpData.setResponse_bytes(byteCount);
        }
        printEvent("responseBodyEnd: byteCount=" + byteCount);
    }


    @Override
    public void callEnd(Call call) {
        if (null != mOkHttpData) {
            long elapsedNanos = System.nanoTime();
            mOkHttpData.setCostTime(elapsedNanos / 1000000000d);
            mOkHttpData.setNet_operator(DeviceUtils.getInstance(ActivityTracker.get().tryGetTopActivity()).getDetailNetworkTypeForStatic());
            mOkHttpData.setResponseFail(true);
            doReportHttpResult(mOkHttpData);
        }
        printEvent("callEnd");
    }

    @Override
    public void callFailed(Call call, IOException ioe) {
        if (null != mOkHttpData) {
            mOkHttpData.setFail_msg(ioe.toString());
            mOkHttpData.setResponseFail(false);
            doReportHttpResult(mOkHttpData);
        }
        printEvent("callFailed: " + ioe);
    }

    /**
     * deviceId + (new Date()).getTime() + Math.floor(Math.random() * 999999)
     *
     * @param mOkHttpData
     */
    private void doReportHttpResult(OkHttpData mOkHttpData) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ReportField.netOperator.name(), mOkHttpData.getNet_operator());
        map.put(ReportField.requestId.name(), mOkHttpData.getRequest_id());
        map.put(ReportField.url.name(), mOkHttpData.getUrl());
        map.put(ReportField.occurTime.name(), mOkHttpData.getRequestTime());
        map.put(ReportField.costTime.name(), mOkHttpData.getCostTime());
        map.put(ReportField.responseCode.name(), mOkHttpData.getResponse_code());
        map.put(ReportField.requestBytes.name(), mOkHttpData.getRequest_bytes());
        map.put(ReportField.responseBytes.name(), mOkHttpData.getResponse_bytes());
        map.put(ReportField.isSlowRequest.name(), mOkHttpData.isSlowRequest());
        map.put(ReportField.remoteIp.name(), mOkHttpData.getRemote_ip());
        map.put(ReportField.failMsg.name(), mOkHttpData.getFail_msg());
        map.put(ReportField.isResponseFail.name(), mOkHttpData.getFail_msg());
        HttpPlugin plugin = Infors.getInstance().getPluginByClass(HttpPlugin.class);

        if (plugin != null) {
            Issue issue = new Issue(TYPE_HTTP, map, plugin);
            plugin.onDetectIssue(issue);
        }

    }

    private static boolean isShouldCollect() {
        if (null == Infors.getInstance().getPluginByClass(HttpPlugin.class)) {
            return false;
        }
        return true;
    }


}