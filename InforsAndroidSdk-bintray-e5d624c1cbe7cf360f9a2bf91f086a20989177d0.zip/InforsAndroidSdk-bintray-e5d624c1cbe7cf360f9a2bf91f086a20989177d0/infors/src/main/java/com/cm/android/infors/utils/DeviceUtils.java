package com.cm.android.infors.utils;

import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.app.UiModeManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.*;
import android.os.Build.VERSION;
import android.provider.Settings.Secure;
import android.support.annotation.RequiresApi;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.text.format.Formatter;
import org.json.JSONArray;
import org.json.JSONException;

import java.io.*;
import java.lang.Process;
import java.net.*;
import java.util.*;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import static com.cm.android.infors.utils.EncryptData.Base64AES;

/**
 * @author wusm
 */
public class DeviceUtils {
    private Context context;
    private static DeviceUtils DeviceUtils;

    public static synchronized DeviceUtils getInstance(Context c) {
        if (DeviceUtils == null && c != null) {
            DeviceUtils = new DeviceUtils(c);
        }

        return DeviceUtils;
    }

    private DeviceUtils(Context context) {
        this.context = context.getApplicationContext();
    }

    public boolean isRooted() {
        return false;
    }

    public String getSSID() {
        try {
            if (this.checkPermission("android.permission.ACCESS_WIFI_STATE")) {
                Object t = this.getSystemService("wifi");
                if (t == null) {
                    return null;
                }

                StringBuilder sb = new StringBuilder();
                sb.append("ge");
                sb.append("tC");
                sb.append("on");
                sb.append("ne");
                sb.append("ct");
                sb.append("io");
                sb.append("nI");
                sb.append("nf");
                sb.append("O");
                Object info = ReflectUtils.invokeInstanceMethod(t, sb.toString(), new Object[0]);
                if (info != null) {
                    StringBuilder sb1 = new StringBuilder();
                    sb1.append("ge");
                    sb1.append("tS");
                    sb1.append("SI");
                    sb1.append("D");
                    String ssid = (String) ReflectUtils.invokeInstanceMethod(info, sb1.toString(), new Object[0]);
                    return ssid == null ? null : ssid.replace("\"", "");
                }
            }
        } catch (Throwable var6) {
        }

        return null;
    }

    public String getBssid() {
        try {
            if (this.checkPermission("android.permission.ACCESS_WIFI_STATE")) {
                Object t = this.getSystemService("wifi");
                if (t == null) {
                    return null;
                }

                StringBuilder sb = new StringBuilder();
                sb.append("ge");
                sb.append("tC");
                sb.append("on");
                sb.append("ne");
                sb.append("ct");
                sb.append("io");
                sb.append("nI");
                sb.append("nf");
                sb.append("O");
                Object info = ReflectUtils.invokeInstanceMethod(t, sb.toString(), new Object[0]);
                if (info != null) {
                    StringBuilder sb1 = new StringBuilder();
                    sb1.append("ge");
                    sb1.append("tB");
                    sb1.append("SS");
                    sb1.append("ID");
                    String bssid = (String) ReflectUtils.invokeInstanceMethod(info, sb1.toString(), new Object[0]);
                    return bssid == null ? null : bssid;
                }
            }
        } catch (Throwable var6) {
        }

        return null;
    }

    public String getMacAddress() {
        if (VERSION.SDK_INT >= 23) {
            String t = null;

            try {
                t = this.getHardwareAddressFromShell("wlan0");
            } catch (Throwable var9) {
                t = null;
            }

            if (t == null) {
                try {
                    t = this.getCurrentNetworkHardwareAddress();
                } catch (Throwable var8) {
                    t = null;
                }
            }

            if (t == null) {
                try {
                    String[] sb = this.listNetworkHardwareAddress();
                    if (sb.length > 0) {
                        t = sb[0];
                    }
                } catch (Throwable var7) {
                    t = null;
                }
            }

            if (t != null) {
                return t;
            }
        }

        try {
            Object t1 = this.getSystemService("wifi");
            if (t1 == null) {
                return null;
            }

            StringBuilder sb1 = new StringBuilder();
            sb1.append("ge");
            sb1.append("tC");
            sb1.append("on");
            sb1.append("ne");
            sb1.append("ct");
            sb1.append("io");
            sb1.append("nI");
            sb1.append("nf");
            sb1.append("O");
            Object info = ReflectUtils.invokeInstanceMethod(t1, sb1.toString(), new Object[0]);

            if (info != null) {
                StringBuilder sb2 = new StringBuilder();
                sb2.append("ge");
                sb2.append("tM");
                sb2.append("ac");
                sb2.append("Ad");
                sb2.append("dr");
                sb2.append("es");
                sb2.append("s");
                String mac = (String) ReflectUtils.invokeInstanceMethod(info, sb2.toString(), new Object[0]);
                return mac == null ? null : mac.trim();
            }
        } catch (Throwable var6) {
            //    MobLogger.getInstance(context).W(var6);
        }
        return null;
    }

    @RequiresApi(api = Build.VERSION_CODES.GINGERBREAD)
    private String getCurrentNetworkHardwareAddress() throws Throwable {
        Enumeration nis = NetworkInterface.getNetworkInterfaces();
        if (nis == null) {
            return null;
        } else {
            ArrayList interfaces = Collections.list(nis);
            Iterator var3 = interfaces.iterator();

            while (true) {
                NetworkInterface intf;
                Enumeration ias;
                do {
                    if (!var3.hasNext()) {
                        return null;
                    }

                    intf = (NetworkInterface) var3.next();
                    ias = intf.getInetAddresses();
                } while (ias == null);

                ArrayList addrs = Collections.list(ias);
                Iterator var7 = addrs.iterator();

                while (var7.hasNext()) {
                    InetAddress add = (InetAddress) var7.next();
                    if (!add.isLoopbackAddress() && add instanceof Inet4Address) {
                        byte[] mac = intf.getHardwareAddress();
                        if (mac != null) {
                            StringBuilder buf = new StringBuilder();
                            byte[] var11 = mac;
                            int var12 = mac.length;

                            for (int var13 = 0; var13 < var12; ++var13) {
                                byte aMac = var11[var13];
                                buf.append(String.format("%02x:", new Object[]{Byte.valueOf(aMac)}));
                            }

                            if (buf.length() > 0) {
                                buf.deleteCharAt(buf.length() - 1);
                            }

                            return buf.toString();
                        }
                    }
                }
            }
        }
    }

    private String[] listNetworkHardwareAddress() throws Throwable {
        Enumeration nis = NetworkInterface.getNetworkInterfaces();
        if (nis == null) {
            return null;
        } else {
            ArrayList interfaces = Collections.list(nis);
            HashMap macs = new HashMap();
            Iterator names = interfaces.iterator();

            while (true) {
                NetworkInterface wlans;
                byte[] eths;
                do {
                    if (!names.hasNext()) {
                        ArrayList var14 = new ArrayList(macs.keySet());
                        ArrayList var15 = new ArrayList();
                        ArrayList var16 = new ArrayList();
                        ArrayList var17 = new ArrayList();
                        ArrayList var18 = new ArrayList();
                        ArrayList var19 = new ArrayList();
                        ArrayList var20 = new ArrayList();
                        ArrayList var21 = new ArrayList();

                        while (var14.size() > 0) {
                            String macArr = (String) var14.remove(0);
                            if (macArr.startsWith("wlan")) {
                                var15.add(macArr);
                            } else if (macArr.startsWith("eth")) {
                                var16.add(macArr);
                            } else if (macArr.startsWith("rev_rmnet")) {
                                var17.add(macArr);
                            } else if (macArr.startsWith("dummy")) {
                                var18.add(macArr);
                            } else if (macArr.startsWith("usbnet")) {
                                var19.add(macArr);
                            } else if (macArr.startsWith("rmnet_usb")) {
                                var20.add(macArr);
                            } else {
                                var21.add(macArr);
                            }
                        }

                        Collections.sort(var15);
                        Collections.sort(var16);
                        Collections.sort(var17);
                        Collections.sort(var18);
                        Collections.sort(var19);
                        Collections.sort(var20);
                        Collections.sort(var21);
                        var14.addAll(var15);
                        var14.addAll(var16);
                        var14.addAll(var17);
                        var14.addAll(var18);
                        var14.addAll(var19);
                        var14.addAll(var20);
                        var14.addAll(var21);
                        String[] var22 = new String[var14.size()];

                        for (int i = 0; i < var22.length; ++i) {
                            var22[i] = (String) macs.get(var14.get(i));
                        }

                        return var22;
                    }

                    wlans = (NetworkInterface) names.next();
                    eths = wlans.getHardwareAddress();
                } while (eths == null);

                StringBuilder rmnets = new StringBuilder();
                byte[] dummys = eths;
                int usbs = eths.length;

                for (int rmnetUsbs = 0; rmnetUsbs < usbs; ++rmnetUsbs) {
                    byte others = dummys[rmnetUsbs];
                    rmnets.append(String.format("%02x:", new Object[]{Byte.valueOf(others)}));
                }

                if (rmnets.length() > 0) {
                    rmnets.deleteCharAt(rmnets.length() - 1);
                }

                macs.put(wlans.getName(), rmnets.toString());
            }
        }
    }

    private String getHardwareAddressFromShell(String networkCard) {
        String line = null;
        BufferedReader br = null;

        try {
            StringBuilder t = new StringBuilder();
            t.append("ca");
            t.append("t ");
            t.append("/s");
            t.append("ys");
            t.append("/c");
            t.append("la");
            t.append("ss");
            t.append("/n");
            t.append("et");
            t.append("/");
            t.append(networkCard);
            t.append("/a");
            t.append("dd");
            t.append("re");
            t.append("ss");
            Process p = Runtime.getRuntime().exec(t.toString());
            InputStreamReader isr = new InputStreamReader(p.getInputStream());
            br = new BufferedReader(isr);
            line = br.readLine();
        } catch (Throwable var15) {
            //  MobLogger.getInstance(context).D(var15);
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (Throwable var14) {
                    ;
                }
            }

        }

        return TextUtils.isEmpty(line) ? null : line;
    }

    public String getModel() {
        String model = Build.MODEL;
        if (!TextUtils.isEmpty(model)) {
            model = model.trim();
        }

        return model;
    }

    public String getManufacturer() {
        return Build.MANUFACTURER;
    }

    public String getDeviceId() {
        String deviceId = this.getIMEI();
        return TextUtils.isEmpty(deviceId) && VERSION.SDK_INT >= 9 ? this.getSerialno() : deviceId;
    }

    /**
     * @deprecated
     */
    public String getMime() {
        return this.getIMEI();
    }

    public String getIMEI() {
        Object phone = this.getSystemService("phone");
        if (phone == null) {
            return null;
        } else {
            String deviceId = null;

            try {
                if (this.checkPermission("android.permission.READ_PHONE_STATE")) {
                    StringBuilder t = new StringBuilder();
                    t.append("ge");
                    t.append("tD");
                    t.append("ev");
                    t.append("ic");
                    t.append("eI");
                    t.append("D");
                    deviceId = (String) ReflectUtils.invokeInstanceMethod(phone, t.toString(), new Object[0]);
                }
            } catch (Throwable var4) {
                //   MobLogger.getInstance(context).W(var4);
            }

            return TextUtils.isEmpty(deviceId) ? null : deviceId.trim();
        }
    }

    public String getSerialno() {
        String serialno = null;
        if (VERSION.SDK_INT >= 9) {
            try {
                StringBuilder t = new StringBuilder();
                t.append("an");
                t.append("dr");
                t.append("oi");
                t.append("D.");
                t.append("os");
                t.append(".S");
                t.append("ys");
                t.append("te");
                t.append("mP");
                t.append("ro");
                t.append("pe");
                t.append("rt");
                t.append("ie");
                t.append("s");
                ReflectUtils.importClass(t.toString());
                StringBuilder sb1 = new StringBuilder();
                sb1.append("ge");
                sb1.append("t");
                serialno = (String) ReflectUtils.invokeStaticMethod("SystemProperties", sb1.toString(), new Object[]{"ro.serialno", "unknown"});
            } catch (Throwable var4) {
                //      MobLogger.getInstance(context).D(var4);
                serialno = null;
            }
        }

        if (!TextUtils.isEmpty(serialno)) {
            serialno = serialno.trim();
        }

        return serialno;
    }

    public String getDeviceData() {
        String data = this.getModel() + "|" + this.getOSVersionInt() + "|" + this.getManufacturer() + "|" + this.getCarrier() + "|" + this.getScreenSize();
        String deviString = this.getDeviceKey();
        try {
            return Base64AES(data, deviString.substring(0, 16));
        } catch (Throwable throwable) {
            throwable.printStackTrace();
            return null;
        }
    }

    public String getDeviceDataNotAES() {
        return this.getModel() + "|" + this.getOSVersion() + "|" + this.getManufacturer() + "|" + this.getCarrier() + "|" + this.getScreenSize();
    }


    /**
     * @deprecated
     */
    public String getOSVersion() {
        return String.valueOf(this.getOSVersionInt());
    }

    public int getOSVersionInt() {
        return VERSION.SDK_INT;
    }

    public String getOSVersionName() {
        return VERSION.RELEASE;
    }

    public String getOSLanguage() {
        return Locale.getDefault().getLanguage();
    }

    public String getAppLanguage() {
        return this.context.getResources().getConfiguration().locale.getLanguage();
    }

    public String getOSCountry() {
        return Locale.getDefault().getCountry();
    }

    public String getScreenSize() {
        int[] size = ResUtils.getScreenSize(this.context);
        return this.context.getResources().getConfiguration().orientation == 1 ? size[0] + "x" + size[1] : size[1] + "x" + size[0];
    }

    public String getCarrier() {
        try {
            Object t = this.getSystemService("phone");
            if (t == null) {
                return "-1";
            } else {
                StringBuilder sb = new StringBuilder();
                sb.append("ge");
                sb.append("tS");
                sb.append("im");
                sb.append("Op");
                sb.append("er");
                sb.append("at");
                sb.append("or");
                String operator = (String) ReflectUtils.invokeInstanceMethod(t, sb.toString(), new Object[0]);
                if (TextUtils.isEmpty(operator)) {
                    operator = "-1";
                }

                return operator;
            }
        } catch (Throwable var4) {
            //    MobLogger.getInstance(context).W(var4);
            return "-1";
        }
    }

    private static final Map<String, String> sCarrierMap = new HashMap<String, String>() {
        {
            //中国移动
            put("46000", "中国移动");
            put("46002", "中国移动");
            put("46007", "中国移动");
            put("46008", "中国移动");

            //中国联通
            put("46001", "中国联通");
            put("46006", "中国联通");
            put("46009", "中国联通");

            //中国电信
            put("46003", "中国电信");
            put("46005", "中国电信");
            put("46011", "中国电信");

            //中国卫通
            put("46004", "中国卫通");

            //中国铁通
            put("46020", "中国铁通");

        }
    };

    public String operatorToCarrier() {
        String operator = getCarrier();
        final String other = "其他";

        if (TextUtils.isEmpty(operator)) {
            return other;
        }

        for (Map.Entry<String, String> entry : sCarrierMap.entrySet()) {
            if (operator.startsWith(entry.getKey())) {
                return entry.getValue();
            }
        }

        return other;
    }


    public String getCarrierName() {
        Object tm = this.getSystemService("phone");
        if (tm == null) {
            return null;
        } else {
            try {
                if (this.checkPermission("android.permission.READ_PHONE_STATE")) {
                    StringBuilder t = new StringBuilder();
                    t.append("ge");
                    t.append("tS");
                    t.append("im");
                    t.append("Op");
                    t.append("er");
                    t.append("at");
                    t.append("or");
                    t.append("Na");
                    t.append("me");
                    String operator = (String) ReflectUtils.invokeInstanceMethod(tm, t.toString(), new Object[0]);
                    if (TextUtils.isEmpty(operator)) {
                        operator = null;
                    }

                    return operator;
                }
            } catch (Throwable var4) {
                //     MobLogger.getInstance(context).W(var4);
            }

            return null;
        }
    }

    public String getDeviceKey() {
        String deviceKey = null;

        try {
            deviceKey = this.getDeviceKeyWithDuid("comm/dbs/.duid");
        } catch (Throwable var5) {
            // MobLogger.getInstance(context).W(var5);
        }

        if (TextUtils.isEmpty(deviceKey) || deviceKey.length() < 40) {
            deviceKey = this.genDeviceKey();
        }

        if (!TextUtils.isEmpty(deviceKey) && deviceKey.length() >= 40) {
            return deviceKey.trim();
        } else {
            try {
                deviceKey = this.getLocalDeviceKey();
            } catch (Throwable var4) {
                //     MobLogger.getInstance(context).W(var4);
                deviceKey = null;
            }

            if (!TextUtils.isEmpty(deviceKey) && deviceKey.length() >= 40) {
                return deviceKey.trim();
            } else {
                if (TextUtils.isEmpty(deviceKey) || deviceKey.length() < 40) {
                    deviceKey = this.getCharAndNumr(40);
                }

                if (deviceKey != null) {
                    try {
                        deviceKey = deviceKey.trim();
                        this.saveLocalDeviceKey(deviceKey);
                    } catch (Throwable var3) {
                        //         MobLogger.getInstance(context).W(var3);
                    }
                }

                return deviceKey;
            }
        }
    }

    private String getDeviceKeyWithDuid(String duidFilePath) throws Throwable {
        HashMap map = null;

        try {
            File deviceInfo = new File(ResUtils.getCacheRoot(this.context), duidFilePath);
            if (deviceInfo.exists() && deviceInfo.isFile()) {
                ObjectInputStream deviceKey = null;

                try {
                    FileInputStream t = new FileInputStream(deviceInfo);
                    deviceKey = new ObjectInputStream(t);
                    map = (HashMap) deviceKey.readObject();
                } catch (Throwable var19) {
                    //      MobLogger.getInstance(context).W(var19);
                } finally {
                    if (deviceKey != null) {
                        try {
                            deviceKey.close();
                        } catch (Throwable var18) {
                            ;
                        }
                    }

                }
            }
        } catch (Throwable var21) {
            //  MobLogger.getInstance(context).W(var21);
        }

        if (map == null) {
            return null;
        } else {
            HashMap deviceInfo1 = (HashMap) map.get("deviceInfo");
            if (deviceInfo1 == null) {
                return null;
            } else {
                String deviceKey1 = "";

                try {
                    String t1 = (String) deviceInfo1.get("mac");
                    String deviceId = (String) deviceInfo1.get("imei");
                    if (TextUtils.isEmpty(deviceId) && VERSION.SDK_INT >= 9) {
                        deviceId = (String) deviceInfo1.get("serialno");
                    }

                    String model = (String) deviceInfo1.get("model");
                    String data = t1 + ":" + deviceId + ":" + model;
                    byte[] bytes = EncryptData.SHA1(data);
                    deviceKey1 = EncryptData.byteToHex(bytes);
                } catch (Throwable var17) {
                    //      MobLogger.getInstance(context).D(var17);
                    deviceKey1 = null;
                }

                return deviceKey1;
            }
        }
    }

    private String genDeviceKey() {
        String newKey = null;

        try {
            //   String t = this.getMacAddress();  自带的Mac获取不到MacAdress
            String udid = this.getDeviceId();
            String model = this.getModel();
            // String data = t + ":" + udid + ":" + model;
            String data = udid + ":" + model;
            byte[] bytes = EncryptData.SHA1(data);
            newKey = EncryptData.byteToHex(bytes);
        } catch (Throwable var7) {
            //    MobLogger.getInstance(context).D(var7);
            newKey = null;
        }

        return newKey;
    }


    public String getMCC() {
        String imsi = this.getIMSI();
        return imsi != null && imsi.length() >= 3 ? imsi.substring(0, 3) : null;
    }

    public String getMNC() {
        String imsi = this.getIMSI();
        return imsi != null && imsi.length() >= 5 ? imsi.substring(3, 5) : null;
    }

    public String getSimSerialNumber() {
        try {
            Object t = this.getSystemService("phone");
            if (t == null) {
                return "-1";
            } else {
                StringBuilder sb = new StringBuilder();
                sb.append("ge");
                sb.append("tS");
                sb.append("im");
                sb.append("Se");
                sb.append("ri");
                sb.append("al");
                sb.append("Nu");
                sb.append("mb");
                sb.append("er");
                return (String) ReflectUtils.invokeInstanceMethod(t, sb.toString(), new Object[0]);
            }
        } catch (Throwable var3) {
            //   MobLogger.getInstance(context).W(var3);
            return "-1";
        }
    }

    public String getLine1Number() {
        try {
            Object t = this.getSystemService("phone");
            if (t == null) {
                return "-1";
            } else {
                StringBuilder sb = new StringBuilder();
                sb.append("ge");
                sb.append("tL");
                sb.append("in");
                sb.append("e1");
                sb.append("Nu");
                sb.append("mb");
                sb.append("er");
                return (String) ReflectUtils.invokeInstanceMethod(t, sb.toString(), new Object[0]);
            }
        } catch (Throwable var3) {
            //      MobLogger.getInstance(context).W(var3);
            return "-1";
        }
    }

    public String getBluetoothName() {
        try {
            StringBuilder e = new StringBuilder();
            e.append("an");
            e.append("dr");
            e.append("oi");
            e.append("D.");
            e.append("bl");
            e.append("ue");
            e.append("to");
            e.append("ot");
            e.append("h.");
            e.append("Bl");
            e.append("ue");
            e.append("to");
            e.append("ot");
            e.append("hA");
            e.append("da");
            e.append("pt");
            e.append("er");
            ReflectUtils.importClass(e.toString());
            if (this.checkPermission("android.permission.BLUETOOTH")) {
                StringBuilder sb1 = new StringBuilder();
                sb1.append("ge");
                sb1.append("tD");
                sb1.append("ef");
                sb1.append("au");
                sb1.append("lt");
                sb1.append("Ad");
                sb1.append("ap");
                sb1.append("te");
                sb1.append("r");
                Object myDevice = ReflectUtils.invokeStaticMethod("BluetoothAdapter", sb1.toString(), new Object[0]);
                if (myDevice != null) {
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append("ge");
                    sb2.append("tN");
                    sb2.append("am");
                    sb2.append("E");
                    return (String) ReflectUtils.invokeInstanceMethod(myDevice, sb2.toString(), new Object[0]);
                }
            }
        } catch (Throwable var5) {
            //  MobLogger.getInstance(context).D(var5);
        }

        return null;
    }


    private Object getSystemService(String name) {
        try {
            return this.context.getSystemService(name);
        } catch (Throwable var3) {
            //  MobLogger.getInstance(context).W(var3);
            return null;
        }
    }

    public String getNetworkType() {
        ConnectivityManager conn = (ConnectivityManager) this
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        if (conn == null) {
            return "none";
        } else {
//            try {
//                if (!this.checkPermission("android.permission.ACCESS_NETWORK_STATE")) {
//                    return "none";
//                }
//            } catch (Throwable var4) {
//                //      MobLogger.getInstance(context).W(var4);
//                return "none";
//            }

            NetworkInfo network = conn.getActiveNetworkInfo();
            if (network != null && network.isAvailable()) {
                int type = network.getType();
                switch (type) {
                    case 0:
                        if (this.is4GMobileNetwork()) {
                            return "4G";
                        }

                        return this.isFastMobileNetwork() ? "3G" : "2G";
                    case 1:
                        return "wifi";
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    default:
                        return String.valueOf(type);
                    case 6:
                        return "wimax";
                    case 7:
                        return "bluetooth";
                    case 8:
                        return "dummy";
                    case 9:
                        return "ethernet";
                }
            } else {
                return "none";
            }
        }
    }

    public String getNetworkTypeForStatic() {
        String networkType = this.getNetworkType().toLowerCase();
        return !TextUtils.isEmpty(networkType) && !"none".equals(networkType) ? (!networkType.startsWith("4g") && !networkType.startsWith("3g") && !networkType.startsWith("2g") ? (networkType.startsWith("wifi") ? "wifi" : "other") : "cell") : "none";
    }

    public String getDetailNetworkTypeForStatic() {
        String networkType = this.getNetworkType().toLowerCase();
        return !TextUtils.isEmpty(networkType) && !"none".equals(networkType) ?
                (networkType.startsWith("wifi") ?
                        "wifi" : (networkType.startsWith("4g") ?
                        operatorToCarrier() + "(4g)" : (networkType.startsWith("3g") ?
                        operatorToCarrier() + "(3g)" : (networkType.startsWith("2g") ?
                        operatorToCarrier() + "(2g)" : (networkType.startsWith("bluetooth") ?
                        "bluetooth" : networkType))))) : "none";
    }

    public int getPlatformCode() {
        return 1;
    }

    private boolean is4GMobileNetwork() {
        Object phone = this.getSystemService("phone");
        if (phone == null) {
            return false;
        } else {
            try {
                StringBuilder t = new StringBuilder();
                t.append("ge");
                t.append("tN");
                t.append("et");
                t.append("wo");
                t.append("rk");
                t.append("Ty");
                t.append("pe");
                int type = ((Integer) ReflectUtils.invokeInstanceMethod(phone, t.toString(), new Object[0])).intValue();
                return type == 13;
            } catch (Throwable var4) {
                //  MobLogger.getInstance(context).W(var4);
                return false;
            }
        }
    }

    private boolean isFastMobileNetwork() {
        Object phone = this.getSystemService("phone");
        if (phone == null) {
            return false;
        } else {
            try {
                StringBuilder t = new StringBuilder();
                t.append("ge");
                t.append("tN");
                t.append("et");
                t.append("wo");
                t.append("rk");
                t.append("Ty");
                t.append("pe");
                int type = ((Integer) ReflectUtils.invokeInstanceMethod(phone, t.toString(), new Object[0])).intValue();
                switch (type) {
                    case 0:
                        return false;
                    case 1:
                        return false;
                    case 2:
                        return false;
                    case 3:
                        return true;
                    case 4:
                        return false;
                    case 5:
                        return true;
                    case 6:
                        return true;
                    case 7:
                        return false;
                    case 8:
                        return true;
                    case 9:
                        return true;
                    case 10:
                        return true;
                    case 11:
                        return false;
                    case 12:
                        return true;
                    case 13:
                        return true;
                    case 14:
                        return true;
                    case 15:
                        return true;
                }
            } catch (Throwable var4) {
                //     MobLogger.getInstance(context).W(var4);
            }

            return false;
        }
    }

    public JSONArray getRunningApp() {
        JSONArray appNmes = new JSONArray();
        Object am = this.getSystemService("activity");
        if (am == null) {
            return appNmes;
        } else {
            try {
                StringBuilder t = new StringBuilder();
                t.append("ge");
                t.append("tR");
                t.append("un");
                t.append("ni");
                t.append("ng");
                t.append("Ap");
                t.append("pP");
                t.append("ro");
                t.append("ce");
                t.append("ss");
                t.append("es");
                List apps = (List) ReflectUtils.invokeInstanceMethod(am, t.toString(), new Object[0]);
                if (apps == null) {
                    return appNmes;
                }

                Iterator var5 = apps.iterator();

                while (var5.hasNext()) {
                    Object app = var5.next();
                    StringBuilder sb1 = new StringBuilder();
                    sb1.append("pr");
                    sb1.append("oc");
                    sb1.append("es");
                    sb1.append("sN");
                    sb1.append("am");
                    sb1.append("E");
                    appNmes.put(ReflectUtils.getInstanceField(app, sb1.toString()));
                }
            } catch (Throwable var8) {
                //    MobLogger.getInstance(context).W(var8);
            }

            return appNmes;
        }
    }

    public String getRunningAppStr() throws JSONException {
        JSONArray apps = this.getRunningApp();
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < apps.length(); ++i) {
            if (i > 0) {
                sb.append(',');
            }

            sb.append(String.valueOf(apps.get(i)));
        }

        return sb.toString();
    }


    public String getCharAndNumr(int length) {
        long currentTime = System.currentTimeMillis();
        long elapseTime = SystemClock.elapsedRealtime();
        long realTime = currentTime ^ elapseTime;
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append(realTime);
        Random random = new Random();

        for (int i = 0; i < length; ++i) {
            String charOrNum = random.nextInt(2) % 2 == 0 ? "char" : "num";
            if ("char".equalsIgnoreCase(charOrNum)) {
                char charValue = (char) (97 + random.nextInt(26));
                stringBuffer.insert(i + 1, charValue);
            } else {
                stringBuffer.insert(stringBuffer.length(), random.nextInt(10));
            }
        }

        return stringBuffer.toString().substring(0, 40);
    }


    private String getLocalDeviceKey() throws Throwable {
        if (!this.getSdcardState()) {
            return null;
        } else {
            String sdPath = this.getSdcardPath();
            File cacheRoot = new File(sdPath, "ShareSDK");
            File keyFile;
            if (cacheRoot.exists()) {
                keyFile = new File(cacheRoot, ".dk");
                if (keyFile.exists()) {
                    boolean fis = keyFile.renameTo(new File(ResUtils.getCacheRoot(this.context), ".dk"));
                    if (fis) {
                        keyFile.delete();
                    }
                }
            }

            keyFile = new File(ResUtils.getCacheRoot(this.context), ".dk");
            if (!keyFile.exists()) {
                return null;
            } else {
                FileInputStream fis1 = new FileInputStream(keyFile);
                ObjectInputStream ois = new ObjectInputStream(fis1);
                Object key = ois.readObject();
                String strKey = null;
                if (key != null && key instanceof char[]) {
                    char[] cKey = (char[]) ((char[]) key);
                    strKey = String.valueOf(cKey);
                }

                ois.close();
                return strKey;
            }
        }
    }

    private void saveLocalDeviceKey(String key) throws Throwable {
        if (this.getSdcardState()) {
            File keyFile = new File(ResUtils.getCacheRoot(this.context), ".dk");
            if (keyFile.exists()) {
                keyFile.delete();
            }

            FileOutputStream fos = new FileOutputStream(keyFile);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            char[] cKey = key.toCharArray();
            oos.writeObject(cKey);
            oos.flush();
            oos.close();
        }
    }

    public String getPackageName() {
        return this.context.getPackageName();
    }

    public String getAppName() {
        String appName = this.context.getApplicationInfo().name;
        if (appName != null) {
            if (VERSION.SDK_INT < 25 || appName.endsWith(".*")) {
                return appName;
            }

            try {
                ReflectUtils.importClass(appName);
                appName = null;
            } catch (Throwable var3) {
                ;
            }
        }

        int appLbl = this.context.getApplicationInfo().labelRes;
        if (appLbl > 0) {
            appName = this.context.getString(appLbl);
        } else {
            appName = String.valueOf(this.context.getApplicationInfo().nonLocalizedLabel);
        }

        return appName;
    }

    public int getAppVersion() {
        try {
            PackageManager t = this.context.getPackageManager();
            PackageInfo pi = t.getPackageInfo(this.context.getPackageName(), 0);
            return pi.versionCode;
        } catch (Throwable var3) {
            //    MobLogger.getInstance(context).D(var3);
            return 0;
        }
    }

    public String getAppVersionName() {
        try {
            PackageManager t = this.context.getPackageManager();
            PackageInfo pi = t.getPackageInfo(this.context.getPackageName(), 0);
            return pi.versionName;
        } catch (Throwable var3) {
            //     MobLogger.getInstance(context).D(var3);
            return "1.0";
        }
    }

    public ArrayList<HashMap<String, String>> getInstalledApp(boolean includeSystemApp) {
        try {
            ArrayList t = new ArrayList();

            try {
                StringBuilder apps = new StringBuilder();
                apps.append("pm");
                apps.append(" l");
                apps.append("is");
                apps.append("t ");
                apps.append("pa");
                apps.append("ck");
                apps.append("ag");
                apps.append("es");
                Process pm = Runtime.getRuntime().exec(apps.toString());
                InputStreamReader isr = new InputStreamReader(pm.getInputStream(), "utf-8");
                BufferedReader pkg = new BufferedReader(isr);

                for (String pi = pkg.readLine(); pi != null; pi = pkg.readLine()) {
                    pi = pi.toLowerCase().trim();
                    if (pi.startsWith("package:")) {
                        pi = pi.substring("package:".length()).trim();
                        t.add(pi);
                    }
                }

                pkg.close();
                pm.destroy();
            } catch (Throwable var13) {
                //       MobLogger.getInstance(context).W(var13);
            }

            ArrayList apps1 = new ArrayList();
            PackageManager pm1 = this.context.getPackageManager();
            Iterator isr1 = t.iterator();

            while (isr1.hasNext()) {
                String pkg1 = (String) isr1.next();
                PackageInfo pi1 = null;

                try {
                    pi1 = pm1.getPackageInfo(pkg1, 0);
                } catch (Throwable var12) {
                    //       MobLogger.getInstance(context).D(var12);
                }

                if (pi1 != null && (includeSystemApp || !this.isSystemApp(pi1))) {
                    HashMap app = new HashMap();
                    app.put("pkg", pi1.packageName);
                    String appName = pi1.applicationInfo.name;
                    if (appName == null) {
                        int appLbl = pi1.applicationInfo.labelRes;
                        if (appLbl > 0) {
                            CharSequence label = pm1.getText(pi1.packageName, appLbl, pi1.applicationInfo);
                            if (label != null) {
                                appName = label.toString().trim();
                            }
                        }

                        if (appName == null) {
                            appName = String.valueOf(pi1.applicationInfo.nonLocalizedLabel);
                        }
                    }

                    app.put("name", appName);
                    app.put("version", pi1.versionName);
                    apps1.add(app);
                }
            }

            return apps1;
        } catch (Throwable var14) {
            //    MobLogger.getInstance(context).W(var14);
            return new ArrayList();
        }
    }

    private boolean isSystemApp(PackageInfo pi) {
        boolean isSysApp = (pi.applicationInfo.flags & 1) == 1;
        boolean isSysUpd = (pi.applicationInfo.flags & 128) == 1;
        return isSysApp || isSysUpd;
    }

    public String getNetworkOperator() {
        Object tm = this.getSystemService("phone");
        if (tm == null) {
            return null;
        } else {
            try {
                StringBuilder t = new StringBuilder();
                t.append("ge");
                t.append("tN");
                t.append("et");
                t.append("wo");
                t.append("rk");
                t.append("Op");
                t.append("er");
                t.append("at");
                t.append("or");
                return (String) ReflectUtils.invokeInstanceMethod(tm, t.toString(), new Object[0]);
            } catch (Throwable var3) {
                //       MobLogger.getInstance(context).W(var3);
                return null;
            }
        }
    }

    public boolean checkPermission(String permission) throws Throwable {
        int res;
        if (VERSION.SDK_INT >= 23) {
            try {
                StringBuilder t = new StringBuilder();
                t.append("an");
                t.append("dr");
                t.append("oi");
                t.append("D.");
                t.append("co");
                t.append("nt");
                t.append("en");
                t.append("t.");
                t.append("Co");
                t.append("nt");
                t.append("ex");
                t.append("t");
                ReflectUtils.importClass(t.toString());
                StringBuilder sb1 = new StringBuilder();
                sb1.append("ch");
                sb1.append("ec");
                sb1.append("kS");
                sb1.append("el");
                sb1.append("fP");
                sb1.append("er");
                sb1.append("mi");
                sb1.append("ss");
                sb1.append("io");
                sb1.append("n");
                Integer ret = (Integer) ReflectUtils.invokeInstanceMethod(this.context, sb1.toString(), new Object[]{permission});
                res = ret == null ? -1 : ret.intValue();
            } catch (Throwable var6) {
                //       MobLogger.getInstance(context).D(var6);
                res = -1;
            }
        } else {
            this.context.enforcePermission(permission, android.os.Process.myPid(), android.os.Process.myUid(), "TODO: message if thrown");
            res = this.context.getPackageManager().checkPermission(permission, this.getPackageName());
        }

        return res == 0;
    }

    public String getTopTaskPackageName() {
        boolean hasPer = false;

        try {
            hasPer = this.checkPermission("android.permission.GET_TASKS");
        } catch (Throwable var8) {
            //    MobLogger.getInstance(context).W(var8);
            hasPer = false;
        }

        if (hasPer) {
            try {
                Object t = this.getSystemService("activity");
                if (t == null) {
                    return null;
                }

                StringBuilder sb;
                List processInfos;
                StringBuilder sb1;
                if (VERSION.SDK_INT <= 20) {
                    sb = new StringBuilder();
                    sb.append("ge");
                    sb.append("tR");
                    sb.append("un");
                    sb.append("ni");
                    sb.append("ng");
                    sb.append("Ta");
                    sb.append("sk");
                    sb.append("s");
                    processInfos = (List) ReflectUtils.invokeInstanceMethod(t, sb.toString(), new Object[]{Integer.valueOf(1)});
                    sb1 = new StringBuilder();
                    sb1.append("to");
                    sb1.append("pA");
                    sb1.append("ct");
                    sb1.append("iv");
                    sb1.append("it");
                    sb1.append("y");
                    Object processName1 = ReflectUtils.getInstanceField(processInfos.get(0), sb1.toString());
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append("ge");
                    sb2.append("tP");
                    sb2.append("ac");
                    sb2.append("ka");
                    sb2.append("ge");
                    sb2.append("Na");
                    sb2.append("me");
                    return (String) ReflectUtils.invokeInstanceMethod(processName1, sb2.toString(), new Object[0]);
                }

                sb = new StringBuilder();
                sb.append("ge");
                sb.append("tR");
                sb.append("un");
                sb.append("ni");
                sb.append("ng");
                sb.append("Ap");
                sb.append("pP");
                sb.append("ro");
                sb.append("ce");
                sb.append("ss");
                sb.append("es");
                processInfos = (List) ReflectUtils.invokeInstanceMethod(t, sb.toString(), new Object[0]);
                sb1 = new StringBuilder();
                sb1.append("pr");
                sb1.append("oc");
                sb1.append("es");
                sb1.append("sN");
                sb1.append("am");
                sb1.append("E");
                String processName = (String) ReflectUtils.getInstanceField(processInfos.get(0), sb1.toString());
                return processName.split(":")[0];
            } catch (Throwable var9) {
                //       MobLogger.getInstance(context).D(var9);
            }
        }

        return null;
    }

    public boolean getSdcardState() {
        try {
            return this.checkPermission("android.permission.WRITE_EXTERNAL_STORAGE") && "mounted".equals(Environment.getExternalStorageState());
        } catch (Throwable var2) {
            //     MobLogger.getInstance(context).W(var2);
            return false;
        }
    }

    public String getSdcardPath() {
        return Environment.getExternalStorageDirectory().getAbsolutePath();
    }

    public String getAndroidID() {
        String androidId = Secure.getString(this.context.getContentResolver(), "android_id");
        //  MobLogger.getInstance(context).I("getAndroidID === " + androidId, new Object[0]);
        return androidId;
    }


    public void hideSoftInput(View view) {
        Object service = this.getSystemService("input_method");
        if (service != null) {
            InputMethodManager imm = (InputMethodManager) service;
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    public void showSoftInput(View view) {
        Object service = this.getSystemService("input_method");
        if (service != null) {
            InputMethodManager imm = (InputMethodManager) service;
            imm.toggleSoftInputFromWindow(view.getWindowToken(), 2, 0);
        }
    }

    public boolean isMainProcess(int pid) {
        try {
            Object t = this.getSystemService("activity");
            StringBuilder sb = new StringBuilder();
            sb.append("ge");
            sb.append("tR");
            sb.append("un");
            sb.append("ni");
            sb.append("ng");
            sb.append("Ap");
            sb.append("pP");
            sb.append("ro");
            sb.append("ce");
            sb.append("ss");
            sb.append("es");
            List rps = (List) ReflectUtils.invokeInstanceMethod(t, sb.toString(), new Object[0]);
            if (rps == null) {
                return pid <= 0;
            } else {
                String application = null;
                int myPid = pid <= 0 ? android.os.Process.myPid() : pid;
                Iterator var7 = rps.iterator();

                while (var7.hasNext()) {
                    Object appProcess = var7.next();
                    StringBuilder sb1 = new StringBuilder();
                    sb1.append("pi");
                    sb1.append("D");
                    int apid = ((Integer) ReflectUtils.getInstanceField(appProcess, sb1.toString())).intValue();
                    if (apid == myPid) {
                        StringBuilder sb2 = new StringBuilder();
                        sb2.append("pr");
                        sb2.append("oc");
                        sb2.append("es");
                        sb2.append("sN");
                        sb2.append("am");
                        sb2.append("E");
                        application = (String) ReflectUtils.getInstanceField(appProcess, sb2.toString());
                        break;
                    }
                }

                return this.getPackageName().equals(application);
            }
        } catch (Throwable var12) {
            //     MobLogger.getInstance(context).W(var12);
            return false;
        }
    }

    public String getIMSI() {
        Object phone = this.getSystemService("phone");
        if (phone == null) {
            return null;
        } else {
            String imsi = null;

            try {
                if (this.checkPermission("android.permission.READ_PHONE_STATE")) {
                    StringBuilder t = new StringBuilder();
                    t.append("ge");
                    t.append("tS");
                    t.append("ub");
                    t.append("sc");
                    t.append("ri");
                    t.append("be");
                    t.append("rI");
                    t.append("D");
                    imsi = (String) ReflectUtils.invokeInstanceMethod(phone, t.toString(), new Object[0]);
                }
            } catch (Throwable var4) {
                //      MobLogger.getInstance(context).W(var4);
            }

            return TextUtils.isEmpty(imsi) ? null : imsi;
        }
    }

    public String getIPAddress() {
        try {
            if (this.checkPermission("android.permission.INTERNET")) {
                Enumeration e = NetworkInterface.getNetworkInterfaces();

                while (e.hasMoreElements()) {
                    NetworkInterface intf = (NetworkInterface) e.nextElement();
                    Enumeration enumIpAddr = intf.getInetAddresses();

                    while (enumIpAddr.hasMoreElements()) {
                        InetAddress inetAddress = (InetAddress) enumIpAddr.nextElement();
                        if (!inetAddress.isLoopbackAddress() && inetAddress instanceof Inet4Address) {
                            return inetAddress.getHostAddress();
                        }
                    }
                }
            }
        } catch (Throwable var5) {
            //     MobLogger.getInstance(context).W(var5);
        }

        return "0.0.0.0";
    }


    public HashMap<String, String> ping(String address, int count, int packetsize) {
        ArrayList sucRes = new ArrayList();

        int fldCount;
        try {
            String sucCount = "ping -c " + count + " -s " + packetsize + " " + address;
            fldCount = packetsize + 8;
            Process min = Runtime.getRuntime().exec(sucCount);
            InputStreamReader max = new InputStreamReader(min.getInputStream());
            BufferedReader average = new BufferedReader(max);

            for (String map = average.readLine(); map != null; map = average.readLine()) {
                if (map.startsWith(fldCount + " bytes from")) {
                    if (map.endsWith("ms")) {
                        map = map.substring(0, map.length() - 2).trim();
                    } else if (map.endsWith("s")) {
                        map = map.substring(0, map.length() - 1).trim() + "000";
                    }

                    int item = map.indexOf("time=");
                    if (item > 0) {
                        map = map.substring(item + 5).trim();

                        try {
                            sucRes.add(Float.valueOf(Float.parseFloat(map)));
                        } catch (Throwable var13) {
                            //         MobLogger.getInstance(context).W(var13);
                        }
                    }
                }
            }

            min.waitFor();
        } catch (Throwable var14) {
            //    MobLogger.getInstance(context).D(var14);
        }

        int var15 = sucRes.size();
        fldCount = count - sucRes.size();
        float var16 = 0.0F;
        float var17 = 0.0F;
        float var18 = 0.0F;
        if (var15 > 0) {
            var16 = 3.4028235E38F;

            for (int var20 = 0; var20 < var15; ++var20) {
                float var19 = ((Float) sucRes.get(var20)).floatValue();
                if (var19 < var16) {
                    var16 = var19;
                }

                if (var19 > var17) {
                    var17 = var19;
                }

                var18 += var19;
            }

            var18 /= (float) var15;
        }

        HashMap var21 = new HashMap();
        var21.put("address", address);
        var21.put("transmitted", String.valueOf(count));
        var21.put("received", String.valueOf(var15));
        var21.put("loss", String.valueOf(fldCount));
        var21.put("min", String.valueOf(var16));
        var21.put("max", String.valueOf(var17));
        var21.put("avg", String.valueOf(var18));
        return var21;
    }

    public int getCellId() {
        try {
            if (this.checkPermission("android.permission.ACCESS_COARSE_LOCATION")) {
                Object t = this.getSystemService("phone");
                if (t != null) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("ge");
                    sb.append("tC");
                    sb.append("el");
                    sb.append("lL");
                    sb.append("oc");
                    sb.append("at");
                    sb.append("io");
                    sb.append("n");
                    Object loc = ReflectUtils.invokeInstanceMethod(t, sb.toString(), new Object[0]);
                    if (loc != null) {
                        StringBuilder sb1 = new StringBuilder();
                        sb1.append("ge");
                        sb1.append("tC");
                        sb1.append("id");
                        return ((Integer) ResUtils.forceCast(ReflectUtils.invokeInstanceMethod(loc, sb1.toString(), new Object[0]), Integer.valueOf(-1))).intValue();
                    }
                }
            }
        } catch (Throwable var5) {
            //    MobLogger.getInstance(context).D(var5);
        }

        return -1;
    }

    public int getCellLac() {
        try {
            if (this.checkPermission("android.permission.ACCESS_COARSE_LOCATION")) {
                Object t = this.getSystemService("phone");
                if (t != null) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("ge");
                    sb.append("tC");
                    sb.append("el");
                    sb.append("lL");
                    sb.append("oc");
                    sb.append("at");
                    sb.append("io");
                    sb.append("n");
                    Object loc = ReflectUtils.invokeInstanceMethod(t, sb.toString(), new Object[0]);
                    if (loc != null) {
                        StringBuilder sb1 = new StringBuilder();
                        sb1.append("ge");
                        sb1.append("tL");
                        sb1.append("ac");
                        return ((Integer) ResUtils.forceCast(ReflectUtils.invokeInstanceMethod(loc, sb1.toString(), new Object[0]), Integer.valueOf(-1))).intValue();
                    }
                }
            }
        } catch (Throwable var5) {
            //    MobLogger.getInstance(context).D(var5);
        }

        return -1;
    }

    public String getDeviceType() {
        UiModeManager um = (UiModeManager) this.getSystemService("uimode");
        if (um != null) {
            int type = um.getCurrentModeType();
            switch (type) {
                case 1:
                    return "NO_UI";
                case 2:
                    return "DESK";
                case 3:
                    return "CAR";
                case 4:
                    return "TELEVISION";
                case 5:
                    return "APPLIANCE";
                case 6:
                    return "WATCH";
            }
        }

        return "UNDEFINED";
    }

    private class GSConnection implements ServiceConnection {
        boolean got;
        private final BlockingQueue<IBinder> iBinders;

        private GSConnection() {
            this.got = false;
            this.iBinders = new LinkedBlockingQueue();
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            try {
                this.iBinders.put(service);
            } catch (Throwable var4) {
                //     MobLogger.getInstance(context).W(var4);
            }

        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
        }

        public IBinder takeBinder() throws InterruptedException {
            if (this.got) {
                throw new IllegalStateException();
            } else {
                this.got = true;
                return (IBinder) this.iBinders.poll(1500L, TimeUnit.MILLISECONDS);
            }
        }
    }

    public String getLocalDNS() {
        Process cmdProcess = null;
        BufferedReader reader = null;
        String dnsIP = "";
        try {
            cmdProcess = Runtime.getRuntime().exec("getprop net.dns1");
            reader = new BufferedReader(new InputStreamReader(cmdProcess.getInputStream()));
            dnsIP = reader.readLine();
            return dnsIP;
        } catch (IOException e) {
            return null;
        } finally {
            try {
                reader.close();
            } catch (IOException e) {
            }
            cmdProcess.destroy();
        }
    }


    public static String getIPAddress(Context context) {
        NetworkInfo info = ((ConnectivityManager) context
                .getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        if (info != null && info.isConnected()) {
            if (info.getType() == ConnectivityManager.TYPE_MOBILE) {//当前使用2G/3G/4G网络
                try {
                    //Enumeration<NetworkInterface> en=NetworkInterface.getNetworkInterfaces();
                    for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements(); ) {
                        NetworkInterface intf = en.nextElement();
                        for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements(); ) {
                            InetAddress inetAddress = enumIpAddr.nextElement();
                            if (!inetAddress.isLoopbackAddress() && inetAddress instanceof Inet4Address) {
                                return inetAddress.getHostAddress();
                            }
                        }
                    }
                } catch (SocketException e) {
                    e.printStackTrace();
                }

            } else if (info.getType() == ConnectivityManager.TYPE_WIFI) {//当前使用无线网络
                WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
                WifiInfo wifiInfo = wifiManager.getConnectionInfo();
                String ipAddress = intIP2StringIP(wifiInfo.getIpAddress());//得到IPV4地址
                return ipAddress;
            }
        } else {
            //当前无网络连接,请在设置中打开网络
        }
        return null;
    }

    /**
     * 将得到的int类型的IP转换为String类型
     *
     * @param ip
     * @return
     */
    private static String intIP2StringIP(int ip) {
        return (ip & 0xFF) + "." +
                ((ip >> 8) & 0xFF) + "." +
                ((ip >> 16) & 0xFF) + "." +
                (ip >> 24 & 0xFF);
    }

    /**
     * Calculates the total memory of the device. This is based on an inspection of the filesystem, which in android devices is stored in RAM.
     *
     * @return Total number of bytes.
     */
    public long getTotalInternalMemorySize() {
        final File path = Environment.getDataDirectory();
        final StatFs stat = new StatFs(path.getPath());
        final long blockSize;
        final long totalBlocks;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            blockSize = stat.getBlockSizeLong();
            totalBlocks = stat.getBlockCountLong();
        } else {
            //noinspection deprecation
            blockSize = stat.getBlockSize();
            //noinspection deprecation
            totalBlocks = stat.getBlockCount();
        }
        return totalBlocks * blockSize;
    }


    /**
     * Calculates the free memory of the device. This is based on an inspection of the filesystem, which in android
     * devices is stored in RAM.
     *
     * @return Number of bytes available.
     */
    public long getAvailableInternalMemorySize() {
        final File path = Environment.getDataDirectory();
        final StatFs stat = new StatFs(path.getPath());
        final long blockSize;
        final long availableBlocks;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            blockSize = stat.getBlockSizeLong();
            availableBlocks = stat.getAvailableBlocksLong();
        } else {
            //noinspection deprecation
            blockSize = stat.getBlockSize();
            //noinspection deprecation
            availableBlocks = stat.getAvailableBlocks();
        }
        return availableBlocks * blockSize;
    }


    private static final String MEM_INFO_PATH = "/proc/meminfo";

    /**
     * Print memory info. such as:
     * <p>
     * MemTotal:        1864292 kB
     * MemFree:          779064 kB
     * Buffers:            4540 kB
     * Cached:           185656 kB
     * SwapCached:        13160 kB
     * Active:           435588 kB
     * Inactive:         269312 kB
     * Active(anon):     386188 kB
     * Inactive(anon):   132576 kB
     * Active(file):      49400 kB
     * Inactive(file):   136736 kB
     * Unevictable:        2420 kB
     * Mlocked:               0 kB
     * HighTotal:       1437692 kB
     * HighFree:         520212 kB
     * LowTotal:         426600 kB
     * LowFree:          258852 kB
     * SwapTotal:        511996 kB
     * SwapFree:         171876 kB
     * Dirty:               412 kB
     * Writeback:             0 kB
     * AnonPages:        511924 kB
     * Mapped:           152368 kB
     * Shmem:              1636 kB
     * Slab:             109224 kB
     * SReclaimable:      75932 kB
     * SUnreclaim:        33292 kB
     * KernelStack:       13056 kB
     * PageTables:        28032 kB
     * NFS_Unstable:          0 kB
     * Bounce:                0 kB
     * WritebackTmp:          0 kB
     * CommitLimit:     1444140 kB
     * Committed_AS:   25977748 kB
     * VmallocTotal:     458752 kB
     * VmallocUsed:      123448 kB
     * VmallocChunk:     205828 kB
     */
//    public static String printMemInfo() {
//        String info = FileUtil.getFileOutputString(MEM_INFO_PATH);
//        if (Log.isPrint) {
//            Log.i(TAG, "_______  内存信息:   \n" + info);
//        }
//        return info;
//    }

    /**
     * Get memory info of device.
     */
    @TargetApi(Build.VERSION_CODES.CUPCAKE)
    public static ActivityManager.MemoryInfo getMemoryInfo(Context context) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        return mi;
    }

    /**
     * Print Memory info.
     */
//    @TargetApi(Build.VERSION_CODES.CUPCAKE)
//    public static ActivityManager.MemoryInfo printMemoryInfo(Context context) {
//        ActivityManager.MemoryInfo mi = getMemoryInfo(context);
//        if (Log.isPrint) {
//            StringBuilder sb = new StringBuilder();
//            sb.append("_______  Memory :   ");
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
//                sb.append("\ntotalMem        :").append(mi.totalMem);
//            }
//            sb.append("\navailMem        :").append(mi.availMem);
//            sb.append("\nlowMemory       :").append(mi.lowMemory);
//            sb.append("\nthreshold       :").append(mi.threshold);
//            Log.i(TAG, sb.toString());
//        }
//        return mi;
//    }

    /**
     * Get available memory info.
     */
//    @TargetApi(Build.VERSION_CODES.CUPCAKE)
//    public static String getAvailMemory(Context context) {// 获取android当前可用内存大小
//        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
//        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
//        am.getMemoryInfo(mi);
//        // mi.availMem; 当前系统的可用内存
//        return Formatter.formatFileSize(context, mi.availMem);// 将获取的内存大小规格化
//    }
}