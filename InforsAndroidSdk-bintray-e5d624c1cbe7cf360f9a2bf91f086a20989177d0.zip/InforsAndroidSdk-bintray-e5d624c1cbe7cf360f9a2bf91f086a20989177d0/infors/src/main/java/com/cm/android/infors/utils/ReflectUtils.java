package com.cm.android.infors.utils;

/**
 * @author wusm
 */


import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;
/**
 * @author wusm
 */

public class ReflectUtils {
    private static HashSet<String> packageSet = new HashSet();
    private static HashMap<String, Class<?>> classMap;
    private static HashMap<Object, Object> nameMap;
    private static CachePool<String, Method> cachedMethod;
    private static CachePool<String, Constructor<?>> cachedConstr;

    public ReflectUtils() {
    }

    public static String importClass(String className) throws Throwable {
        return importClass((String)null, className);
    }

    public static synchronized String importClass(String name, String className) throws Throwable {
        if(className.endsWith(".*")) {
            packageSet.add(className.substring(0, className.length() - 2));
            return "*";
        } else {
            Class clz = Class.forName(className);
            if(name == null) {
                name = clz.getSimpleName();
            }

            classMap.put(name, clz);
            nameMap.put(clz, name);
            return name;
        }
    }

    private static synchronized Class<?> getImportedClass(String className) {
        Class clz = (Class)classMap.get(className);
        if(clz == null) {
            Iterator var2 = packageSet.iterator();

            while(var2.hasNext()) {
                String packageName = (String)var2.next();

                try {
                    importClass(packageName + "." + className);
                } catch (Throwable var5) {
                    ;
                }

                clz = (Class)classMap.get(className);
                if(clz != null) {
                    break;
                }
            }
        }

        return clz;
    }

    private static Class<?>[] getTypes(Object[] args) {
        Class[] types = new Class[args.length];

        for(int i = 0; i < args.length; ++i) {
            types[i] = args[i] == null?null:args[i].getClass();
        }

        return types;
    }

    private static boolean primitiveEquals(Class<?> primitive, Class<?> target) {
        return primitive == Byte.TYPE && target == Byte.class || primitive == Short.TYPE && (target == Short.class || target == Byte.class || target == Character.class) || primitive == Character.TYPE && (target == Character.class || target == Short.class || target == Byte.class) || primitive == Integer.TYPE && (target == Integer.class || target == Short.class || target == Byte.class || target == Character.class) || primitive == Long.TYPE && (target == Long.class || target == Integer.class || target == Short.class || target == Byte.class || target == Character.class) || primitive == Float.TYPE && (target == Float.class || target == Long.class || target == Integer.class || target == Short.class || target == Byte.class || target == Character.class) || primitive == Double.TYPE && (target == Double.class || target == Float.class || target == Long.class || target == Integer.class || target == Short.class || target == Byte.class || target == Character.class) || primitive == Boolean.TYPE && target == Boolean.class;
    }

    private static boolean matchParams(Class<?>[] mTypes, Class<?>[] types) {
        if(mTypes.length != types.length) {
            return false;
        } else {
            boolean match = true;

            for(int i = 0; i < types.length; ++i) {
                if(types[i] != null && !primitiveEquals(mTypes[i], types[i]) && !mTypes[i].isAssignableFrom(types[i])) {
                    match = false;
                    break;
                }
            }

            return match;
        }
    }

    private static boolean tryMatchParams(Class<?>[] mTypes, Class<?>[] types) {
        if(mTypes.length - types.length != 1) {
            return false;
        } else {
            boolean match = true;

            for(int i = 0; i < types.length; ++i) {
                if(types[i] != null && !primitiveEquals(mTypes[i], types[i]) && !mTypes[i].isAssignableFrom(types[i])) {
                    match = false;
                    break;
                }
            }

            return match && mTypes[mTypes.length - 1].isArray();
        }
    }

    public static Object newInstance(String className, Object... args) throws Throwable {
        try {
            return onNewInstance(className, args);
        } catch (Throwable var4) {
            if(var4 instanceof NoSuchMethodException) {
                throw var4;
            } else {
                String msg = "className: " + className + ", methodName: <init>";
                throw new Throwable(msg, var4);
            }
        }
    }

    private static Object onNewInstance(String className, Object... args) throws Throwable {
        if(className.startsWith("[")) {
            return newArray(className, args);
        } else {
            String mthSign = className + "#" + args.length;
            Constructor con = (Constructor)cachedConstr.get(mthSign);
            Class[] types = getTypes(args);
            if(con != null && matchParams(con.getParameterTypes(), types)) {
                con.setAccessible(true);
                return con.newInstance(args);
            } else {
                Class clz = getImportedClass(className);
                Constructor[] cons = clz.getDeclaredConstructors();
                ArrayList overloads = new ArrayList();
                ArrayList paramsTypes = new ArrayList();
                Constructor[] i = cons;
                int paramTypes = cons.length;

                for(int componentType = 0; componentType < paramTypes; ++componentType) {
                    Constructor isElement = i[componentType];
                    Class[] arrLen = isElement.getParameterTypes();
                    if(matchParams(arrLen, types)) {
                        cachedConstr.put(mthSign, isElement);
                        isElement.setAccessible(true);
                        return isElement.newInstance(args);
                    }

                    if(arrLen.length > 0 && arrLen[arrLen.length - 1].isArray() && types.length >= arrLen.length - 1) {
                        overloads.add(isElement);
                        paramsTypes.add(arrLen);
                    }
                }

                for(int var17 = 0; var17 < paramsTypes.size(); ++var17) {
                    Class[] var18 = (Class[])paramsTypes.get(var17);
                    Class var19 = var18[var18.length - 1].getComponentType();
                    if(tryMatchParams(var18, types)) {
                        Object[] var21 = new Object[args.length + 1];
                        System.arraycopy(args, 0, var21, 0, args.length);
                        var21[args.length] = Array.newInstance(var19, 0);
                        Constructor var23 = (Constructor)overloads.get(var17);
                        var23.setAccessible(true);
                        return var23.newInstance(args);
                    }

                    boolean var20 = true;

                    int var22;
                    for(var22 = var18.length - 1; var22 < types.length; ++var22) {
                        if(!types[var22].equals(var19)) {
                            var20 = false;
                            break;
                        }
                    }

                    if(var20) {
                        var22 = types.length - var18.length + 1;
                        Object arr = Array.newInstance(var19, var22);

                        for(int newArgs = 0; newArgs < var22; ++newArgs) {
                            Array.set(arr, newArgs, args[var18.length - 1 + newArgs]);
                        }

                        Object[] var24 = new Object[args.length + 1];
                        System.arraycopy(args, 0, var24, 0, args.length);
                        var24[args.length] = arr;
                        Constructor c = (Constructor)overloads.get(var17);
                        c.setAccessible(true);
                        return c.newInstance(args);
                    }
                }

                throw new NoSuchMethodException("className: " + className + ", methodName: <init>");
            }
        }
    }

    private static Object newArray(String className, Object... args) throws Throwable {
        String tmp = className;

        int dimension;
        for(dimension = 0; tmp.startsWith("["); tmp = tmp.substring(1)) {
            ++dimension;
        }

        int[] lens = null;
        if(dimension == args.length) {
            lens = new int[dimension];

            for(int eleClz = 0; eleClz < dimension; ++eleClz) {
                try {
                    lens[eleClz] = Integer.parseInt(String.valueOf(args[eleClz]));
                } catch (Throwable var7) {
                    lens = null;
                    break;
                }
            }
        }

        if(lens != null) {
            Class var8 = null;
            if("B".equals(tmp)) {
                var8 = Byte.TYPE;
            } else if("S".equals(tmp)) {
                var8 = Short.TYPE;
            } else if("I".equals(tmp)) {
                var8 = Integer.TYPE;
            } else if("J".equals(tmp)) {
                var8 = Long.TYPE;
            } else if("F".equals(tmp)) {
                var8 = Float.TYPE;
            } else if("D".equals(tmp)) {
                var8 = Double.TYPE;
            } else if("Z".equals(tmp)) {
                var8 = Boolean.TYPE;
            } else if("C".equals(tmp)) {
                var8 = Character.TYPE;
            } else {
                var8 = getImportedClass(tmp);
            }

            if(var8 != null) {
                return Array.newInstance(var8, lens);
            }
        }

        throw new NoSuchMethodException("className: [" + className + ", methodName: <init>");
    }

    public static <T> T invokeStaticMethod(String className, String methodName, Object... args) throws Throwable {
        try {
            return invokeMethod(className, (Object)null, methodName, args);
        } catch (Throwable var5) {
            if(var5 instanceof NoSuchMethodException) {
                throw var5;
            } else {
                String msg = "className: " + className + ", methodName: " + methodName;
                throw new Throwable(msg, var5);
            }
        }
    }

    private static <T> T invokeMethod(String className, Object receiver, String methodName, Object... args) throws Throwable {
        Class clz;
        if(receiver == null) {
            clz = getImportedClass(className);
        } else {
            clz = receiver.getClass();
        }

        String mthSign = clz.getName() + "#" + methodName + "#" + args.length;
        Method mth = (Method)cachedMethod.get(mthSign);
        Class[] types = getTypes(args);
        if(mth != null) {
            boolean clzs = Modifier.isStatic(mth.getModifiers());
            boolean overloads = receiver == null?clzs:!clzs;
            if(overloads && matchParams(mth.getParameterTypes(), types)) {
                mth.setAccessible(true);
                if(mth.getReturnType() == Void.TYPE) {
                    mth.invoke(receiver, args);
                    return null;
                }

                return (T) mth.invoke(receiver, args);
            }
        }

        ArrayList var21;
        for(var21 = new ArrayList(); clz != null; clz = clz.getSuperclass()) {
            var21.add(clz);
        }

        ArrayList var22 = new ArrayList();
        ArrayList paramsTypes = new ArrayList();
        Iterator i = var21.iterator();

        int arrLen;
        while(i.hasNext()) {
            Class paramTypes = (Class)i.next();
            Method[] componentType = paramTypes.getDeclaredMethods();
            Method[] isElement = componentType;
            arrLen = componentType.length;

            for(int arr = 0; arr < arrLen; ++arr) {
                Method newArgs = isElement[arr];
                boolean m = Modifier.isStatic(newArgs.getModifiers());
                boolean modifier = receiver == null?m:!m;
                if(newArgs.getName().equals(methodName) && modifier) {
                    Class[] paramTypes1 = newArgs.getParameterTypes();
                    if(matchParams(paramTypes1, types)) {
                        cachedMethod.put(mthSign, newArgs);
                        newArgs.setAccessible(true);
                        if(newArgs.getReturnType() == Void.TYPE) {
                            newArgs.invoke(receiver, args);
                            return null;
                        }

                        return (T) newArgs.invoke(receiver, args);
                    }

                    if(paramTypes1.length > 0 && paramTypes1[paramTypes1.length - 1].isArray() && types.length >= paramTypes1.length - 1) {
                        var22.add(newArgs);
                        paramsTypes.add(paramTypes1);
                    }
                }
            }
        }

        for(int var23 = 0; var23 < paramsTypes.size(); ++var23) {
            Class[] var24 = (Class[])paramsTypes.get(var23);
            Class var25 = var24[var24.length - 1].getComponentType();
            if(tryMatchParams(var24, types)) {
                Object[] var27 = new Object[args.length + 1];
                System.arraycopy(args, 0, var27, 0, args.length);
                var27[args.length] = Array.newInstance(var25, 0);
                Method var28 = (Method)var22.get(var23);
                var28.setAccessible(true);
                if(var28.getReturnType() == Void.TYPE) {
                    var28.invoke(receiver, var27);
                    return null;
                }

                return (T) var28.invoke(receiver, var27);
            }

            boolean var26 = true;

            for(arrLen = var24.length - 1; arrLen < types.length; ++arrLen) {
                if(!types[arrLen].equals(var25)) {
                    var26 = false;
                    break;
                }
            }

            if(var26) {
                arrLen = types.length - var24.length + 1;
                Object var29 = Array.newInstance(var25, arrLen);

                for(int var30 = 0; var30 < arrLen; ++var30) {
                    Array.set(var29, var30, args[var24.length - 1 + var30]);
                }

                Object[] var31 = new Object[var24.length];
                System.arraycopy(args, 0, var31, 0, var24.length - 1);
                var31[var24.length - 1] = var29;
                Method var32 = (Method)var22.get(var23);
                var32.setAccessible(true);
                if(var32.getReturnType() == Void.TYPE) {
                    var32.invoke(receiver, var31);
                    return null;
                }

                return (T) var32.invoke(receiver, var31);
            }
        }

        throw new NoSuchMethodException("className: " + receiver.getClass() + ", methodName: " + methodName);
    }

    public static <T> T invokeInstanceMethod(Object receiver, String methodName, Object... args) throws Throwable {
        try {
            return invokeMethod((String)null, receiver, methodName, args);
        } catch (Throwable var5) {
            if(var5 instanceof NoSuchMethodException) {
                throw var5;
            } else {
                String msg = "className: " + receiver.getClass() + ", methodName: " + methodName;
                throw new Throwable(msg, var5);
            }
        }
    }

    public static <T> T getStaticField(String className, String fieldName) throws Throwable {
        try {
            return onGetStaticField(className, fieldName);
        } catch (Throwable var4) {
            if(var4 instanceof NoSuchFieldException) {
                throw var4;
            } else {
                String msg = "className: " + className + ", fieldName: " + fieldName;
                throw new Throwable(msg, var4);
            }
        }
    }

    private static <T> T onGetStaticField(String className, String fieldName) throws Throwable {
        ArrayList clzs = new ArrayList();

        for(Class clz = getImportedClass(className); clz != null; clz = clz.getSuperclass()) {
            clzs.add(clz);
        }

        Iterator var4 = clzs.iterator();

        while(var4.hasNext()) {
            Class c = (Class)var4.next();
            Field fld = null;

            try {
                fld = c.getDeclaredField(fieldName);
            } catch (Throwable var8) {
                ;
            }

            if(fld != null && Modifier.isStatic(fld.getModifiers())) {
                fld.setAccessible(true);
                return (T) fld.get((Object)null);
            }
        }

        throw new NoSuchFieldException("className: " + className + ", fieldName: " + fieldName);
    }

    public static void setStaticField(String className, String fieldName, Object value) throws Throwable {
        try {
            onSetStaticField(className, fieldName, value);
        } catch (Throwable var5) {
            if(var5 instanceof NoSuchFieldException) {
                throw var5;
            } else {
                String msg = "className: " + className + ", fieldName: " + fieldName + ", value: " + value;
                throw new Throwable(msg, var5);
            }
        }
    }

    private static void onSetStaticField(String className, String fieldName, Object value) throws Throwable {
        ArrayList clzs = new ArrayList();

        for(Class clz = getImportedClass(className); clz != null; clz = clz.getSuperclass()) {
            clzs.add(clz);
        }

        Iterator var5 = clzs.iterator();

        while(var5.hasNext()) {
            Class c = (Class)var5.next();
            Field fld = null;

            try {
                fld = c.getDeclaredField(fieldName);
            } catch (Throwable var9) {
                ;
            }

            if(fld != null && Modifier.isStatic(fld.getModifiers())) {
                fld.setAccessible(true);
                fld.set((Object)null, value);
                return;
            }
        }

        throw new NoSuchFieldException("className: " + className + ", fieldName: " + fieldName + ", value: " + value);
    }

    public static <T> T getInstanceField(Object receiver, String fieldName) throws Throwable {
        try {
            return onGetInstanceField(receiver, fieldName);
        } catch (Throwable var4) {
            if(var4 instanceof NoSuchFieldException) {
                throw var4;
            } else {
                String msg = "className: " + receiver.getClass() + ", fieldName: " + fieldName;
                throw new Throwable(msg, var4);
            }
        }
    }

    private static <T> T onGetInstanceField(Object receiver, String fieldName) throws Throwable {
        if(receiver.getClass().isArray()) {
            return (T) onGetElement(receiver, fieldName);
        } else {
            ArrayList clzs = new ArrayList();

            for(Class clz = receiver.getClass(); clz != null; clz = clz.getSuperclass()) {
                clzs.add(clz);
            }

            Iterator var4 = clzs.iterator();

            while(var4.hasNext()) {
                Class c = (Class)var4.next();
                Field fld = null;

                try {
                    fld = c.getDeclaredField(fieldName);
                } catch (Throwable var8) {
                    ;
                }

                if(fld != null && !Modifier.isStatic(fld.getModifiers())) {
                    fld.setAccessible(true);
                    return (T) fld.get(receiver);
                }
            }

            throw new NoSuchFieldException("className: " + receiver.getClass() + ", fieldName: " + fieldName);
        }
    }

    private static Object onGetElement(Object receiver, String fieldName) throws Throwable {
        if("length".equals(fieldName)) {
            return Integer.valueOf(Array.getLength(receiver));
        } else {
            if(fieldName.startsWith("[") && fieldName.endsWith("]")) {
                int index = -1;

                try {
                    String strIndex = fieldName.substring(1, fieldName.length() - 1);
                    index = Integer.parseInt(strIndex);
                } catch (Throwable var4) {
                    ;
                }

                if(index != -1) {
                    return Array.get(receiver, index);
                }
            }

            throw new NoSuchFieldException("className: " + receiver.getClass() + ", fieldName: " + fieldName);
        }
    }

    public static void setInstanceField(Object receiver, String fieldName, Object value) throws Throwable {
        try {
            onSetInstanceField(receiver, fieldName, value);
        } catch (Throwable var5) {
            if(var5 instanceof NoSuchFieldException) {
                throw var5;
            } else {
                String msg = "className: " + receiver.getClass() + ", fieldName: " + fieldName + ", value: " + value;
                throw new Throwable(msg, var5);
            }
        }
    }

    private static void onSetInstanceField(Object receiver, String fieldName, Object value) throws Throwable {
        if(receiver.getClass().isArray()) {
            onSetElement(receiver, fieldName, value);
        } else {
            ArrayList clzs = new ArrayList();

            for(Class clz = receiver.getClass(); clz != null; clz = clz.getSuperclass()) {
                clzs.add(clz);
            }

            Iterator var5 = clzs.iterator();

            while(var5.hasNext()) {
                Class c = (Class)var5.next();
                Field fld = null;

                try {
                    fld = c.getDeclaredField(fieldName);
                } catch (Throwable var9) {
                    ;
                }

                if(fld != null && !Modifier.isStatic(fld.getModifiers())) {
                    fld.setAccessible(true);
                    fld.set(receiver, value);
                    return;
                }
            }

            throw new NoSuchFieldException("className: " + receiver.getClass() + ", fieldName: " + fieldName + ", value: " + value);
        }
    }

    private static void onSetElement(Object receiver, String fieldName, Object value) throws Throwable {
        if(fieldName.startsWith("[") && fieldName.endsWith("]")) {
            int index = -1;

            String recClzName;
            try {
                recClzName = fieldName.substring(1, fieldName.length() - 1);
                index = Integer.parseInt(recClzName);
            } catch (Throwable var7) {
                ;
            }

            if(index != -1) {
                for(recClzName = receiver.getClass().getName(); recClzName.startsWith("["); recClzName = recClzName.substring(1)) {
                    ;
                }

                Class vClass = value.getClass();
                if("B".equals(recClzName)) {
                    if(vClass == Byte.class) {
                        Array.set(receiver, index, value);
                        return;
                    }
                } else {
                    Object dValue;
                    if("S".equals(recClzName)) {
                        dValue = null;
                        if(vClass == Short.class) {
                            dValue = value;
                        } else if(vClass == Byte.class) {
                            dValue = Short.valueOf((short)((Byte)value).byteValue());
                        }

                        if(dValue != null) {
                            Array.set(receiver, index, dValue);
                            return;
                        }
                    } else if("I".equals(recClzName)) {
                        dValue = null;
                        if(vClass == Integer.class) {
                            dValue = value;
                        } else if(vClass == Short.class) {
                            dValue = Integer.valueOf(((Short)value).shortValue());
                        } else if(vClass == Byte.class) {
                            dValue = Integer.valueOf(((Byte)value).byteValue());
                        }

                        if(dValue != null) {
                            Array.set(receiver, index, dValue);
                            return;
                        }
                    } else if("J".equals(recClzName)) {
                        dValue = null;
                        if(vClass == Long.class) {
                            dValue = value;
                        } else if(vClass == Integer.class) {
                            dValue = Long.valueOf((long)((Integer)value).intValue());
                        } else if(vClass == Short.class) {
                            dValue = Long.valueOf((long)((Short)value).shortValue());
                        } else if(vClass == Byte.class) {
                            dValue = Long.valueOf((long)((Byte)value).byteValue());
                        }

                        if(dValue != null) {
                            Array.set(receiver, index, dValue);
                            return;
                        }
                    } else if("F".equals(recClzName)) {
                        dValue = null;
                        if(vClass == Float.class) {
                            dValue = value;
                        } else if(vClass == Long.class) {
                            dValue = Float.valueOf((float)((Long)value).longValue());
                        } else if(vClass == Integer.class) {
                            dValue = Float.valueOf((float)((Integer)value).intValue());
                        } else if(vClass == Short.class) {
                            dValue = Float.valueOf((float)((Short)value).shortValue());
                        } else if(vClass == Byte.class) {
                            dValue = Float.valueOf((float)((Byte)value).byteValue());
                        }

                        if(dValue != null) {
                            Array.set(receiver, index, dValue);
                            return;
                        }
                    } else if("D".equals(recClzName)) {
                        dValue = null;
                        if(vClass == Double.class) {
                            dValue = value;
                        } else if(vClass == Float.class) {
                            dValue = Double.valueOf((double)((Float)value).floatValue());
                        } else if(vClass == Long.class) {
                            dValue = Double.valueOf((double)((Long)value).longValue());
                        } else if(vClass == Integer.class) {
                            dValue = Double.valueOf((double)((Integer)value).intValue());
                        } else if(vClass == Short.class) {
                            dValue = Double.valueOf((double)((Short)value).shortValue());
                        } else if(vClass == Byte.class) {
                            dValue = Double.valueOf((double)((Byte)value).byteValue());
                        }

                        if(dValue != null) {
                            Array.set(receiver, index, dValue);
                            return;
                        }
                    } else if("Z".equals(recClzName)) {
                        if(vClass == Boolean.class) {
                            Array.set(receiver, index, value);
                            return;
                        }
                    } else if("C".equals(recClzName)) {
                        if(vClass == Character.class) {
                            Array.set(receiver, index, value);
                            return;
                        }
                    } else if(recClzName.equals(vClass.getName())) {
                        Array.set(receiver, index, value);
                        return;
                    }
                }
            }
        }

        throw new NoSuchFieldException("className: " + receiver.getClass() + ", fieldName: " + fieldName + ", value: " + value);
    }

    public static Class<?> getClass(String name) throws Throwable {
        Class clz = getImportedClass(name);
        if(clz == null) {
            try {
                clz = Class.forName(name);
                if(clz != null) {
                    classMap.put(name, clz);
                }
            } catch (Throwable var3) {
                ;
            }
        }

        return clz;
    }

    public static String getName(Class<?> clz) throws Throwable {
        String name = (String)nameMap.get(clz);
        if(name == null) {
            name = clz.getSimpleName();
            if(classMap.containsKey(name)) {
                name = null;
            } else {
                classMap.put(name, clz);
                nameMap.put(clz, name);
            }
        }

        return name;
    }

    public static Object createProxy(final HashMap<String, ReflectRunnable> proxyHandler, Class... proxyIntefaces) throws Throwable {
        ClassLoader loader = proxyHandler.getClass().getClassLoader();
        InvocationHandler handler = new InvocationHandler() {
            @Override
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                ReflectRunnable function = (ReflectRunnable)proxyHandler.get(method.getName());
                if(function != null) {
                    return function.run(args);
                } else {
                    throw new NoSuchMethodException();
                }
            }
        };
        return Proxy.newProxyInstance(loader, proxyIntefaces, handler);
    }

    static {
        packageSet.add("java.lang");
        packageSet.add("java.io");
        packageSet.add("java.nio");
        packageSet.add("java.net");
        packageSet.add("java.util");
        packageSet.add("com.mob.tools");
        packageSet.add("com.mob.tools.gui");
        packageSet.add("com.mob.tools.log");
        packageSet.add("com.mob.tools.network");
        packageSet.add("com.mob.tools.utils");
        classMap = new HashMap();
        classMap.put("double", Double.TYPE);
        classMap.put("float", Float.TYPE);
        classMap.put("long", Long.TYPE);
        classMap.put("int", Integer.TYPE);
        classMap.put("short", Short.TYPE);
        classMap.put("byte", Byte.TYPE);
        classMap.put("char", Character.TYPE);
        classMap.put("boolean", Boolean.TYPE);
        classMap.put("Object", Object.class);
        classMap.put("String", String.class);
        classMap.put("Thread", Thread.class);
        classMap.put("Runnable", Runnable.class);
        classMap.put("System", System.class);
        classMap.put("double", Double.class);
        classMap.put("Float", Float.class);
        classMap.put("Long", Long.class);
        classMap.put("Integer", Integer.class);
        classMap.put("Short", Short.class);
        classMap.put("Byte", Byte.class);
        classMap.put("Character", Character.class);
        classMap.put("Boolean", Boolean.class);
        nameMap = new HashMap();
        Iterator var0 = classMap.entrySet().iterator();

        while(var0.hasNext()) {
            Entry ent = (Entry)var0.next();
            nameMap.put(ent.getValue(), ent.getKey());
        }

        cachedMethod = new CachePool(25);
        cachedConstr = new CachePool(5);
    }

    public interface ReflectRunnable {
        Object run(Object var1);
    }
}
