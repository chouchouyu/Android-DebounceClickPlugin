/*
 *  Copyright 2010 Emmanuel Astier &amp; Kevin Gaudin
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
package com.cm.android.infors.apm.crash;


import android.util.Log;
import com.cm.android.infors.core.Consts;
import com.cm.android.infors.core.Logger;
import com.cm.android.infors.core.report.Issue;
import com.cm.android.infors.core.ReportField;
import com.cm.android.infors.utils.DeviceUtils;
import com.cm.android.infors.utils.EncryptData;
import com.cm.android.infors.utils.InforsUtil;
import org.json.JSONObject;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

import static com.cm.android.infors.core.Consts.M;
import static com.cm.android.infors.core.Consts.TYPE_CRASH;

/**
 * 采集系统中java Crash事件
 *
 * @author wusm
 */
public class ExceptionHandler implements Thread.UncaughtExceptionHandler {

    private static final String TAG = "Infors.ExceptionHandler";
    private final Thread.UncaughtExceptionHandler mDefaultExceptionHandler;

    private static final int SLEEP_TIMEOUT_MS = 400;

    private static ExceptionHandler sInstance;

    private final CrashPlugin plugin;

    public ExceptionHandler(CrashPlugin crashPlugin) {
        this.plugin = crashPlugin;
        mDefaultExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(this);
    }

    public static void init(CrashPlugin crashPlugin) {
        if (sInstance == null) {
            synchronized (ExceptionHandler.class) {
                if (sInstance == null) {
                    sInstance = new ExceptionHandler(crashPlugin);
                }
            }
        }
    }

    @Override
    public synchronized void uncaughtException(Thread t, Throwable e) {

        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        e.printStackTrace(pw);
        pw.flush();
        //  stackTrace
        String stackTrace = sw.toString();
        //cause
//        String cause = e.getMessage();
        //throwable
        Throwable rootTr = e;
        while (e.getCause() != null) {
            e = e.getCause();
            if (e.getStackTrace() != null && e.getStackTrace().length > 0) {
                rootTr = e;
            }
            String msg = e.getMessage();
//            if (!TextUtils.isEmpty(msg))
//                cause = msg;
        }
        //exceptionType
//        String exceptionType = rootTr.getClass().getName();
        //throwClassName
//        String throwClassName;
        //throwMethodName
//        String throwMethodName;
        //throwLineNumber
//        int throwLineNumber;

//        if (rootTr.getStackTrace().length > 0) {
//            StackTraceElement trace = rootTr.getStackTrace()[0];
//            throwClassName = trace.getClassName();
//            throwMethodName = trace.getMethodName();
//            throwLineNumber = trace.getLineNumber();
//        } else {
//            throwClassName = "unknown";
//            throwMethodName = "unknown";
//            throwLineNumber = 0;
//        }


//        Log.d("EXCEPTION -stackTrace", stackTrace);
//        Log.d("EXCEPTION -cause", cause);
//        Log.d("EXCEPTION -throwable", rootTr.toString());
//        Log.d("EXCEPTION - ClassName", throwClassName);
//        Log.d("EXCEPTION -exceptionTyp", exceptionType);
//        Log.d("EXCEPTION -MethodName", throwMethodName);
//        Log.d("EXCEPTION -LineNumber", throwLineNumber+"");
//        Log.d("EXCEPTION -Process", InforsUtil.getProcessName(plugin.getApplication()));


        try {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put(ReportField.processInfo.name(), InforsUtil.getProcessName(plugin.getApplication()));
            map.put(ReportField.crashId.name(), EncryptData.getMD5(rootTr.toString() + stackTrace));
            map.put(ReportField.crashType.name(), rootTr.toString());
            map.put(ReportField.stackTrace.name(), stackTrace);
            long availMemorySize = DeviceUtils.getInstance(plugin.getApplication()).getMemoryInfo(plugin.getApplication()).availMem ;
            long totalMemorySize = DeviceUtils.getInstance(plugin.getApplication()).getMemoryInfo(plugin.getApplication()).totalMem ;
            long usedMemorySize = totalMemorySize - availMemorySize;
            double percent = (double) usedMemorySize / (double) totalMemorySize;
            map.put(ReportField.freeMemoryProportion.name(), (usedMemorySize / M) + "M/" + (totalMemorySize / M) + "M(" + String.format("%.2f", percent * 100) + "%)");
            map.put(ReportField.occurTime.name(), System.currentTimeMillis());

            Issue issue = new Issue(TYPE_CRASH, map, plugin);
            plugin.onDetectIssue(issue);
        } catch (Throwable thr) {
            Logger.e(TAG, thr, "unexpected exception, skip reporting.");
        }

        if (mDefaultExceptionHandler != null) {
            mDefaultExceptionHandler.uncaughtException(t, e);
        } else {
            killProcessAndExit();
        }
    }

    private void killProcessAndExit() {
        try {
            Thread.sleep(SLEEP_TIMEOUT_MS);
        } catch (InterruptedException e1) {
            e1.printStackTrace();
        }
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(10);
    }
}