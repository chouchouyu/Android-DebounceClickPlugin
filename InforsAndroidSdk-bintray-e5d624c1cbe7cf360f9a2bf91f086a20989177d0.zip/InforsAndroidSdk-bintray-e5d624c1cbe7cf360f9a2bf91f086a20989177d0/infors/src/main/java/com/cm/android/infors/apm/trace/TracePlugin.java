package com.cm.android.infors.apm.trace;

import android.app.Application;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import com.cm.android.infors.core.Logger;
import com.cm.android.infors.core.SDKSwitchHandler;
import com.cm.android.infors.core.plugin.Plugin;
import com.cm.android.infors.core.plugin.PluginListener;

public class TracePlugin extends Plugin {

    private static String TAG = "Infors.TracePlugin";
    private FrameTracer mFrameTracer;

    @Override
    public synchronized void init(Application app, PluginListener listener, SDKSwitchHandler dynamicConfig) {
        super.init(app, listener, dynamicConfig);
//        Logger.i(TAG, "trace plugin init, trace config: %s", mTraceConfig.toString());
        Logger.i(TAG, "trace plugin init");
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
            Logger.e(TAG, "[FrameBeat] API is low Build.VERSION_CODES.JELLY_BEAN(16), TracePlugin is not supported");
            unSupportPlugin();
            return;
        }
        if (!dynamicConfig.isBlockEnable() || !dynamicConfig.isAutoTraceEnable()) {
            unSupportPlugin();
            return;
        }

        mFrameTracer = new FrameTracer(this);
    }

    @Override
    public void start() {
        super.start();
        if (!isSupported()) {
            return;
        }
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                //保证在主线程调用
                FrameBeat.getInstance().onCreate();
            }
        });

        if (null != mFrameTracer) {
            mFrameTracer.onCreate();
        }
    }


    @Override
    public void stop() {
        super.stop();
        if (!isSupported()) {
            return;
        }
        if (null != mFrameTracer) {
            mFrameTracer.onDestroy();
        }
    }


    @Override
    public void destroy() {
        super.destroy();
    }


    @Override
    public String getTag() {
        return TracePlugin.TAG;
    }

    public FrameTracer getFrameTracer() {
        return mFrameTracer;
    }
}
