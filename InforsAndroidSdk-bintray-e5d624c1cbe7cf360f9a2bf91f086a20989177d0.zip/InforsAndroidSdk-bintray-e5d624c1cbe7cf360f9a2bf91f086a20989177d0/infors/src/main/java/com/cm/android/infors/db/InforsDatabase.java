package com.cm.android.infors.db;

import android.arch.persistence.db.SupportSQLiteDatabase;
import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.arch.persistence.room.TypeConverters;
import android.content.Context;
import android.support.annotation.NonNull;

import java.util.concurrent.atomic.AtomicInteger;

import static com.cm.android.infors.core.Consts.SDK_NAME;

/**
 * @author wusm
 */

@Database(entities = {EventEntity.class, APMEventEntity.class}, version = 3, exportSchema = false)
@TypeConverters(DateConverter.class)
public abstract class InforsDatabase extends RoomDatabase {

    public abstract EventDao eventDao();

    public abstract APMEventDao apmEventDao();

    private volatile static InforsDatabase INSTANCE;

    public static InforsDatabase getInstance(final Context context) {
        if (INSTANCE == null) {
            synchronized (InforsDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = buildDatabase(context.getApplicationContext());
                }
            }
        }
        return INSTANCE;
    }


    private static InforsDatabase buildDatabase(final Context context) {
        return Room.databaseBuilder(context,
                InforsDatabase.class, SDK_NAME)
                .fallbackToDestructiveMigration()
                .addMigrations(Migrations.MIGRATION_2_3)
                .addCallback(new RoomDatabase.Callback() {
                    @Override
                    public void onCreate(@NonNull SupportSQLiteDatabase db) {
                    }

                    @Override
                    public void onOpen(@NonNull SupportSQLiteDatabase db) {
                    }
                })
                .fallbackToDestructiveMigration()
                .build();
    }
}

