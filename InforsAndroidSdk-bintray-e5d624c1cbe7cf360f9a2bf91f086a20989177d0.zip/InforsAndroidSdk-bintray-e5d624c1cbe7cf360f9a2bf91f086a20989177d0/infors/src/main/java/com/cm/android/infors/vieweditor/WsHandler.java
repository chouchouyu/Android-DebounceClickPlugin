package com.cm.android.infors.vieweditor;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import com.cm.android.infors.core.Consts;
import com.cm.android.infors.core.InforsConfig;
import com.cm.android.infors.core.Logger;
import com.cm.android.infors.core.report.Upload;
import com.cm.android.infors.core.events.ActivityTracker;
import com.cm.android.infors.utils.InforsUtil;
import com.cm.android.infors.vieweditor.screencast.Screencast;
import com.cm.android.infors.vieweditor.view.ViewTree;

import java.net.MalformedURLException;
import java.net.URL;

import static com.cm.android.infors.core.Consts.TAG;
import static com.cm.android.infors.utils.PrefUtils.getBooleanFromSP;
import static com.cm.android.infors.utils.PrefUtils.saveBooleanSP;
import static com.cm.android.infors.vieweditor.IViewEditor.MessageType.PAGE;

/**
 * handle websocke Connect
 *
 * @author wusm
 */
public class WsHandler implements ViewTree.ViewTreeUpdateListener, Screencast.ScreenCastSavedListener {

    private final Upload upload;
    private final InforsConfig config;
    private final Context context;
    private ActivityDetail activityDetail;
    private WsJsonFactory wsJsonFactory;

    private final ActivityTracker mActivityTracker = ActivityTracker.get();
    private PCConncetion pcConncetion;
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());
    boolean shouldReportOnActivityAdded;

    final ViewTree viewTree;
    final Screencast screencast;


    public WsHandler(Context context, InforsConfig config, Upload upload) {
        this.upload = upload;
        this.config = config;
        this.context = context;
        wsJsonFactory = new WsJsonFactory(context, config);
        viewTree = new ViewTree(config, WsHandler.this);
        screencast = new Screencast(config, WsHandler.this);
        mActivityTracker.registerListener(mListener);
    }

    /**
     * startConnect webSocket
     */
    public void openWS() {
        try {
            if (!InforsUtil.isConnected(context)) {
                Logger.i(TAG, "websocket -> " + "openWS");
                URL url = new URL(config.getBaseUrl());
                StringBuffer sb_url = new StringBuffer("wss://").append(url.getHost()).append("/api/sdk-ws");
                pcConncetion = PCConncetion.getInstance(sb_url.toString(), wsConnectionHandler);
                pcConncetion.startConnect();
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } finally {
            InforsUtil.setConnection(context, true);
        }

    }


    /**
     * websoket events listener
     */
    private final IViewEditor.WsHandle wsConnectionHandler = new IViewEditor.WsHandle() {

        @Override
        public void onDisconnect(Throwable throwable) {
            InforsUtil.setConnection(context, false);
            shouldReportOnActivityAdded = false;
            mActivityTracker.unregisterListener(mListener);
        }

        @Override
        public void onOpen() {
            String deviceInfo = wsJsonFactory.getDeviceInfoJson();
            Logger.i(TAG, "websocket ->: send :sendDeviceInfo " + deviceInfo);
            pcConncetion.send(deviceInfo);

        }

        @Override
        public void onSendMessageSuccess() {
            mMainHandler.post(new Runnable() {
                @Override
                public void run() {
                    shouldReportOnActivityAdded = true;
                    tryGetActivityInfo();
                }
            });
        }
    };


    private final ActivityTracker.Listener mListener = new ActivityTracker.Listener() {

        @Override
        public void onActivityCreate(Activity activity) {

        }

        @Override
        public void onActivityStart(Activity activity) {

        }

        @Override
        public void onActivityResume(Activity activity) {
            tryGetActivityInfo();
        }

        @Override
        public void onActivityPause(Activity activity) {

        }

        @Override
        public void onActivityStop(Activity activity) {

        }

        @Override
        public void onActivityDestroyed(Activity activity) {

        }

    };

    /**
     * after websocket connected ,send activity descible info
     */
    public void tryGetActivityInfo() {
        final Activity activity = mActivityTracker.tryGetTopActivity();
        if (shouldReportOnActivityAdded) {
            activityDetail = new ActivityDetail();
            viewTree.startDrawViewTree(activity);
            screencast.startScreencast(activity);
        }
    }

    /**
     * get activity view Tree
     *
     * @param activityName
     * @param viewTreeJson
     */
    @Override
    public void onViewTreeChange(String activityName, String viewTreeJson) {
        activityDetail.setActivityName(activityName);
        if (activityDetail.getActivityName().equals(activityName)) {
            activityDetail.setViewTreeJson(viewTreeJson);
        }
    }

    /**
     * get activity ScreenCast
     *
     * @param activityName
     * @param picPath
     */
    @Override
    public void onScreenCastSaved(final String activityName, final String picPath) {
        upload.uploadPic(picPath, new IViewEditor.OnSuccess() {
            @Override
            public void onSuccess(String picUrl) {
                if (TextUtils.equals(activityDetail.getActivityName(), activityName)) {
                    activityDetail.setPicPath(picUrl);
                    if (!TextUtils.isEmpty(activityDetail.getViewTreeJson())) {
                        String json = wsJsonFactory.jsonFactory(PAGE, activityDetail.getViewTreeJson(), activityDetail.getPicPath());
                        Logger.w(TAG, "webSocket: send :sendPageInfo  " + json);
                        pcConncetion.send(json);
                    }
                }
            }

        });
    }


    class ActivityDetail {
        private String activityName;
        private String viewTreeJson;
        private String picPath;

        public String getActivityName() {
            return activityName;
        }

        public void setActivityName(String activityName) {
            this.activityName = activityName;
        }

        public String getViewTreeJson() {
            return viewTreeJson;
        }

        public void setViewTreeJson(String viewTreeJson) {
            this.viewTreeJson = viewTreeJson;
        }

        public String getPicPath() {
            return picPath;
        }

        public void setPicPath(String picPath) {
            this.picPath = picPath;
        }

        @Override
        public String toString() {
            return "ActivityDetail{" +
                    "activityName='" + activityName + '\'' +
                    ", viewTreeJson='" + viewTreeJson + '\'' +
                    ", picPath='" + picPath + '\'' +
                    '}';
        }
    }
}
