package com.cm.android.infors;

import android.app.Application;
import android.support.annotation.NonNull;

import java.util.HashSet;
import java.util.Map;
import java.util.concurrent.ThreadPoolExecutor;

import com.cm.android.infors.apm.crash.CrashPlugin;
import com.cm.android.infors.apm.network.HttpPlugin;
import com.cm.android.infors.apm.trace.TracePlugin;
import com.cm.android.infors.apm.trace.hacker.Hacker;
import com.cm.android.infors.core.*;
import com.cm.android.infors.core.events.ActivityTracker;
import com.cm.android.infors.core.events.ProcessMonitor;
import com.cm.android.infors.core.thread.DefaultPoolExecutor;
import com.cm.android.infors.core.plugin.DefaultPluginListener;
import com.cm.android.infors.core.plugin.Plugin;
import com.cm.android.infors.core.plugin.PluginListener;
import com.cm.android.infors.core.report.Upload;
import com.cm.android.infors.request.modal.UserInfo;
import com.cm.android.infors.vieweditor.listener.WindowCallbackListener;

import static com.cm.android.infors.core.Consts.*;

/**
 * Created by wusm on 2018/4/2.
 */
public final class Infors implements SDKSwitchHandler.SDKSwitchListener {

    static {
        Hacker.hackSysHandlerCallback();
    }

    public volatile static ThreadPoolExecutor executor = DefaultPoolExecutor.getInstance();

    private volatile static InforsConfig config = InforsConfig.getInstance();
    private final Boolean openLog;

    @Override
    public void onSwitchChange(SDKSwitchHandler sdkSwitchHandler) {

        Logger.i(TAG, "sdk 开关->: "
                + "SDK总开关 :" + sdkSwitchHandler.isInforsEnable()
                + "；自动埋点开关 :" + sdkSwitchHandler.isAutoTraceEnable()
                + "；热力图开关 :" + sdkSwitchHandler.isHeatMapEnable()
                + "；可视化开关 :" + sdkSwitchHandler.isViewEditorEnable()
                + "；http开关 :" + sdkSwitchHandler.isHttpEnable()
                + "；卡顿开关 :" + sdkSwitchHandler.isBlockEnable()
                + "；奔溃开关 :" + sdkSwitchHandler.isCrashEnable()
        );
        if (sdkSwitchHandler.isInforsEnable()) {
            plugins = new HashSet<>();
            addPlugin(new HttpPlugin());
            addPlugin(new CrashPlugin());
            addPlugin(new TracePlugin());
            addPlugin(new InitialPlugin(config, upload, processMonitor));
            for (Plugin plugin : plugins) {
                plugin.init(app, pluginListener, sdkSwitchHandler);
                pluginListener.onInit(plugin);
            }
            startAllPlugins();
        }
    }


    public static class Builder {
        private final Application application;
        private String appkey;
        private Boolean openLog;
        //        private HashSet<Plugin> plugins;
        private PluginListener pluginListener;
        private String baseUrl;

        public Builder(@NonNull Application app) {
            if (app == null) {
                throw new RuntimeException("Infors init, application is null");
            }
            this.application = app;
        }
//
//        private Builder plugin(Plugin plugin) {
//            if (plugins == null) {
//                plugins = new HashSet<>();
//            }
//            String tag = plugin.getTag();
//            for (Plugin exist : plugins) {
//                if (tag.equals(exist.getTag())) {
//                    throw new RuntimeException(String.format("plugin with tag %s is already exist", tag));
//                }
//            }
//            plugins.add(plugin);
//            return this;
//        }


        public Builder setBaseUrl(@NonNull String baseUrl) {
            this.baseUrl = baseUrl;
            return this;
        }

        public Builder patchListener(@NonNull PluginListener pluginListener) {
            this.pluginListener = pluginListener;
            return this;
        }


        public Builder setAppkey(@NonNull String appkey) {
            this.appkey = appkey;
            return this;
        }

        public Builder Loggable(@NonNull Boolean openLog) {
            this.openLog = openLog;
            return this;
        }


        public Infors build() {
            if (PermissionHelper.checkBasicConfiguration(application)) {
                Logger.i(TAG, "Infos ====== 权限申请不全 =====");
            }
            if (pluginListener == null) {
                pluginListener = new DefaultPluginListener(application, config, executor);
            }

            return new Infors(application, appkey, openLog, pluginListener, baseUrl);
        }

    }


    public static Infors init(@NonNull Infors infors) {
        if (infors == null) {
            throw new RuntimeException("Infors init,infors should not be null.");
        }
        synchronized (Infors.class) {
            if (null == instance) {
                instance = infors;
            } else {
                Logger.e(TAG, "Infos instance is already set. this invoking will be ignored");
            }
        }
        return instance;
    }

    public static Infors getInstance() {
        if (instance == null) {
            throw new RuntimeException("you must init Infors sdk first");
        }
        return instance;
    }

    private Upload upload;
    private final PluginListener pluginListener;
    private HashSet<Plugin> plugins;

    public void startAllPlugins() {
        if (plugins == null) {
            return;
        }
        for (Plugin plugin : plugins) {
            plugin.start();
        }
    }

    public void stopAllPlugins() {
        if (plugins == null) {
            return;
        }
        for (Plugin plugin : plugins) {
            plugin.stop();
        }
    }

    public void destroyAllPlugins() {
        if (plugins == null) {
            return;
        }
        for (Plugin plugin : plugins) {
            plugin.destroy();
        }
    }

    public HashSet<Plugin> getPlugins() {
        return plugins;
    }

    public Plugin getPluginByTag(String tag) {
        if (plugins == null) {
            return null;
        }
        for (Plugin plugin : plugins) {
            if (plugin.getTag().equals(tag)) {
                return plugin;
            }
        }
        return null;
    }

    public <T extends Plugin> T getPluginByClass(Class<T> pluginClass) {
        if (plugins == null) {
            return null;
        }
        String className = pluginClass.getName();
        for (Plugin plugin : plugins) {
            if (plugin.getClass().getName().equals(className)) {
                return (T) plugin;
            }
        }
        return null;
    }


    ProcessMonitor processMonitor = ProcessMonitor.get();


    private HashSet<Plugin> addPlugin(Plugin plugin) {
        if (plugins == null) {
            plugins = new HashSet<>();
        }
        String tag = plugin.getTag();
        for (Plugin exist : plugins) {
            if (tag.equals(exist.getTag())) {
                throw new RuntimeException(String.format("plugin with tag %s is already exist", tag));
            }
        }
        plugins.add(plugin);
        return plugins;
    }

    private Infors(final Application application, String appkey, Boolean openLog,
                   PluginListener pluginListener, String baseUrl) {

        this.app = application;
        config.setAppKey(appkey);
        config.setBaseUrl(baseUrl);
        this.openLog = openLog;
        this.pluginListener = pluginListener;
        initLogger(openLog);

        upload = new Upload(config, executor);
//        initialPlugin = new InitialPlugin(config, upload);
//        if (plugins == null) {
//            plugins = new HashSet<>();
//        }

//        plugins.add(initialPlugin);

        if (app == null) {
            Logger.i(TAG, "Infos ===== Application 不能为null =====");
            return;
        }

        Logger.i(TAG, "Infos ===== 数据采集开始 =====");
//        setAppLaunchTime();

        // Hook activity tracking so that after infors is attached we can figure out what
        // activities are present.
        boolean isTrackingActivities = ActivityTracker.get().beginTrackingIfPossible(
                app);
        if (!isTrackingActivities) {
            Logger.i(TAG, "Automatic activity tracking not available on this API level, caller must " +
                    "invoke " +
                    "ActivityTracker methods manually!");
        }

        processMonitor.start();


        SDKSwitchHandler switchHandler = new SDKSwitchHandler(app, config, this);
        switchHandler.getSwitchConfigFormNet(upload);

        new WindowCallbackListener(config, upload);
    }


    private final Application app;

    public Application getAppContext() {
        return app;
    }

    private static volatile Infors instance;

    private void initLogger(final boolean flag) {
        Logger.enableLogger(flag);
    }

    /**
     * app 启动时间计时
     */
//    private void setAppLaunchTime() {
//        config.setAppLaunchTime(Hacker.sApplicationCreateBeginTime);
//    }


    /**
     * 用户登录时 设置用户信息
     *
     * @param userInfo
     */
    public void setUserDetail(@NonNull UserInfo userInfo) {
        InitialPlugin plugin = Infors.getInstance().getPluginByClass(InitialPlugin.class);

        if (plugin != null) {
            plugin.reportUserInfo(userInfo);
        }

    }

    /**
     * 用户登出时 设置登出信息
     */
    public void logout() {
        InitialPlugin plugin = Infors.getInstance().getPluginByClass(InitialPlugin.class);

        if (plugin != null) {
            plugin.reportUserInfo(null);
        }
    }

    /**
     * 用户自添加数据，在每次上报都会带上的。
     * V3.0.0 兼容多次调用
     *
     * @param globalParams
     */
    public void setGlobalInfo(@NonNull Map<String, String> globalParams) {
        config.setGlobalParams(globalParams);
    }


    /**
     * 设置自定义Event
     * Map中的key,String中不要带"-",后台不支持，会被过滤掉
     *
     * @param vid
     * @param describe
     * @param map
     */
    public void track(@NonNull String vid, @NonNull String describe, @NonNull Map<String, String>
            map) {
        InitialPlugin plugin = Infors.getInstance().getPluginByClass(InitialPlugin.class);
        if (plugin != null) {
            plugin.reportTraceEvent(vid, describe, map, null);
        }
    }

    /**
     * 区分track，通过该接口上传的事件会单立传至appkey的项目，而非默认项目
     *
     * @param vid      事件的vid,不同的事件保持不一样就行
     * @param describe 作为埋点名称，会在网页中被展示
     * @param map      事件的详细信息，会被插入上报事件的data节点
     * @param appkey   上报至指定的appkey项目下。
     */
    public void trackDistinct(@NonNull String vid, @NonNull String describe, @NonNull Map<String, String>
            map, @NonNull String appkey) {
        InitialPlugin plugin = Infors.getInstance().getPluginByClass(InitialPlugin.class);
        if (plugin != null) {
            plugin.reportTraceEvent(vid, describe, map, appkey);
        }
    }


}

