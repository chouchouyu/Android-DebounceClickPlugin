package com.cm.android.infors.vieweditor.view;

import android.app.Activity;
import android.view.View;
import android.view.ViewDebug;

import com.cm.android.infors.request.modal.ViewDescribe;
import com.cm.android.infors.runtime.AutoTrackUtils;
import com.cm.android.infors.core.Logger;
import com.cm.android.infors.utils.ExceptionHandler;
import com.cm.android.infors.utils.ViewPathUtil;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Observable;
import java.util.regex.Pattern;

import javax.annotation.Nullable;
import javax.annotation.concurrent.GuardedBy;


/**
 * get  propertys for a view
 * Created by susan on 2018/8/13.
 */

public class ViewProperty extends Observable {

    private final Activity activity;
    /**
     * NOTE: Only access this via {@link #getViewProperties}.
     */
    @Nullable
    @GuardedBy("this")
    private volatile List<ViewProperty.ViewCSSProperty> mViewProperties;


    public ViewProperty(View view, int index, Activity activity) {
        ViewDescribe viewDescribe = new ViewDescribe(view, index);
        this.activity = activity;
        getViewDescribe(view, viewDescribe);
    }


    /**
     * get view propertys to describe a cretain view
     *
     * @param view
     * @param viewDescribe
     */
    private void getViewDescribe(final View view, final ViewDescribe viewDescribe) {
        final int[] decorViewLocationInScreen = new int[2];
        view.post(new Runnable() {
            @Override
            public void run() {
                view.getLocationOnScreen(decorViewLocationInScreen);
//                Logger.d("---decorView locationInScreen x is " + decorViewLocationInScreen[0] +
//                        "                              location In Screen Y is " +
//                        decorViewLocationInScreen[1]);
                final List<ViewCSSProperty> properties = getViewProperties();

                for (int i = 0, size = properties.size(); i < size; i++) {
                    final ViewCSSProperty property = properties.get(i);

                    try {
//                        Log.w("Traversal-focus", " CSSName:" + property.getCSSName());
//                                Log.w("Traversal-focus", "View NAME:" + onGetNodeName(childVg)
//                                                + " CSSName:" + property.getCSSName()
//                                                + " Value:" + property.getValue(childVg)
//                                +  " Annotation:" + property.getAnnotation()
//                                );

                        String CSSName = property.getCSSName();
                        Object rawValue = property.getValue(view);


                        if (rawValue != null) {
                        } else {
                        }

                        switch (CSSName) {
                            case "context":
                                viewDescribe.setPageName(rawValue.getClass().getCanonicalName());
                                break;
                            case "measured-height":
                                viewDescribe.setHeight(toInt(rawValue));
                                break;
                            case "measured-width":
                                viewDescribe.setWidth(toInt(rawValue));
                                break;
                            case "top":
                                viewDescribe.setTop(decorViewLocationInScreen[1]);
                                break;
                            case "left":
                                viewDescribe.setLeft(decorViewLocationInScreen[0]);
                                break;


                        }
                    } catch (Exception e) {
                        if (e instanceof IllegalAccessException || e instanceof
                                InvocationTargetException) {
                            Logger.e(e.getStackTrace().toString(), String.format("failed to get " +
                                    "style property " + property.getCSSName() +
                                    " of element= " + view.toString()));
                        } else {
                            throw ExceptionHandler.propagate(e);
                        }
                    }
                }


                viewDescribe.setId(AutoTrackUtils.getId(activity, view));
                viewDescribe.setXpath(ViewPathUtil.getViewPath(view));
                viewDescribe.setConfigable(AutoTrackUtils.configableOfView(view));
                setChanged();
                notifyObservers(viewDescribe);
            }
        });

    }


    private int toInt(Object rawValue) {
        if (rawValue instanceof Integer) {
            return (int) rawValue;
        } else {
            return 0;
        }
    }


    private List<ViewProperty.ViewCSSProperty> getViewProperties() {
        if (mViewProperties == null) {
            synchronized (this) {
                if (mViewProperties == null) {
                    List<ViewProperty.ViewCSSProperty> props = new ArrayList<>();

                    for (final Method method : View.class.getDeclaredMethods()) {
                        ViewDebug.ExportedProperty annotation =
                                method.getAnnotation(
                                        ViewDebug.ExportedProperty.class);

                        if (annotation != null) {
                            props.add(new ViewProperty.MethodBackedCSSProperty(
                                    method,
                                    convertViewPropertyNameToCSSName(method.getName()),
                                    annotation));
                        }
                    }

                    for (final Field field : View.class.getDeclaredFields()) {
                        ViewDebug.ExportedProperty annotation =
                                field.getAnnotation(
                                        ViewDebug.ExportedProperty.class);

                        if (annotation != null) {
                            props.add(new ViewProperty.FieldBackedCSSProperty(
                                    field,
                                    convertViewPropertyNameToCSSName(field.getName()),
                                    annotation));
                        }
                    }


                    Collections.sort(props, new Comparator<ViewProperty.ViewCSSProperty>() {
                        @Override
                        public int compare(ViewProperty.ViewCSSProperty lhs, ViewProperty
                                .ViewCSSProperty rhs) {
                            return lhs.getCSSName().compareTo(rhs.getCSSName());
                        }
                    });
                    mViewProperties = Collections.unmodifiableList(props);
                }
            }
        }


        return mViewProperties;
    }

    private String convertViewPropertyNameToCSSName(String getterName) {
        // Split string by uppercase characters. Thankfully since
        // this is the android source we don't have to worry about
        // internationalization funk.

        String[] words = getWordBoundaryPattern().split(getterName);

        StringBuilder result = new StringBuilder();

        for (int i = 0; i < words.length; i++) {
            if ("get".equals(words[i]) || "m".equals(words[i])) {
                continue;
            }

            result.append(words[i].toLowerCase());

            if (i < words.length - 1) {
                result.append('-');
            }
        }

        return result.toString();
    }

    /**
     * NOTE: Only access this via {@link #getWordBoundaryPattern}.
     */
    @Nullable
    private Pattern mWordBoundaryPattern;

    private Pattern getWordBoundaryPattern() {
        if (mWordBoundaryPattern == null) {
            mWordBoundaryPattern = Pattern.compile("(?<=\\p{Lower})(?=\\p{Upper})");
        }

        return mWordBoundaryPattern;
    }

    private abstract class ViewCSSProperty {
        private final String mCSSName;
        private final ViewDebug.ExportedProperty mAnnotation;

        public ViewCSSProperty(String cssName, @Nullable ViewDebug.ExportedProperty annotation) {
            mCSSName = cssName;
            mAnnotation = annotation;
        }

        public final String getCSSName() {
            return mCSSName;
        }

        public abstract Object getValue(View view)
                throws InvocationTargetException, IllegalAccessException;

        public final @Nullable
        ViewDebug.ExportedProperty getAnnotation() {
            return mAnnotation;
        }
    }

    private final class FieldBackedCSSProperty extends ViewProperty.ViewCSSProperty {
        private final Field mField;

        public FieldBackedCSSProperty(
                Field field,
                String cssName,
                @Nullable ViewDebug.ExportedProperty annotation) {
            super(cssName, annotation);
            mField = field;
            mField.setAccessible(true);
        }

        @Override
        public Object getValue(View view) throws InvocationTargetException, IllegalAccessException {
            return mField.get(view);
        }
    }

    private final class MethodBackedCSSProperty extends ViewProperty.ViewCSSProperty {
        private final Method mMethod;

        public MethodBackedCSSProperty(
                Method method,
                String cssName,
                @Nullable ViewDebug.ExportedProperty annotation) {
            super(cssName, annotation);
            mMethod = method;
            mMethod.setAccessible(true);
        }

        @Override
        public Object getValue(View view) throws InvocationTargetException, IllegalAccessException {
            return mMethod.invoke(view);
        }
    }


}
