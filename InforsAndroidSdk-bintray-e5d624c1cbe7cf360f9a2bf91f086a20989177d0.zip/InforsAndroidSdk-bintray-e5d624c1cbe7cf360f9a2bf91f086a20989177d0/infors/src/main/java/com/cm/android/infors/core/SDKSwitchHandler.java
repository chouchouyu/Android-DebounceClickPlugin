package com.cm.android.infors.core;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import com.cm.android.infors.core.report.Upload;
import com.cm.android.infors.request.modal.SdkSwitchRes;
import com.cm.android.infors.utils.SharedPreferencesFactory;

import static com.cm.android.infors.core.Consts.*;
import static com.cm.android.infors.utils.PrefUtils.*;

public class SDKSwitchHandler {

    public interface NetResponse {
        void onSuccess(SdkSwitchRes.BodyBean switchBean);

        void onFailure();
    }

    private SDKSwitchListener listener;

    public interface SDKSwitchListener {
        void onSwitchChange(SDKSwitchHandler sdkSwitchHandler);
    }

    private final Context context;
    private final InforsConfig config;


    public SDKSwitchHandler(Context context, InforsConfig config, SDKSwitchListener listener) {
        this.context = context;
        this.config = config;
        this.listener = listener;
    }

    public void getSwitchConfigFormNet(Upload upload) {
        upload.getSwith(config, new SDKSwitchHandler.NetResponse() {

            @Override
            public void onSuccess(SdkSwitchRes.BodyBean switchBean) {
                saveToSP(switchBean);
                listener.onSwitchChange(SDKSwitchHandler.this);
            }

            @Override
            public void onFailure() {
                listener.onSwitchChange(SDKSwitchHandler.this);
            }
        });

    }


    public void saveToSP(SdkSwitchRes.BodyBean switchBean) {
        setInforsEnable(switchBean.isIsInforsEnable());
        setAutoTraceEnable(switchBean.isIsAutoTraceEnable());
        setHeatMapEnable(switchBean.isIsHeatMapEnable());
        setViewEditorEnable(switchBean.isIsViewEditorEnable());
        setBlockEnable(switchBean.isIsBlockEnable());
        setCrashEnable(switchBean.isIsCrashEnable());
        setHttpEnable(switchBean.isIsHttpEnable());
    }

    public void setInforsEnable(boolean inforsEnable) {
        saveBooleanSP(context, config, SP_SWITCH_INFORS, inforsEnable);
    }

    public void setAutoTraceEnable(boolean autoTraceEnable) {
        saveBooleanSP(context, config, SP_SWITCH_AUTOTRACE, autoTraceEnable);
    }

    public void setHeatMapEnable(boolean heatMapEnable) {
        saveBooleanSP(context, config, SP_SWITCH_HEATMAP, heatMapEnable);
    }

    public void setViewEditorEnable(boolean viewEditorEnable) {
        saveBooleanSP(context, config, SP_SWITCH_VIEWEDITOR, viewEditorEnable);
    }

    public void setHttpEnable(boolean httpEnable) {
        saveBooleanSP(context, config, SP_SWITCH_HTTP, httpEnable);
    }

    public void setBlockEnable(boolean blockEnable) {
        saveBooleanSP(context, config, SP_SWITCH_BLOCK, blockEnable);
    }

    public void setCrashEnable(boolean crashEnable) {
        saveBooleanSP(context, config, SP_SWITCH_CRASH, crashEnable);
    }

    public boolean isInforsEnable() {
        return getValue(SP_SWITCH_INFORS);
    }

    public boolean isAutoTraceEnable() {
        return getValue(SP_SWITCH_AUTOTRACE);
    }

    public boolean isHeatMapEnable() {
        return getValue(SP_SWITCH_HEATMAP);
    }

    public boolean isViewEditorEnable() {
        return getValue(SP_SWITCH_VIEWEDITOR);
    }

    public boolean isHttpEnable() {
        return getValue(SP_SWITCH_HTTP);
    }

    public boolean isBlockEnable() {
        return getValue(SP_SWITCH_BLOCK);
    }

    public boolean isCrashEnable() {
        return getValue(SP_SWITCH_CRASH);
    }


    private boolean getValue(String key) {
        SharedPreferencesFactory sharedPreferencesFactory = new SharedPreferencesFactory(context,
                config);
        SharedPreferences sharedPreferences = sharedPreferencesFactory.create();
        if (sharedPreferences.contains(key)) {
            return getBooleanFromSP(context, config, key);
        }
        return false;
    }
}
