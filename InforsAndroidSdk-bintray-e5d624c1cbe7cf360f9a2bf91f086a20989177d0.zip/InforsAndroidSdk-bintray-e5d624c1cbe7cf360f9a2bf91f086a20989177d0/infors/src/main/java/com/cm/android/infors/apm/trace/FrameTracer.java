package com.cm.android.infors.apm.trace;

import android.app.Activity;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.view.ViewTreeObserver;
import com.cm.android.infors.apm.trace.listeners.IDoFrameListener;
import com.cm.android.infors.core.Consts;
import com.cm.android.infors.core.Logger;
import com.cm.android.infors.core.ReportField;
import com.cm.android.infors.core.events.ActivityTracker;
import com.cm.android.infors.core.report.Issue;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

import static com.cm.android.infors.core.Consts.*;

/**
 * https://mp.weixin.qq.com/s?__biz=MzAxMzYyNDkyNA==&mid=2651332439&idx=1&sn=ba542ffeb494d827b9009d4e2128ed5c&scene=1&srcid=0818mFLqkkIMoS7vzjxTOEq2&key=8dcebf9e179c9f3a440c75502cc03ba23f09db161f5a3a4bd15acbdaa6b2ac0e641552d3b40a09b753739924009c9bfb&ascene=0&uin=Mjc3OTU3Nzk1&devicetype=iMac+MacBookPro10%2C1+OSX+OSX+10.10.5+build%2814F1909%29&version=11020201&pass_ticket=jzkG1H7kXvY27npmMnFUaa1eMShQT4c0PYd9r8wDanabk59MHU0ynkDd6oxen8jH
 * Android卡顿性能监测方案对比
 */
@RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
public class FrameTracer extends BaseTracer implements ViewTreeObserver.OnDrawListener, ActivityTracker.Listener {
    private static final String TAG = "Infors.FrameTracer";
    private boolean isDrawing;
    private final LinkedList<IDoFrameListener> mDoFrameListenerList = new LinkedList<>();
    private static final long REFRESH_RATE_MS = (int) (Consts.DEFAULT_DEVICE_REFRESH_RATE * Consts.TIME_MILLIS_TO_NANO);
    private static long SKIPPED_FRAME_ANR_TRIGGER = 0;
    private static long SKIPPED_FRAME_WARNING_LIMIT = 0;


    public FrameTracer(TracePlugin plugin) {
        super(plugin);
        SKIPPED_FRAME_WARNING_LIMIT = Consts.THRESHOLD_TIME * 1000l * 1000l / REFRESH_RATE_MS;
        SKIPPED_FRAME_ANR_TRIGGER = 5000000000l / REFRESH_RATE_MS;

        ActivityTracker.get().registerListener(this);
    }

    @Override
    public void doFrame(final long lastFrameNanos, final long frameNanos) {
        if (!isDrawing) {
            return;
        }
        isDrawing = false;

        final int droppedCount = (int) ((frameNanos - lastFrameNanos) / REFRESH_RATE_MS);
        if (droppedCount > 1) {
            if (droppedCount >= SKIPPED_FRAME_WARNING_LIMIT) {
//                Logger.d(TAG, "Skipped " + droppedCount + " frames!  "
//                        + "The application may be doing too much work on its main thread." + (droppedCount >= SKIPPED_FRAME_ANR_TRIGGER));
                final BlockError blockError = BlockError.NewMainOnly(droppedCount, getScene(),
                        droppedCount >= SKIPPED_FRAME_ANR_TRIGGER);
                Map<String, Object> map = new HashMap<String, Object>();
                map.put(ReportField.occurTime.name(), System.currentTimeMillis());
                map.put(ReportField.pageId.name(), blockError.getScreen());
                map.put(ReportField.thread.name(), blockError.getThread());
                map.put(ReportField.msg.name(), blockError.getScreen() + " " + blockError.getMessage());
                Issue issue = new Issue(TYPE_BLOCK, map, getPlugin());
                getPlugin().onDetectIssue(issue);
                for (final IDoFrameListener listener : mDoFrameListenerList) {
                    listener.doFrameSync(blockError);
                    if (null != listener.getHandler()) {
                        listener.getHandler().post(new Runnable() {
                            @Override
                            public void run() {
                                listener.getHandler().post(new AsyncDoFrameTask(listener, blockError));
                            }
                        });

                    }
                }

            }

        }
    }


    @Override
    public void onActivityCreate(Activity activity) {

    }

    @Override
    public void onActivityStart(Activity activity) {

    }

    @Override
    public void onActivityResume(final Activity activity) {
        if (null == activity) {
            Logger.e(TAG, "Empty Parameters");
            return;
        }

        if (null != activity.getWindow() && null != activity.getWindow().getDecorView()) {
            activity.getWindow().getDecorView().post(new Runnable() {
                @Override
                public void run() {
                    Logger.i(TAG, "[onChange] activity:%s", activity.getClass().getCanonicalName());
                    activity.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(FrameTracer.this);
                    activity.getWindow().getDecorView().getViewTreeObserver().addOnDrawListener(FrameTracer.this);
                }
            });
        }
    }

    @Override
    public void onActivityPause(Activity activity) {

    }

    @Override
    public void onActivityStop(Activity activity) {

    }

    @Override
    public void onActivityDestroyed(Activity activity) {

    }


    @Override
    public void onDraw() {
        isDrawing = true;
    }

    private final static class AsyncDoFrameTask implements Runnable {
        private BlockError blockError;
        IDoFrameListener listener;

        public AsyncDoFrameTask(IDoFrameListener listener, BlockError blockError) {
            this.listener = listener;
            this.blockError = blockError;
        }

        @Override
        public void run() {
            listener.doFrameAsync(blockError);
        }
    }

    public void register(IDoFrameListener listener) {
        if (FrameBeat.getInstance().isPause()) {
            FrameBeat.getInstance().resume();
        }
        if (!mDoFrameListenerList.contains(listener)) {
            mDoFrameListenerList.add(listener);
        }
    }

    public void unregister(IDoFrameListener listener) {
        mDoFrameListenerList.remove(listener);
        if (!FrameBeat.getInstance().isPause() && mDoFrameListenerList.isEmpty()) {
            FrameBeat.getInstance().removeListener(this);
        }
    }
}
