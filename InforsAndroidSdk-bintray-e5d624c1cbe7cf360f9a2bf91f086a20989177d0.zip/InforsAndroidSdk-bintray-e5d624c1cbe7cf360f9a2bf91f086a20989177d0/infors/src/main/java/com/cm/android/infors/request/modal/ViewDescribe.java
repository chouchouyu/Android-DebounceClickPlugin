package com.cm.android.infors.request.modal;

import android.view.View;

import java.util.LinkedList;
import java.util.List;

/**
 * 可视化view的描述
 * @author wusm
 */

public class ViewDescribe {

    private List<ViewDescribe> childViews;
    private int height;
    private int id;
    private int index;
    private int left;
    private String pageName;
    private int top;
    private String type;
    private int width;
    private String xpath;
    private boolean configable;

    public ViewDescribe(View view, int index) {
        setType(view.getClass().getName());
        setIndex(index);
    }

    public List<ViewDescribe> getChildViews() {
        if (childViews == null) {
            childViews = new LinkedList<>();
        }
        return childViews;
    }

    public void setChildViews(List<ViewDescribe> childViews) {
        this.childViews = childViews;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public int getLeft() {
        return left;
    }

    public void setLeft(int left) {
        this.left = left;
    }

    public String getPageName() {
        return pageName;
    }

    public void setPageName(String pageName) {
        this.pageName = pageName;
    }

    public int getTop() {
        return top;
    }

    public void setTop(int top) {
        this.top = top;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public String getXpath() {
        return xpath;
    }

    public void setXpath(String xpath) {
        this.xpath = xpath;
    }

    public boolean isConfigable() {
        return configable;
    }

    public void setConfigable(boolean configable) {
        this.configable = configable;
    }

    @Override
    public String toString() {
        return "ViewDescribe{" +
                "childViews=" + childViews +
                ", height=" + height +
                ", id=" + id +
                ", index=" + index +
                ", left=" + left +
                ", pageName='" + pageName + '\'' +
                ", top=" + top +
                ", type='" + type + '\'' +
                ", width=" + width +
                ", xpath='" + xpath + '\'' +
                ", configable=" + configable +
                '}';
    }
}
