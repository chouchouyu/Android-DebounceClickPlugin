package com.cm.android.infors.plugin.utils

import com.android.SdkConstants
import com.android.build.gradle.AppExtension
import com.android.build.gradle.BaseExtension
import com.android.utils.FileUtils
import com.cm.android.infors.plugin.InforsExtension
import org.gradle.api.Project
class Utils {

    static def shouldExcludeFile(def filePath) {
        if (filePath.endsWith("BuildConfig.class")
                || filePath.endsWith("BuildConfig\$*.class")
                || filePath.endsWith("R.class")
                || isRIgnoreFile(filePath)
                || isBuildConfigIgnoreFile(filePath)) {
            return true
        } else {
            return false

        }
    }

    static def isRIgnoreFile(def fileName) {
        //println  ('R$mipmap.class'==~'R\\$mipmap\\.class' )
        def regex = ~'R\\$.*\\.class'
        def match = fileName =~ regex
        match.find()
    }

    static def isBuildConfigIgnoreFile(def fileName) {
        //("BuildConfig\$*.class")
        def regex = ~'BuildConfig\\$.*\\.class'
        def match = fileName =~ regex
        match.find()
    }


    static boolean isMatchCondition(Project project, InforsExtension extension, String name) {
        name.endsWith(SdkConstants.DOT_CLASS) &&
                shouldModifyClass(project, extension, name) &&
                !shouldExcludeFile(name)
    }

    /**
     * 只扫描特定包下的类
     * @param className 形如 android.app.Fragment 的类名
     * @return
     */
    static def shouldModifyClass(Project project, InforsExtension extension, String className) {
        def targetPackages = setIncludePackages(extension.includePackages, project)
        def pathName = path2Classname(className);
        for (i in targetPackages) {
            if (pathName.contains(i)) {
                return true
            }
        }
        return false
    }

    static def path2Classname(String entryName) {
        entryName.replace(File.separator, ".").replace(".class", "")
    }


    static def setIncludePackages(def includePackage, Project project) {
        def butterknifePackage = ['butterknife.internal.DebouncingOnClickListener']
        AppExtension android = project.extensions.getByType(AppExtension)
        def appPackageName = getAppPackageName(android)
        butterknifePackage.add(appPackageName)
        if (includePackage) {
            butterknifePackage.addAll(includePackage)
        }
        butterknifePackage
    }

    /**
     * 获取应用程序包名
     * @return
     */
    static def getAppPackageName(AppExtension android) {
        def manifestFile = android.sourceSets.main.manifest.srcFile
        def xml = new XmlSlurper().parse(manifestFile)
        def pageName = xml.@package
        return "$pageName"
    }


    static void forExtension(BaseExtension extension, Closure closure) {

        def findExtensionType
        if (closure.maximumNumberOfParameters == 3) findExtensionType = true

        if (extension instanceof AppExtension) {
            if (findExtensionType) {
                closure.call(true, false, false)
            } else {
                extension.applicationVariants.all(closure)
            }
        }
//        if (extension instanceof LibraryExtension) {
//            if (findExtensionType) {
//                closure.call(false, true, false)
//            } else {
//                extension.libraryVariants.all(closure)
//            }
//        }
//        if (extension instanceof FeatureExtension) {
//            if (findExtensionType) {
//                closure.call(false, false, true)
//            } else {
//                extension.featureVariants.all(closure)
//            }
//        }
    }

    static File toOutputFile(File outputDir, File inputDir, File inputFile) {
        return new File(outputDir, FileUtils.relativePossiblyNonExistingPath(inputFile, inputDir))
    }

}
